"""从06验收文档唯一来源导出一张宽屏指标表，不生成测试成绩。"""
from pathlib import Path
from hashlib import sha256
from html import escape
from urllib.parse import quote
from bs4 import BeautifulSoup
from markdown_it import MarkdownIt

folder = Path(__file__).resolve().parent
source = folder.parent / "0001-douyin-ai-studio" / "06-验收标准与测试方案.md"
raw = source.read_text(encoding="utf-8")
body = BeautifulSoup(MarkdownIt("commonmark").enable("table").render(raw), "html.parser")
table = next(t for t in body.find_all("table") if "指标（★核心）" in t.get_text())
rows = table.select("tbody tr")
core = 0
last_stage = None
for row in rows:
    cells = row.find_all("td", recursive=False)
    if len(cells) != 5:
        raise ValueError("指标表必须包含环节、指标、含义、方法、基线五列")
    stage = cells[0].get_text(strip=True)
    classes = []
    if "★" in cells[1].get_text():
        classes.append("core")
        core += 1
    if stage != last_stage:
        classes.append("stage-start")
    row["class"] = classes
    last_stage = stage
for header in table.select("thead th"):
    header["scope"] = "col"
table["aria-label"] = "各生产环节的评估指标、含义、计算方法和标准基线"
digest = sha256(source.read_bytes()).hexdigest()
main_href = quote("../0001-douyin-ai-studio/06-验收标准与测试方案.html", safe="/.")
css = """
:root{font-family:system-ui,'Microsoft YaHei',sans-serif;color:#202126;background:#f7f8fa}
*{box-sizing:border-box}body{margin:0;padding:28px 32px}main{max-width:1640px;margin:auto}
header{margin-bottom:20px}h1{font-size:27px;line-height:1.4;margin:8px 0 12px}
p{font-size:14px;line-height:1.8;margin:6px 0}a{color:#002fa7}small{color:#666}
.eyebrow{font-size:12px;color:#002fa7;letter-spacing:.08em}.note{color:#555;max-width:1200px}
.table-wrap{overflow-x:auto;background:white;border:1px solid #d9dde5}
table{width:100%;min-width:1060px;border-collapse:separate;border-spacing:0;font-size:14px;line-height:1.65;table-layout:fixed}
thead th{background:#eef1f5;text-align:left;font-size:13px;position:sticky;top:0;z-index:1}
th,td{padding:13px 15px;border-right:1px solid #e0e4eb;border-bottom:1px solid #e0e4eb;vertical-align:top;overflow-wrap:anywhere}
th:nth-child(1){width:8%}th:nth-child(2){width:17%}th:nth-child(3){width:19%}th:nth-child(4){width:31%}th:nth-child(5){width:25%}
th:last-child,td:last-child{border-right:0}tbody tr:last-child td{border-bottom:0}
tr.core td:nth-child(2){color:#002fa7;background:#eef3ff}tr.stage-start td{border-top:1px solid #c7ceda}
td:first-child{font-weight:600;color:#555;font-size:13px}code{font-size:.95em}
footer{padding:18px 0;font-size:12px;line-height:1.8;color:#666}
@media(max-width:700px){body{padding:18px 14px}h1{font-size:23px}.table-wrap{border-radius:0}}
@media print{@page{size:A3 landscape;margin:10mm}body{padding:0;background:white}main{max-width:none}table{min-width:0;font-size:10px;line-height:1.5}th,td{padding:7px}thead{display:table-header-group}thead th{position:static}.table-wrap{overflow:visible}tr{break-inside:avoid}a{color:inherit}}
"""
document = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="source-sha256" content="{digest}"><link rel="icon" href="data:,"><title>各环节评估指标总表</title><style>{css}</style></head>
<body><main><header><div class="eyebrow">AI 自媒体生产 · 评估标准</div>
<h1>各环节评估指标总表</h1>
<p><strong>{len(rows)} 项指标 · ★ 标出 {core} 项核心指标</strong> · <a href="{main_href}#41-评估方法">完整测法与验收用例</a></p>
<p class="note">★ 表示优先关注；“硬”必须满足，“建议”在测试前冻结，“待标定/观察”先实测。所有数值为计划基线，尚未取得本项目评测成绩。</p>
<p class="note">文案至少 3 人盲评取中位数；媒体至少 2 人逐项达标。1/2/3/4/5 分分别为不可用、需大改、基本可用、有质量、优秀。P95 为误差排序后第 ceil(0.95×n) 项；比例分母为 0 时记“无样本”。</p>
</header><div class="table-wrap" tabindex="0" aria-label="指标总表，可横向滚动">{table}</div>
<footer>字幕必须同时核对已审稿件、批准的朗读映射和最终音轨；画面全片检查，嘴型/字幕误差逐片报告。失败与未完成任务不能从成功率中剔除。TP/FP/FN/TN 分别为正确检出、误报、漏报、正确排除重复。
<br>来源：{escape(source.name)} 第 4.2 节；本页由同一表格自动导出，修改请编辑源文档。保存原有 61 个验收用例，不以本表取代实际验收。</footer></main></body></html>'''
(folder / "评估指标总表.html").write_text(document, encoding="utf-8")
print(f"Generated one table: {len(rows)} rows, {core} core metrics; source SHA-256 {digest}")
