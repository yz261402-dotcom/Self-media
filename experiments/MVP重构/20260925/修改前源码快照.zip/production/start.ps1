# 一键启动工作台（后端 8000 + 前端 5173）
# 用法：在 PowerShell 中执行 .\start.ps1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'frontend'

Write-Host '启动后端 FastAPI (127.0.0.1:8000)...'
$py = Join-Path $backend '.venv\Scripts\python.exe'
if (-not (Test-Path $py)) { $py = 'python' }
Start-Process -FilePath $py -ArgumentList '-m','uvicorn','app.main:app','--host','127.0.0.1','--port','8000' -WorkingDirectory $backend

Start-Sleep -Seconds 3

Write-Host '启动前端 Vite (127.0.0.1:5173)...'
$node = (Get-Command node).Source
Start-Process -FilePath $node -ArgumentList 'node_modules/vite/bin/vite.js','--port','5173','--host','127.0.0.1' -WorkingDirectory $frontend

Start-Sleep -Seconds 3
Write-Host '打开 http://127.0.0.1:5173'
Start-Process 'http://127.0.0.1:5173'
