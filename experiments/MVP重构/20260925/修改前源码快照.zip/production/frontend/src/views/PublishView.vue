<script setup lang="ts">
import { computed } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'

const store = useStudioStore()
const PLATFORMS = [
  { name: '抖音', need: '账号授权 + 应用权限 + 官方投稿接口' },
  { name: 'B 站', need: '投稿 API 权限与稿件字段能力' },
  { name: '快手', need: '开放平台权限与视频发布能力' },
  { name: '小红书', need: '官方发布与数据权限待核' },
  { name: '微信视频号', need: '发布接口与主体资格待核' },
]
const pkg = computed(() => store.pkg)
</script>

<template>
  <div>
    <div class="page-head">
      <h1>发布</h1>
      <StatusBadge text="planned" />
    </div>
    <div class="page-sub">未取得官方权限前不提供自动发布，未实现的操作一律禁用</div>

    <div class="section">
      <Note kind="warn" label="范围">
        V1 生产闭环在「视频合成」的预览与下载处结束。自动发布需逐平台取得官方权限后独立验收；
        本地定时器、上传成功或草稿包都不能当作「已发布」。
      </Note>
    </div>

    <div class="section">
      <div class="section-head"><span class="section-title">当前可交付状态</span></div>
      <div class="panel">
        <template v-if="pkg">
          <div class="panel-head">
            <span style="font-weight: 600">{{ pkg.title }}</span>
            <div class="topbar-spacer"></div>
            <StatusBadge :text="pkg.state" />
          </div>
          <div class="panel-pad">
            <dl class="kv">
              <dt>包 ID</dt><dd class="mono">{{ pkg.id }}</dd>
              <dt>Manifest</dt><dd class="mono">{{ pkg.manifest_digest }}</dd>
            </dl>
          </div>
        </template>
        <div v-else class="empty">当前作品还没有处于 ready 的发布包。</div>
      </div>
    </div>

    <div class="section">
      <div class="section-head">
        <span class="section-title">平台能力</span>
        <span class="section-note">逐个核验，不默认相同</span>
      </div>
      <div class="panel">
        <table>
          <thead><tr><th>平台</th><th>所需条件</th><th class="tight">状态</th><th class="tight">操作</th></tr></thead>
          <tbody>
            <tr v-for="p in PLATFORMS" :key="p.name">
              <td style="font-weight: 600">{{ p.name }}</td>
              <td class="muted" style="font-size: 12px">{{ p.need }}</td>
              <td class="tight"><StatusBadge text="planned" /></td>
              <td class="tight"><button class="sm" disabled>连接并发布</button></td>
            </tr>
          </tbody>
        </table>
        <div class="panel-pad" style="border-top: 1px solid var(--line)">
          <div class="btn-row">
            <button class="sm" disabled>设置排期提醒</button>
            <button class="sm" disabled>人工投稿回填</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
