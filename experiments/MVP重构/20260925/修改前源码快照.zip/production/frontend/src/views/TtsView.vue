<script setup lang="ts">
import { computed, ref } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'

const store = useStudioStore()
const sampleText = ref('大家好，今天我们用三分钟讲清楚一个容易被忽略的细节。')

const scriptReady = computed(() => store.scriptReady)
const previews = computed(() => store.audios.filter((a) => a.kind === 'preview'))
const fulls = computed(() => store.audios.filter((a) => a.kind === 'full'))
const dur = (ms: number) => (Math.round(ms / 100) / 10).toFixed(1)

// 可确认性来自后端门禁，不在前端自己放宽：
// 占位产物（is_mock）与硬门禁失败项都不允许被确认为最终音频。
const confirmBlock = (a: { is_mock?: boolean; confirmed?: boolean; checks: { code: string; outcome: string; hard_gate: boolean; message: string }[] }) => {
  if (a.confirmed) return '已确认为最终音频'
  if (a.is_mock) return '占位音频不可确认：需接入真实 Provider 后重新合成'
  const hard = a.checks.filter((c) => c.hard_gate && c.outcome !== 'pass')
  if (hard.length) return `硬门禁未通过（${hard.map((c) => c.code).join('、')}）`
  return ''
}
</script>

<template>
  <div>
    <div class="page-head">
      <h1>语音配音</h1>
      <StatusBadge text="available" />
    </div>
    <div class="page-sub">先短句试听选声，再合成全文；确认后音频冻结</div>

    <div v-if="!scriptReady" class="section">
      <Note kind="warn" label="前置未满足">
        还没有已采用且通过审核的稿件。请先到「口播稿」选定一稿，全文配音以它为唯一正文来源。
      </Note>
    </div>

    <div class="grid-2 section">
      <div>
        <div class="section-head">
          <span class="section-title">音色与试听</span>
          <span class="section-note">用同一短句比较不同声音</span>
        </div>
        <div class="panel">
          <div class="panel-pad" style="border-bottom: 1px solid var(--line)">
            <label class="field" style="margin-bottom: 0">
              <span>基准短句</span>
              <textarea v-model="sampleText" style="min-height: 56px"></textarea>
            </label>
          </div>
          <table>
            <thead>
              <tr><th>音色</th><th class="tight">定版</th><th class="tight">操作</th></tr>
            </thead>
            <tbody>
              <tr v-for="v in store.voices" :key="v.id" :class="{ hl: store.currentWork?.voice_asset_id === v.id }">
                <td>
                  <div style="font-weight: 600">{{ v.name }}</div>
                  <div class="faint mono">{{ v.provider }} / {{ v.model }}</div>
                </td>
                <td class="tight"><StatusBadge :text="v.approval_state" /></td>
                <td class="tight">
                  <div class="btn-row">
                    <button class="sm" :disabled="store.busy !== ''" @click="store.voicePreview(v.id, sampleText)">
                      试听
                    </button>
                    <button
                      class="sm"
                      :disabled="store.currentWork?.voice_asset_id === v.id || v.approval_state !== 'approved'"
                      @click="store.selectVoice(v.id)"
                    >
                      {{ store.currentWork?.voice_asset_id === v.id ? '已绑定' : '选用' }}
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <div v-if="previews.length" style="border-top: 1px solid var(--line); padding: 8px 14px">
            <div v-for="a in previews" :key="a.id" class="row" style="padding: 3px 0">
              <span class="st ok">试听 {{ dur(a.duration_ms) }}s</span>
              <span class="faint mono">{{ a.voice_asset_id }}</span>
            </div>
            <div class="faint" style="font-size: 10.5px">试听片不能当作最终音频</div>
          </div>
        </div>
      </div>

      <div>
        <div class="section-head">
          <span class="section-title">全文合成</span>
          <span class="section-note">音色：{{ store.currentVoice?.name ?? '未选择' }}</span>
        </div>
        <div class="panel">
          <div class="panel-pad">
            <button class="primary" :disabled="!scriptReady || store.busy !== ''" @click="store.synthesizeFull()">
              合成全文音频
            </button>
          </div>

          <template v-if="fulls.length">
            <div class="divider"></div>
            <div v-for="a in fulls" :key="a.id" style="padding: 14px 16px">
              <div class="row" style="margin-bottom: 8px">
                <span style="font-weight: 600">全文音频 {{ dur(a.duration_ms) }}s</span>
                <StatusBadge v-if="a.is_mock" text="mock" />
                <div class="topbar-spacer"></div>
                <StatusBadge :text="a.confirmed ? 'approved' : 'pending'" />
              </div>

              <audio v-if="a.url" :src="a.url" controls style="width: 100%; margin-bottom: 10px"></audio>
              <div v-else class="faint" style="font-size: 11.5px; margin-bottom: 10px">
                当前模式未返回可播放音频字节（不伪造音频；真实 Provider 接入后此处播放最终 WAV）
              </div>

              <table>
                <tbody>
                  <tr v-for="ck in a.checks" :key="ck.code">
                    <td class="mono tight">{{ ck.code }}</td>
                    <td class="tight"><StatusBadge :text="ck.outcome" /></td>
                    <td class="muted" style="font-size: 11.5px">{{ ck.message }}</td>
                  </tr>
                </tbody>
              </table>

              <div style="margin-top: 10px">
                <button
                  class="primary sm"
                  :disabled="!!confirmBlock(a) || store.busy !== ''"
                  @click="store.confirmAudio(a.id)"
                >
                  {{ a.confirmed ? '已确认为最终音频' : '试听并确认' }}
                </button>
                <span v-if="confirmBlock(a)" class="faint" style="margin-left: 10px; font-size: 11.5px">
                  {{ confirmBlock(a) }}
                </span>
              </div>
            </div>
          </template>
          <div v-else class="empty">尚未合成全文音频。</div>
        </div>
      </div>
    </div>

    <div class="section">
      <Note label="约束">
        术语（RAG / API / LLM）读法需一致，表达标记不能被朗读出来；不支持的情绪要明确提示，不允许静默忽略。
        换声或改正文都会使下游口型与字幕失效并重做。
      </Note>
    </div>
  </div>
</template>
