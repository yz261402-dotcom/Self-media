<script setup lang="ts">
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'

const METRICS = [
  { name: '播放量', source: '平台数据权限未取得' },
  { name: '完播率', source: '各平台是否开放及分母定义待核' },
  { name: '点赞量', source: '平台数据权限未取得' },
  { name: '收藏量', source: '平台数据权限未取得' },
]
</script>

<template>
  <div>
    <div class="page-head">
      <h1>指标监控</h1>
      <StatusBadge text="planned" />
    </div>
    <div class="page-sub">未接入任何平台数据，不展示估算值或补零数据</div>

    <div class="section">
      <Note label="口径">
        不可获取与真实零值必须区分：未授权、未接入、不可获取显示为「不可获取」，不能记成 0。
      </Note>
    </div>

    <div class="section">
      <div class="section-head"><span class="section-title">计划指标</span></div>
      <div class="panel">
        <table>
          <thead><tr><th>指标</th><th>数值</th><th>统计窗口</th><th>来源</th></tr></thead>
          <tbody>
            <tr v-for="m in METRICS" :key="m.name">
              <td style="font-weight: 600">{{ m.name }}</td>
              <td class="faint">不可获取</td>
              <td class="faint">—</td>
              <td class="muted" style="font-size: 12px">{{ m.source }}</td>
            </tr>
          </tbody>
        </table>
        <div class="panel-pad" style="border-top: 1px solid var(--line)">
          <div class="btn-row">
            <button class="sm" disabled>立即采集</button>
            <button class="sm" disabled>导入后台数据</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
