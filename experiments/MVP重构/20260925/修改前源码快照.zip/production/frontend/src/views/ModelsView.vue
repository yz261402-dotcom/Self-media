<script setup lang="ts">
import { computed } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'

const store = useStudioStore()
const providers = computed(() => store.capabilities?.providers ?? [])
const PURPOSE: Record<string, string> = {
  deepseek: '文本决策 / 写稿 / 审核',
  'gpt-image-2': '人像生成与参考编辑',
  minimax: 'TTS 语音合成',
  m2_worker: '数字人口播（GPU Worker）',
}
</script>

<template>
  <div>
    <div class="page-head">
      <h1>领域模型选择</h1>
      <StatusBadge text="developing" />
    </div>
    <div class="page-sub">V1 只提供服务端配置状态与脱敏报错，可编辑配置页后续开放</div>

    <div class="section">
      <div class="section-head"><span class="section-title">已登记 Provider</span><span class="section-note">脱敏显示</span></div>
      <div class="panel">
        <table>
          <thead><tr><th>用途</th><th>Provider / 模型</th><th class="tight">核验</th><th>说明</th></tr></thead>
          <tbody>
            <tr v-for="p in providers" :key="p.provider">
              <td>{{ PURPOSE[p.provider] ?? p.purpose }}</td>
              <td class="mono">{{ p.provider }}<br />{{ p.model }}</td>
              <td class="tight">
                <StatusBadge
                  :text="p.validation_state === 'usable' ? 'approved' : p.validation_state === 'invalid' ? 'rejected' : 'pending'"
                />
              </td>
              <td class="muted" style="font-size: 12px">{{ p.detail }}</td>
            </tr>
          </tbody>
        </table>
        <div class="panel-pad" style="border-top: 1px solid var(--line)">
          <div class="btn-row">
            <button class="sm" disabled>新增模型配置</button>
            <button class="sm" disabled>编辑 URL / 模型名</button>
          </div>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="section-head"><span class="section-title">错误分类要求</span></div>
      <div class="panel panel-pad">
        <ul class="tight">
          <li>密钥错误、余额不足、模型不存在、能力不支持、网络故障必须给出不同提示</li>
          <li>缺配置在付费前阻断；连接检查可能收费时先明确费用并纳入预算</li>
          <li>用户错误提示不得包含 Provider 类名、堆栈或服务商内部状态</li>
        </ul>
        <Note style="margin-top: 12px">
          密钥由服务端保存，不在浏览器直接调用中暴露，不写进作品或日志。填入 URL / Key / 模型名不代表具备适配能力。
        </Note>
      </div>
    </div>
  </div>
</template>
