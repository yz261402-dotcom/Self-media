<script setup lang="ts">
import { computed, ref } from 'vue'
import { useStudioStore } from '@/stores/studio'
import { api } from '@/api'
import type { AvatarAssetView, AvatarPolicyOptions, IdentityReadiness, QualifyProgress } from '@/api/types'
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'
import QualifySteps from '@/components/QualifySteps.vue'

const store = useStudioStore()

const OUTFITS = [
  { v: 'news_suit', t: '新闻套装' },
  { v: 'knitwear', t: '针织衫' },
  { v: 'shirt', t: '衬衫' },
  { v: 'blazer', t: '西装外套' },
]
const BACKGROUNDS = [
  { v: 'studio', t: '演播室' },
  { v: 'classroom', t: '教室' },
  { v: 'tech_scene', t: '科技场景' },
  { v: 'news_studio', t: '新闻演播厅' },
  { v: 'ai_lab', t: 'AI 实验室' },
]

const outfit = ref('news_suit')
const background = ref('studio')
const newIdentity = ref({ gender: '女', age: '22 岁左右', appearance: '', free_text: '' })
const candidates = ref<any[]>([])
const motionKey = ref('')

const current = computed(() => store.currentIdentity)
const work = computed(() => store.currentWork)

/** 只列**已获准的参考**：目录里有键但没有已审参考的动作，选了必然被
 *  MOTION_NOT_APPROVED 拒掉，不该出现在可选列表里。 */
const approvedMotions = computed(() => store.motionCatalog?.approved ?? [])

/** 作品上已登记的动作意图（底片读的就是它）。 */
const currentIntent = computed(() => work.value?.motion_intent ?? null)

async function adoptMotion() {
  const m = approvedMotions.value.find((x) => x.motion_key === motionKey.value)
  await store.adoptMotion(motionKey.value, m?.id)
}

async function genCandidates() {
  // 真实出图：调用文生图服务，返回的候选仍是"待审"——出图不等于合格。
  // 失败时不 swallow：guard 会把后端的 409/422 原因显示出来（含是否可重试）。
  const r = await store.guard('生成候选并出图', () =>
    api.createIdentityCandidateWithImage({
      gender: newIdentity.value.gender,
      age: newIdentity.value.age,
      appearance: newIdentity.value.appearance,
      free_text: newIdentity.value.free_text,
    }),
  )
  if (r) {
    candidates.value = [r, ...candidates.value]
    // 重新拉列表 + 就绪度：新候选要立刻出现在分组里，并带上"还缺什么"。
    await store.reloadIdentities()
  }
}

// ---------------- 定版链：审核 → 参考依据 → 权属确认 → 冻结 ----------------
// 这四步都是"人来做判定"，系统只负责留痕。因此界面上的每个按钮都要求
// 先显式勾选，不做"点一下就等于看见了"的默认同意。

const inspectId = ref('')
const readiness = ref<IdentityReadiness | null>(null)
const heroAssets = ref<AvatarAssetView[]>([])
const policyOptions = ref<AvatarPolicyOptions | null>(null)

const reviewAck = ref(false)
const reviewMethod = ref('人工目检：与期望人设一致')
const policyMode = ref<'multi_view' | 'hero_only'>('hero_only')
const policyReason = ref('')
const policyAck = ref<string[]>([])
const attestBasis = ref('')
const attestAck = ref(false)

const inspecting = computed(
  () =>
    store.identities.find((i) => i.id === inspectId.value) ??
    store.discardedIdentities.find((i) => i.id === inspectId.value) ??
    null,
)

// ---------------- 草稿候选：丢弃 / 恢复 ----------------
// 丢弃**不是删除**：后端只把它移出工作列表并留痕，可恢复。理由必填、点两下确认，
// 不做"点一下就等于同意丢弃"——丢错人的代价比多点一次高得多。
const discardId = ref('')
const discardReason = ref('')
const showDiscarded = ref(false)

/** 该人物"还缺什么"：直接取后端就绪清单的 reasons，界面不自己另编一套说法。 */
function reasonsFor(id: string): string[] {
  return store.readinessMap[id]?.reasons ?? []
}

/**
 * 定版四步进度。同样只取后端结论：界面若自行推断"下一步点哪个"，
 * 就会出现"界面让人点、后端照样拒"的落差——这正是用户此前觉得根本不能用的原因。
 */
function qualifyFor(id: string): QualifyProgress | null {
  return store.readinessMap[id]?.qualify ?? null
}

/** 草稿行的主按钮文案：直接写明走到第几步，用户不必展开面板才知道。 */
function draftActionLabel(id: string): string {
  const q = qualifyFor(id)
  if (!q) return '去定版'
  return `走定版（${q.done_count} / ${q.total} 步）`
}

/**
 * 「已定版」分组只保证**可以被选用**（后端选择端点的门槛是 approval_state）。
 * 它不等于"进得了生产"——生产另有就绪清单。两者混为一谈，会让人以为点了选用就能出片。
 */
function readyFor(id: string): boolean {
  return store.readinessMap[id]?.ready ?? false
}

function readinessSummary(id: string): string {
  const q = qualifyFor(id)
  if (q && q.frozen && q.closed_incomplete) return '已冻结，但四步留痕不全'
  return '就绪清单未通过'
}

function startDiscard(id: string) {
  discardId.value = id
  discardReason.value = '试跑出来的草稿，不要了'
}

function cancelDiscard() {
  discardId.value = ''
  discardReason.value = ''
}

async function confirmDiscard(id: string) {
  await store.discardCandidate(id, discardReason.value)
  cancelDiscard()
  if (inspectId.value === id) inspectId.value = ''
}
const hero = computed(() => heroAssets.value.find((a) => a.kind === 'hero') ?? null)
const heroImageUrl = computed(() =>
  hero.value?.storage_uri ? `/api/v1/media?uri=${encodeURIComponent(hero.value.storage_uri)}` : '',
)
// 身份基准摘要就用原图哈希：同一张图里"是同一个人"的唯一可核对依据。
const derivedDigest = computed(() => hero.value?.file_hash ?? '')
const heroReviewed = computed(() => hero.value?.approval_state === 'approved')
const policyDeclared = computed(() => !!inspecting.value?.reference_policy)
/** 已冻结即链路闭合：四步不可再改，界面必须停手，不能给出点了必被拒的按钮。 */
const isFrozen = computed(() => !!inspecting.value?.frozen)
const canFreeze = computed(
  () =>
    !isFrozen.value &&
    heroReviewed.value &&
    policyDeclared.value &&
    !!derivedDigest.value &&
    !!inspecting.value?.license_id,
)

async function openInspect(id: string) {
  inspectId.value = id
  readiness.value = null
  heroAssets.value = []
  const row = store.identities.find((x) => x.id === id)
  policyMode.value = (row?.reference_policy?.mode as 'multi_view' | 'hero_only') ?? 'hero_only'
  policyReason.value = row?.reference_policy?.reason ?? ''
  policyAck.value = [...(row?.reference_policy?.acknowledged ?? [])]
  reviewAck.value = false
  attestAck.value = false
  attestBasis.value = ''
  if (!policyOptions.value) policyOptions.value = await api.avatarPolicyOptions()
  await refreshInspect()
}

async function refreshInspect() {
  const id = inspectId.value
  const [r, assets] = await Promise.all([
    api.identityReadiness(id),
    api.listIdentityAssets(id),
  ])
  readiness.value = r
  heroAssets.value = assets
  // 走完任一步都要重取分组与就绪度：刚定版的身份要立刻移到"可用"分组，
  // 而"还缺什么"必须跟着变，否则界面显示的还是上一步的旧清单。
  await store.reloadIdentities()
}

function togglePolicyAck(text: string) {
  policyAck.value = policyAck.value.includes(text)
    ? policyAck.value.filter((x) => x !== text)
    : [...policyAck.value, text]
}

async function submitReview() {
  if (!hero.value) return
  const r = await store.guard('登记身份审核', () =>
    api.reviewIdentityAsset(inspectId.value, hero.value!.id, {
      outcome: 'pass',
      identity_digest: derivedDigest.value,
      method: reviewMethod.value,
    }),
  )
  if (r) await refreshInspect()
}

async function submitPolicy() {
  const r = await store.guard('声明参考依据', () =>
    api.setReferencePolicy(inspectId.value, {
      mode: policyMode.value,
      reason: policyReason.value,
      acknowledged: policyMode.value === 'hero_only' ? policyAck.value : [],
    }),
  )
  if (r) await refreshInspect()
}

async function submitAttest() {
  const lic = inspecting.value?.license_id
  if (!lic || !policyOptions.value) return
  const r = await store.guard('确认商用范围', () =>
    api.attestLicense(lic, attestBasis.value, policyOptions.value!.attest_token),
  )
  if (r) await refreshInspect()
}

async function submitFreeze() {
  if (!hero.value || !inspecting.value) return
  const r = await store.guard('冻结定版', () =>
    api.freezeIdentity(inspectId.value, {
      hero_asset_id: hero.value!.id,
      identity_digest: derivedDigest.value,
      license_id: inspecting.value!.license_id ?? '',
    }),
  )
  if (r) await refreshInspect()
}
</script>

<template>
  <div>
    <div class="page-head">
      <h1>人物形象</h1>
      <StatusBadge text="available" />
    </div>
    <div class="page-sub">准备人物资产与表演要求，本页不生成嘴型视频</div>

    <div class="section">
      <div class="section-head">
        <span class="section-title">人物库</span>
        <span class="section-note">顺序是「先定版，后选用」，不能反</span>
      </div>

      <!-- 三件事的关系。此前「选用」与「审核 / 定版」是两个并排的按钮、四步是四块
           同质表单，全靠用户自己悟：谁是前提、冻结是什么、点完往哪走。这里先说清关系，
           下面的表格与面板才读得懂。 -->
      <div class="guide">
        <div class="guide-head">这一页有三件事，不是同一个动作的三个叫法</div>
        <div class="guide-grid">
          <div class="guide-item">
            <div class="guide-title">
              <span class="guide-n">1</span>定版 <span class="faint">· 作用在「这个人」身上 · 4 步</span>
            </div>
            <div class="guide-body">
              原片身份审核 → 声明参考依据 → 商用范围确认 → 冻结定版。
              走完，这个人才<strong>有资格</strong>被使用。没定版的人，任何作品都选不了它——
              选择端点会直接拒绝，不是界面藏了按钮。
            </div>
          </div>
          <div class="guide-item">
            <div class="guide-title">
              <span class="guide-n">2</span>选用 <span class="faint">· 作用在「当前作品」身上 · 1 下</span>
            </div>
            <div class="guide-body">
              从<strong>已定版</strong>的人里挑一个，绑给当前作品。一个作品只用一个人。
              它不改动人物本身，只是声明"这条视频用这个人"。所以定版是选用的前提，
              两者不是并列的两条路。
            </div>
          </div>
          <div class="guide-item">
            <div class="guide-title">
              <span class="guide-n">3</span>冻结 <span class="faint">· 就是定版的第 4 步</span>
            </div>
            <div class="guide-body">
              冻结不是另一个动作、也不是"发布"。它把这一版焊死：原图不可替换、依据口径不可修改，
              此后任何作品都能直接选它。定版前一切可改、定版后不可改，所以顺序是
              <strong>先改完，再冻结</strong>。要换人只能新建版本，旧作品仍用旧版本。
            </div>
          </div>
        </div>
        <div class="guide-foot">
          为什么冻结要做成不可逆：这个人一旦进了成片，脸就是他。如果定版后还能随手换图，
          等于"已发布视频里的脸可以事后被替换"，来源链就断了、无法追溯。
        </div>
      </div>

      <!-- 下一步：选完人物之后往哪走，直接写在这里。此前只有侧栏底部一行浅灰小字，
           选完"选用"就没了下文，用户只能靠猜。 -->
      <Note
        :kind="store.nextStep.key === 'identity' ? 'warn' : 'ok'"
        :label="`当前作品：${work?.name ?? '未选择'}`"
        style="margin-bottom: 14px"
      >
        <div class="row" style="gap: 12px; flex-wrap: wrap">
          <div style="flex: 1; min-width: 220px">
            <div style="font-weight: 600">{{ store.nextStep.title }}</div>
            <div class="faint" style="font-size: 12.5px; margin-top: 2px">
              {{ store.nextStep.detail }}
            </div>
          </div>
          <router-link v-if="store.nextStep.to && store.nextStep.to !== '/avatar'" :to="store.nextStep.to">
            <button class="sm primary">{{ store.nextStep.label }} →</button>
          </router-link>
        </div>
      </Note>

      <!-- ① 已定版：可被作品选用。注意"可选用"≠"进得了生产"，两件事分列显示。 -->
      <div class="panel">
        <div class="panel-head">
          <span style="font-weight: 600">已定版（可以被作品选用）</span>
          <span class="spacer"></span>
          <span class="faint" style="font-size: 12px">{{ store.usableIdentities.length }} 个</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>人物</th>
              <th>人设</th>
              <th>生产就绪清单</th>
              <th class="tight">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="i in store.usableIdentities"
              :key="i.id"
              :class="{ hl: work?.identity_id === i.id }"
            >
              <td>
                <div class="row" style="gap: 8px">
                  <span style="font-weight: 600; font-size: 14px">{{ i.name }}</span>
                  <span v-if="i.is_preset" class="tag">初始预设</span>
                </div>
                <div class="faint mono">{{ i.id }}</div>
              </td>
              <td>
                {{ i.persona }}
                <div class="faint" style="font-size: 12.5px; margin-top: 2px">{{ i.note }}</div>
              </td>
              <td>
                <StatusBadge v-if="readyFor(i.id)" text="ready" />
                <template v-else>
                  <StatusBadge :text="readinessSummary(i.id)" kind="warn" />
                  <!-- 就绪清单未过的原因逐条列出：选用能成，但出片会被拒，不能不说 -->
                  <div class="stack" style="gap: 2px; margin-top: 4px">
                    <div v-for="r in reasonsFor(i.id)" :key="r" class="faint" style="font-size: 11.5px">
                      · {{ r }}
                    </div>
                  </div>
                </template>
              </td>
              <td class="tight">
                <button
                  class="sm primary"
                  :disabled="work?.identity_id === i.id || !work || store.busy !== ''"
                  @click="store.selectIdentity(i.id)"
                >
                  {{ work?.identity_id === i.id ? '本作品已选' : '本作品用它' }}
                </button>
                <div v-if="!work" class="faint" style="font-size: 10.5px; margin-top: 3px">
                  先创建作品才能选用
                </div>
                <button class="sm" style="margin-top: 3px" @click="openInspect(i.id)">
                  {{ inspectId === i.id ? '收起' : '查看定版记录' }}
                </button>
              </td>
            </tr>
            <tr v-if="!store.usableIdentities.length">
              <td colspan="4" class="faint">
                还没有已定版的人物。先在下面「草稿候选」里点「走定版」完成四步，它才会出现在这里。
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- ② 草稿候选：未定版 → 后端不允许任何作品选用它。要么走完四步，要么丢弃。 -->
      <div class="panel" style="margin-top: 14px">
        <div class="panel-head">
          <span style="font-weight: 600">草稿候选（未定版，任何作品都不能选它）</span>
          <span class="spacer"></span>
          <span class="faint" style="font-size: 12px">{{ store.draftIdentities.length }} 个</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>人物</th>
              <th>下一步做什么（来自后端定版进度）</th>
              <th class="tight">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="i in store.draftIdentities" :key="i.id">
              <td>
                <div style="font-weight: 600; font-size: 14px">{{ i.name }}</div>
                <div class="faint mono" style="font-size: 11px">{{ i.id }}</div>
                <div v-if="i.identity_origin === 'generated'" class="faint" style="font-size: 11px">
                  由生成服务产出
                </div>
              </td>
              <td>
                <div class="stack" style="gap: 3px">
                  <!-- 先给"点哪个、第几步"，再给缺项清单：只列缺什么等于还是在让人猜 -->
                  <div style="font-size: 12.5px">
                    <template v-if="qualifyFor(i.id)">
                      <b>第 {{ (qualifyFor(i.id)!.done_count) + 1 }} / {{ qualifyFor(i.id)!.total }} 步</b>
                      <span class="muted">
                        ·
                        {{
                          qualifyFor(i.id)!.steps.find((s) => s.key === qualifyFor(i.id)!.current)?.label ??
                          '四步均已完成，只差定版登记'
                        }}
                      </span>
                    </template>
                    <template v-else>去定版面板查看该走到哪一步</template>
                  </div>
                  <div v-if="reasonsFor(i.id).length" class="stack" style="gap: 2px">
                    <div v-for="r in reasonsFor(i.id)" :key="r" class="faint" style="font-size: 11.5px">
                      · {{ r }}
                    </div>
                  </div>
                  <div v-else class="faint" style="font-size: 11.5px">
                    就绪清单未报缺项，展开面板即可完成最后一步。
                  </div>
                </div>
              </td>
              <td class="tight">
                <button class="sm primary" @click="openInspect(i.id)">
                  {{ inspectId === i.id ? '收起' : draftActionLabel(i.id) }}
                </button>

                <!-- 丢弃要写理由，且要点两下：不做"点一下就等于同意丢弃" -->
                <template v-if="discardId === i.id">
                  <div style="margin-top: 6px; min-width: 190px">
                    <input v-model="discardReason" type="text" placeholder="丢弃理由（必填）" />
                    <div class="row" style="gap: 6px; margin-top: 5px">
                      <button class="sm" @click="cancelDiscard">取消</button>
                      <button
                        class="sm primary"
                        :disabled="!discardReason.trim() || store.busy !== ''"
                        @click="confirmDiscard(i.id)"
                      >
                        确认丢弃
                      </button>
                    </div>
                  </div>
                </template>
                <button v-else class="sm danger" style="margin-top: 3px" @click="startDiscard(i.id)">
                  丢弃这个候选
                </button>
              </td>
            </tr>
            <tr v-if="!store.draftIdentities.length">
              <td colspan="3" class="faint">没有待处理的草稿候选。</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- ③ 已丢弃：只是移出工作列表，记录仍在，随时可恢复 -->
      <div v-if="store.discardedIdentities.length" class="panel" style="margin-top: 14px">
        <div class="panel-head">
          <span style="font-weight: 600">已丢弃（{{ store.discardedIdentities.length }} 个）</span>
          <span class="spacer"></span>
          <button class="sm" @click="showDiscarded = !showDiscarded">
            {{ showDiscarded ? '收起' : '展开' }}
          </button>
        </div>
        <div v-if="!showDiscarded" class="faint" style="padding: 0 22px 16px; font-size: 12.5px">
          丢弃不是删除：人设、原图、审核记录都还在，随时可以把候选放回来。
        </div>
        <table v-else>
          <thead>
            <tr>
              <th>人物</th>
              <th>丢弃理由</th>
              <th class="tight">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="i in store.discardedIdentities" :key="i.id">
              <td>
                <div style="font-weight: 600; font-size: 14px">{{ i.name }}</div>
                <div class="faint mono" style="font-size: 11px">{{ i.id }}</div>
              </td>
              <td class="faint" style="font-size: 12.5px">
                {{ i.discard_reason || '未记录' }}
                <div style="font-size: 11.5px">
                  {{ i.discarded_by || '未记录' }} · {{ (i.discarded_at ?? '').slice(0, 19).replace('T', ' ') }}
                </div>
              </td>
              <td class="tight">
                <button class="sm" :disabled="store.busy !== ''" @click="store.restoreCandidate(i.id)">
                  恢复
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>


      <!-- 定版链：四步都要求人显式确认，系统不替人下结论 -->
      <div v-if="inspecting" class="panel panel-pad" style="margin-top: 12px">
        <div class="row" style="margin-bottom: 4px">
          <span style="font-weight: 600">{{ inspecting.name }}</span>
          <span class="tag mono">{{ inspecting.id }}</span>
          <span v-if="readiness?.limited_reference" class="tag">受限路径</span>
          <div class="topbar-spacer"></div>
          <StatusBadge :text="inspecting.approval_state" />
        </div>

        <!-- 进度与"你停在哪、为什么"来自后端；界面不自行推断 -->
        <QualifySteps :qualify="readiness?.qualify ?? null" />

        <div v-if="readiness" class="stack" style="gap: 4px; margin-top: 10px">
          <div v-if="readiness.ready" class="muted" style="font-size: 12px">
            就绪清单：全部满足，可进入生产（{{ readiness.gate }}）
          </div>
          <template v-else>
            <div class="muted" style="font-size: 12px">
              就绪清单仍缺（这决定能不能出片，与"能不能选用"是两件事）：
            </div>
            <ul style="margin: 0; padding-left: 18px">
              <li v-for="r in readiness.reasons" :key="r" class="faint" style="font-size: 11.5px">{{ r }}</li>
            </ul>
          </template>
        </div>

        <!-- 冻结状态由上面的四步组件表达（已完成 / 留痕不全各有说法），此处只在
             拿不到进度数据时兜底，避免同一句"已冻结"在眼前说两遍。 -->
        <div v-if="isFrozen && !readiness?.qualify" class="frozen-bar">
          该人物<strong>已定版并冻结</strong>：四步的留痕已封存，不可再修改。
          要换人或换图，请走「新建版本」，旧作品仍引用旧版本。
        </div>

        <div class="divider" style="margin: 12px 0"></div>

        <!-- 第 1 步：原片身份审核 -->
        <div class="row" style="margin-bottom: 5px">
          <span style="font-weight: 600; font-size: 13px">1 · 定妆原片身份审核</span>
          <div class="topbar-spacer"></div>
          <StatusBadge :text="hero ? hero.approval_state : 'missing'" />
        </div>
        <div v-if="!hero" class="faint" style="font-size: 11.5px">该人物还没有定妆原片资产。</div>
        <template v-else>
          <img
            v-if="heroImageUrl"
            :src="heroImageUrl"
            :alt="inspecting.name"
            style="width: 100%; max-width: 200px; border-radius: 8px; display: block"
          />
          <div class="faint mono" style="font-size: 11px; margin-top: 4px">
            {{ hero.width }}×{{ hero.height }} · {{ (hero.file_hash || '无哈希').slice(0, 19) }}…
          </div>
          <div v-if="hero.is_mock" class="faint" style="font-size: 11px">
            这是 MOCK 资产，没有真实图片与哈希，不能作为定版依据。
          </div>
          <Note v-else label="这一步要你目检">
            系统不做人脸比对（检测模型权重许可未确认，已登记 blocked）。请打开原图确认「这就是我要的人」，
            并填写你采用的核对方法。审核摘要绑定这张图的哈希，图一变结论即失效。
          </Note>
          <label class="row" style="gap: 6px; font-size: 12px; margin-top: 6px">
            <input v-model="reviewAck" type="checkbox" :disabled="hero.is_mock" />
            <span>我目检过这张原图，确认它符合我要的人设</span>
          </label>
          <label class="field" style="margin-top: 6px">
            <span>核对方法（会写进来源链）</span>
            <input v-model="reviewMethod" type="text" />
          </label>
          <button
            class="sm primary"
            :disabled="!reviewAck || hero.is_mock || store.busy !== ''"
            @click="submitReview"
          >
            登记身份审核结论
          </button>
        </template>

        <div class="divider" style="margin: 12px 0"></div>

        <!-- 第 2 步：参考依据口径 -->
        <div class="row" style="margin-bottom: 5px">
          <span style="font-weight: 600; font-size: 13px">2 · 声明参考依据口径</span>
          <div class="topbar-spacer"></div>
          <StatusBadge :text="policyDeclared ? 'declared' : 'missing'" />
        </div>
        <div class="faint" style="font-size: 11.5px; margin-bottom: 6px">
          定版前必须定下来：拿什么当「是同一个人」的依据。定版后不许再改口径。
        </div>
        <template v-if="policyOptions">
          <label
            v-for="p in policyOptions.reference_policies"
            :key="p.mode"
            class="row"
            style="gap: 6px; font-size: 12px; align-items: flex-start; margin-bottom: 4px"
          >
            <input
              v-model="policyMode"
              type="radio"
              :value="p.mode"
              :disabled="policyDeclared"
              style="margin-top: 3px"
            />
            <span>
              <b>{{ p.label }}</b>
              <span class="faint"> — {{ p.summary }}</span>
            </span>
          </label>

          <template v-if="policyMode === 'hero_only'">
            <label class="field" style="margin-top: 6px">
              <span>为什么要走受限路径（必填）</span>
              <textarea
                v-model="policyReason"
                style="min-height: 52px"
                :disabled="policyDeclared"
                placeholder="例：整张脸由文生图服务产出，不存在同一人的第二张真值"
              />
            </label>
            <div class="faint" style="font-size: 11.5px; margin: 6px 0 4px">
              代价必须逐条确认（原文由后端给出）：
            </div>
            <label
              v-for="lim in policyOptions.hero_only_limitations"
              :key="lim"
              class="row"
              style="gap: 6px; font-size: 11.5px; align-items: flex-start; margin-bottom: 3px"
            >
              <input
                type="checkbox"
                :checked="policyAck.includes(lim)"
                :disabled="policyDeclared"
                style="margin-top: 3px"
                @change="togglePolicyAck(lim)"
              />
              <span>{{ lim }}</span>
            </label>
          </template>
          <button
            class="sm primary"
            :disabled="policyDeclared || store.busy !== ''"
            @click="submitPolicy"
          >
            {{ policyDeclared ? '口径已声明（不可更改）' : '声明参考依据口径' }}
          </button>
        </template>

        <div class="divider" style="margin: 12px 0"></div>

        <!-- 第 3 步：权属人工确认 -->
        <div class="row" style="margin-bottom: 5px">
          <span style="font-weight: 600; font-size: 13px">3 · 商用范围确认</span>
          <div class="topbar-spacer"></div>
          <StatusBadge :text="inspecting.license_id ? 'recorded' : 'missing'" />
        </div>
        <template v-if="inspecting.license_id">
          <div class="faint mono" style="font-size: 11px">权属记录 {{ inspecting.license_id }}</div>
          <Note v-if="policyOptions" label="这不是核验">
            {{ policyOptions.attest_note }}
            系统不会、也无法替你判断 AI 生成物的商用范围；这一步记的是「谁、何时、依据什么」作出的判断。
          </Note>
          <label class="field" style="margin-top: 6px">
            <span>依据什么确认可以商用（必填）</span>
            <input v-model="attestBasis" type="text" placeholder="例：生成服务条款允许商用" />
          </label>
          <label class="row" style="gap: 6px; font-size: 12px; margin-bottom: 6px">
            <input v-model="attestAck" type="checkbox" />
            <span>我已知情：这是由我作出的判断，不代表已取得书面法律意见</span>
          </label>
          <button
            class="sm primary"
            :disabled="!attestAck || isFrozen || store.busy !== ''"
            @click="submitAttest"
          >
            确认商用范围
          </button>
        </template>
        <div v-else class="faint" style="font-size: 11.5px">
          该人物还没有权属记录。AI 生成的主图会自带一条「待核验」记录，先出图再回来确认。
        </div>

        <div class="divider" style="margin: 12px 0"></div>

        <!-- 第 4 步：冻结定版 -->
        <div class="row" style="margin-bottom: 5px">
          <span style="font-weight: 600; font-size: 13px">4 · 冻结定版</span>
        </div>
        <div class="faint" style="font-size: 11.5px; margin-bottom: 6px">
          这是定版的<strong>最后一步</strong>，点下去这一版就固定了：
          原图与参考资产不可被覆盖、依据口径不可修改。此后任何作品都能直接选用它；
          要换人必须显式产生新版本（旧作品仍引用旧版本）。
        </div>
        <button
          class="sm primary"
          :disabled="!canFreeze || store.busy !== ''"
          @click="submitFreeze"
        >
          {{ isFrozen ? '已冻结定版' : '冻结定版' }}
        </button>
        <div v-if="!canFreeze && !isFrozen" class="faint" style="font-size: 11px; margin-top: 4px">
          需要：第 1 步原片已审核通过 ＋ 第 2 步口径已声明 ＋ 第 3 步权属已确认。
        </div>
      </div>
    </div>

    <div class="grid-2 section">
      <div>
        <div class="section-head"><span class="section-title">新建人物</span></div>
        <div class="panel panel-pad">
          <div class="grid-2" style="gap: 10px">
            <label class="field"><span>性别</span><input v-model="newIdentity.gender" type="text" /></label>
            <label class="field"><span>成年年龄感</span><input v-model="newIdentity.age" type="text" /></label>
          </div>
          <label class="field">
            <span>外貌 / 发型 / 气质关键词</span>
            <input v-model="newIdentity.appearance" type="text" placeholder="长发、温柔、专业、亚洲面孔" />
          </label>
          <label class="field">
            <span>自由补充</span>
            <textarea
              v-model="newIdentity.free_text"
              style="min-height: 60px"
              placeholder="正面半身，演播室柔和光"
            />
          </label>
          <button class="primary" :disabled="store.busy !== ''" @click="genCandidates">生成候选并出图</button>
          <div class="faint" style="font-size: 11.5px; margin-top: 6px">
            会调用文生图服务并真实出一张图（产生费用）；出图后仍是待审，不会自动定版。
          </div>

          <template v-if="candidates.length">
            <div class="divider" style="margin: 14px 0 12px"></div>
            <div class="stack" style="gap: 10px">
              <div v-for="c in candidates" :key="c.identity?.id ?? c.id" class="panel panel-pad"
                   style="background: var(--bg)">
                <div class="row" style="margin-bottom: 6px">
                  <span style="font-weight: 600">{{ (c.identity ?? c).name }}</span>
                  <div class="topbar-spacer"></div>
                  <StatusBadge :text="(c.identity ?? c).approval_state" />
                </div>

                <img v-if="c.image_url" :src="c.image_url" :alt="(c.identity ?? c).name"
                     style="width: 100%; max-width: 220px; border-radius: 8px; display: block" />
                <div v-else-if="c.asset?.is_mock" class="empty" style="padding: 18px 0; font-size: 12px">
                  MOCK 模式没有真实图片
                </div>

                <div class="muted" style="font-size: 11.5px; margin-top: 6px">
                  {{ (c.identity ?? c).persona }}
                </div>
                <div class="faint" style="font-size: 11px; margin-top: 2px">
                  {{ (c.identity ?? c).note }}
                </div>
                <div v-if="c.asset" class="faint mono" style="font-size: 11px; margin-top: 4px">
                  {{ c.asset.width }}×{{ c.asset.height }} · {{ (c.asset.file_hash || '').slice(0, 19) }}…
                </div>
                <ul v-if="c.warnings?.length" style="margin: 8px 0 0; padding-left: 18px">
                  <li v-for="w in c.warnings" :key="w" class="faint" style="font-size: 11px">{{ w }}</li>
                </ul>
              </div>
            </div>
          </template>
        </div>
      </div>

      <div>
        <div class="section-head">
          <span class="section-title">服装 / 背景变体</span>
          <span class="section-note">当前：{{ current?.name ?? '未选择' }}</span>
        </div>
        <div class="panel panel-pad">
          <div class="grid-2" style="gap: 10px">
            <label class="field">
              <span>服装</span>
              <select v-model="outfit">
                <option v-for="o in OUTFITS" :key="o.v" :value="o.v">{{ o.t }}</option>
              </select>
            </label>
            <label class="field">
              <span>背景</span>
              <select v-model="background">
                <option v-for="b in BACKGROUNDS" :key="b.v" :value="b.v">{{ b.t }}</option>
              </select>
            </label>
          </div>
          <button
            class="primary"
            :disabled="!current || store.busy !== ''"
            @click="store.createVariant(outfit, background)"
          >
            生成变体
          </button>

          <template v-if="store.variants.length">
            <div class="divider" style="margin: 14px 0 0"></div>
            <table style="margin-top: 2px">
              <thead><tr><th>变体</th><th>服装</th><th>身份审核</th></tr></thead>
              <tbody>
                <tr v-for="v in store.variants" :key="v.id">
                  <td class="mono">{{ v.id }}</td>
                  <td class="muted">{{ v.outfit }} / {{ v.background }}</td>
                  <td><StatusBadge :text="v.approval_state" /></td>
                </tr>
              </tbody>
            </table>
          </template>
          <div v-else class="empty" style="padding: 14px 0 0">
            尚无变体。验收要求覆盖 2 套服装 × 3 类背景共 6 个组合。
          </div>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="section-head">
        <span class="section-title">表演方式</span>
        <span class="section-note">登记在作品上，不在此生成口型</span>
      </div>
      <div class="panel panel-pad">
        <template v-if="work">
          <div class="grid-2" style="gap: 10px">
            <label class="field">
              <span>动作模板（仅列该人物已获准的参考）</span>
              <select v-model="motionKey" :disabled="!approvedMotions.length">
                <option v-if="!approvedMotions.length" value="">该人物暂无已获准动作参考</option>
                <option v-for="m in approvedMotions" :key="m.id" :value="m.motion_key">
                  {{ m.label || m.motion_key }}（{{ m.motion_key }}）
                </option>
              </select>
            </label>
            <div class="field">
              <span>本作品当前登记</span>
              <div class="muted" style="font-size: 12.5px; padding-top: 6px">
                <template v-if="currentIntent && currentIntent.motion_key">
                  已登记 <b>{{ currentIntent.motion_key }}</b>
                  <template v-if="currentIntent.motion_ref_id">
                    · 绑定参考 {{ currentIntent.motion_ref_id }}
                  </template>
                </template>
                <template v-else>
                  尚未登记动作——M2 生成底片时会报「必须先选定动作」
                </template>
              </div>
            </div>
          </div>
          <div class="btn-row" style="margin-top: 10px">
            <button
              class="sm"
              :disabled="!motionKey || store.busy !== ''"
              @click="adoptMotion"
            >
              登记此动作
            </button>
            <span class="faint" style="font-size: 12px">登记后才算数：底片是从作品上读这个字段的</span>
          </div>
          <Note v-if="!approvedMotions.length" label="没有可用动作">
            受支持的动作目录里有键，但该人物名下没有一条**已获准**的动作参考，因此 M2 底片
            无法生成。这不是界面问题——缺的是一条经审的动作参考，而不是少点一次按钮。
          </Note>
          <Note v-else label="为什么必须落库">
            同一条参考一经登记即为**绑定**：同一动作键下的其他参考不得顶替，否则"登记时看到的那条动作"
            与"实际执行的动作"可能不是同一条，而这在成片上分辨不出来。
          </Note>
        </template>
        <div v-else class="muted">先选择作品——动作意图是登记在作品上的。</div>
        <Note label="能力边界">
          LivePortrait 只从动作参考迁移眼睑、表情与头姿，不会根据文本自动设计任意表演；MuseTalk
          用实际音频生成嘴型。**M2 不接受自由文本动作描述**（没有任何动作是从文字现场设计出来的）；
          当前肩颈躯干基本固定，不支持的动作必须明确说明，不能静默执行其他效果。
        </Note>
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 三件事的关系说明。放在「人物库」最前面，因为不理解关系就读不懂下面的表格。 */
.guide {
  border: 1px solid var(--line);
  border-radius: var(--r);
  background: var(--panel);
  padding: 18px 20px 16px;
  margin-bottom: 14px;
}
.guide-head {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 12px;
}
.guide-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
}
.guide-item {
  border: 1px solid var(--line);
  border-radius: var(--r-sm);
  background: var(--panel-2);
  padding: 13px 15px;
}
.guide-title {
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 6px;
  display: flex;
  align-items: baseline;
  gap: 7px;
}
.guide-n {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 19px;
  height: 19px;
  border-radius: 999px;
  background: var(--blue);
  color: #fff;
  font-size: 11px;
  font-weight: 700;
  flex: none;
  transform: translateY(2px);
}
.guide-body {
  font-size: 12.5px;
  line-height: 1.66;
  color: var(--fg-2);
}
.guide-title .faint {
  font-size: 11.5px;
  font-weight: 400;
}
.guide-foot {
  margin-top: 12px;
  padding-top: 11px;
  border-top: 1px solid var(--line);
  font-size: 12px;
  line-height: 1.66;
  color: var(--fg-3);
}

.frozen-bar {
  margin-top: 12px;
  border-left: 3px solid var(--blue);
  background: var(--blue-wash);
  border-radius: 0 var(--r-xs) var(--r-xs) 0;
  padding: 10px 14px;
  font-size: 12.5px;
  color: var(--fg-2);
  line-height: 1.62;
}
</style>
