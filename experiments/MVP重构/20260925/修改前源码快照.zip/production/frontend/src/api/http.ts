// 真实 HTTP 实现：调用 FastAPI 后端（开发期经 Vite 代理）。
import type {
  AdapterStatusView,
  AttestResult,
  AudioGateSummary,
  AvatarAssetView,
  AvatarIdentity,
  AvatarPolicyOptions,
  AvatarVariant,
  GeneratedIdentityCandidate,
  Capabilities,
  CostEstimate,
  FeatureEntry,
  FullAudioResult,
  GenerationRoute,
  IdentityReadiness,
  IdentityReadinessBrief,
  MaskEstimateResult,
  MaskSpec,
  MotionCatalogView,
  MotionIntentResult,
  PlateStatusView,
  PublishPackage,
  QueueView,
  RoutePriceView,
  ScriptBatch,
  ScriptVersion,
  SegmentPlanView,
  SubmissionListView,
  SubmissionResult,
  TalkingHeadCostView,
  TalkingHeadGateSummary,
  TalkingHeadPreflight,
  Task,
  TaskEvent,
  VariantAdmitResult,
  VariantComposeResult,
  VideoAsset,
  VideoGateView,
  VoiceAsset,
  VoicePreviewResult,
  Work,
} from './types'

export class ApiError extends Error {
  code: string
  retryable: boolean
  action: string | null
  constructor(code: string, message: string, retryable = false, action: string | null = null) {
    super(message)
    this.code = code
    this.retryable = retryable
    this.action = action
  }
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response
  try {
    res = await fetch(`/api/v1${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...init,
    })
  } catch {
    throw new ApiError('NETWORK_ERROR', '无法连接后端服务，请确认 FastAPI 已启动（127.0.0.1:8000）', true)
  }
  const text = await res.text()
  // 不能直接 JSON.parse：后端未启动时 Vite 代理会回纯文本 500（"Internal Server Error"），
  // 未捕获异常的 uvicorn 同理。裸解析会把这两种情况变成无信息的 SyntaxError。
  let data: any = null
  if (text) {
    try {
      data = JSON.parse(text)
    } catch {
      const head = text.trim().replace(/\s+/g, ' ').slice(0, 120)
      throw new ApiError(
        'NON_JSON_RESPONSE',
        `后端未返回 JSON（HTTP ${res.status}）：${head}。请确认 FastAPI 正在运行（127.0.0.1:8000）`,
        true,
        '检查后端进程是否存活，然后重试',
      )
    }
  }
  if (!res.ok) {
    const e = data?.error ?? {}
    throw new ApiError(e.code ?? 'UNKNOWN', e.message ?? `请求失败（HTTP ${res.status}）`, !!e.retryable, e.action ?? null)
  }
  return data as T
}

const post = <T>(path: string, body: unknown) =>
  req<T>(path, { method: 'POST', body: JSON.stringify(body ?? {}) })

export const httpApi = {
  getCapabilities: () => req<Capabilities>('/capabilities'),
  getFeatures: () => req<FeatureEntry[]>('/features'),

  listWorks: () => req<Work[]>('/works'),
  createWork: (input: {
    name: string
    topic: string
    content_type: string
    audience: string
    keywords: string[]
    target_duration_ms: number
  }) => post<Work>('/works', input),

  // 默认只拿"在工作列表里"的人物；已丢弃的候选要单独索取（记录没被删，只是移出视线）。
  listIdentities: (includeDiscarded = false) =>
    req<AvatarIdentity[]>(`/avatar-identities${includeDiscarded ? '?include_discarded=true' : ''}`),
  // 一次拿全部人物的"还缺什么"：逐条问会让一屏列表发 N 个请求。
  identitiesReadiness: (includeDiscarded = false) =>
    req<Record<string, IdentityReadinessBrief>>(
      `/avatar-identities/readiness${includeDiscarded ? '?include_discarded=true' : ''}`,
    ),
  // 丢弃 ≠ 删除：只移出工作列表并记录谁/何时/为什么，可 restore 回来。
  discardIdentity: (identityId: string, reason: string) =>
    post<AvatarIdentity>(`/avatar-identities/${identityId}/discard`, {
      actor: 'user_local',
      reason,
    }),
  restoreIdentity: (identityId: string) =>
    post<AvatarIdentity>(`/avatar-identities/${identityId}/restore`, { actor: 'user_local' }),
  createIdentityCandidates: (input: { gender: string; age: string; appearance: string; free_text: string }) =>
    post<AvatarIdentity[]>('/avatar-identities/candidates', input),
  createIdentityCandidateWithImage: (input: {
    gender: string
    age: string
    appearance: string
    free_text: string
    size?: string
  }) => post<GeneratedIdentityCandidate>('/avatar-identities/candidates/with-image', input),
  selectIdentity: (workId: string, identityId: string) =>
    post<Work>(`/works/${workId}/identity`, { identity_id: identityId }),

  // ---- 人物定版链：审核 → 声明参考依据 → 权属确认 → 冻结 ----
  // 每一步的"判定人"都是 user_local：系统不替人做身份判断，也不替人核发商用通行。
  identityReadiness: (identityId: string) =>
    req<IdentityReadiness>(`/identities/${identityId}/readiness`),
  avatarPolicyOptions: () => req<AvatarPolicyOptions>('/avatar/policy-options'),
  listIdentityAssets: (identityId: string, kind?: string) =>
    req<AvatarAssetView[]>(`/identities/${identityId}/assets${kind ? `?kind=${kind}` : ''}`),
  reviewIdentityAsset: (
    identityId: string,
    assetId: string,
    input: { outcome: 'pass' | 'reject' | 'review'; identity_digest: string; method: string; note?: string },
  ) =>
    post<Record<string, unknown>>(`/identities/${identityId}/assets/${assetId}/review`, {
      reviewer: 'user_local',
      ...input,
    }),
  setReferencePolicy: (
    identityId: string,
    input: { mode: 'multi_view' | 'hero_only'; reason: string; acknowledged: string[] },
  ) =>
    post<AvatarIdentity>(`/identities/${identityId}/reference-policy`, {
      reviewer: 'user_local',
      ...input,
    }),
  freezeIdentity: (identityId: string, input: { hero_asset_id: string; identity_digest: string; license_id: string }) =>
    post<AvatarIdentity>(`/identities/${identityId}/freeze`, { reviewer: 'user_local', ...input }),
  attestLicense: (licenseId: string, basis: string, ackToken: string) =>
    post<AttestResult>(`/avatar-licenses/${licenseId}/attest`, {
      reviewer: 'user_local',
      basis,
      ack_token: ackToken,
    }),

  listVariants: (workId: string) => req<AvatarVariant[]>(`/works/${workId}/variants`),
  // 登记变体。给了 asset_id 就**引用已登记的那张资产**（确定性合成的产物），
  // 不再重复登记一份——同一张图两个 id 会让来源链断掉。
  createVariant: (
    workId: string,
    input: { asset_id?: string; outfit: string; background: string; identity_digest?: string },
  ) => post<AvatarVariant>(`/works/${workId}/variants`, input),

  // ---- 换装/换景变体：mask 草稿 → 人目视确认 → 确定性合成 ----
  listMasks: (identityId: string) =>
    req<{ identity_id: string; masks: MaskSpec[]; note: string }>(`/identities/${identityId}/masks`),
  createMask: (
    identityId: string,
    input: { method?: string; alpha_source?: string; component_mode?: string } = {},
  ) => post<MaskEstimateResult>(`/identities/${identityId}/masks`, input),
  // 确认是一次人工目视动作：后端要求操作者以 user 开头，任何"指标全绿即通过"的路径都不存在。
  confirmMask: (maskAssetId: string, outcome: 'pass' | 'fail' | 'review', note = '') =>
    post<MaskSpec>(`/avatar-masks/${maskAssetId}/confirm`, {
      reviewer: 'user_local',
      outcome,
      note,
    }),
  composeVariant: (
    identityId: string,
    input: {
      mask_asset_id: string
      background_asset_id: string
      edge_mode?: string
      person_scale?: number
      outfit?: string
      background_label?: string
      commit?: boolean
    },
  ) => post<VariantComposeResult>(`/identities/${identityId}/variants/compose`, input),

  listVoices: () => req<VoiceAsset[]>('/voices'),
  createVoicePreview: (workId: string, voiceId: string, sampleText: string) =>
    post<VoicePreviewResult>('/voice-previews', { work_id: workId, voice_asset_id: voiceId, sample_text: sampleText }),
  selectVoice: (workId: string, voiceId: string) =>
    post<Work>(`/works/${workId}/voice`, { voice_asset_id: voiceId }),

  generateScripts: (workId: string, topic: string, materials: string[] = []) =>
    post<ScriptBatch>(`/works/${workId}/scripts`, {
      topic,
      // 逐行参考资料：留空也行，此时生成侧避开需要外部依据的事实断言。
      materials: materials.map((text) => ({ text })),
    }),
  getScriptBatch: (workId: string) => req<ScriptBatch | null>(`/works/${workId}/scripts`),
  selectScript: (workId: string, scriptId: string) =>
    post<{ ok: boolean; message: string }>(`/works/${workId}/script-selection`, { script_id: scriptId }),
  reviseScript: (workId: string, scriptId: string, text: string) =>
    post<ScriptVersion>(`/works/${workId}/script-revisions`, { script_id: scriptId, text }),
  /** 让模型把这一稿重写到过硬门禁——用户不必自己改字。 */
  repairScript: (workId: string, scriptId: string) =>
    post<ScriptVersion>(`/works/${workId}/script-repairs`, { script_id: scriptId }),

  synthesizeFullAudio: (workId: string) => post<FullAudioResult>(`/works/${workId}/audio`, {}),
  // 确认是一次人工动作：后端要求 actor 以 user 开头且必须带试听确认。
  // 界面上的"确认"按钮点击即为用户的显式听检确认，因此这里显式传 audition_ack。
  confirmAudio: (workId: string, audioId: string, auditionAck = true) =>
    post<{ ok: boolean; message: string; duration_ms: number; revoked_previous: string[]; note: string }>(
      `/works/${workId}/audio-confirmation`,
      { audio_id: audioId, actor_id: 'user_local', audition_ack: auditionAck },
    ),
  getAudioGate: (workId: string) => req<AudioGateSummary>(`/works/${workId}/audio-gate`),

  estimateCost: (workId: string, route: GenerationRoute) =>
    post<CostEstimate>('/cost-estimates', { work_id: workId, route }),
  /**
   * 确认路线。高成本路线（OmniHuman）必须带 `cost_notice_ack`：
   * 后端会拦，前端弹窗只是呈现，不是约束。
   */
  confirmCost: (
    workId: string,
    route: GenerationRoute,
    costNoticeAck = false,
  ): Promise<{ ok: boolean; cost_notice_acknowledged: boolean; message: string }> =>
    post<{ ok: boolean; cost_notice_acknowledged: boolean; message: string }>(`/works/${workId}/route`, {
      route,
      cost_notice_ack: costNoticeAck,
    }),

  submitTask: (workId: string) => post<Task>('/tasks', { work_id: workId }),
  getTask: (taskId: string) => req<Task>(`/tasks/${taskId}`),
  getTaskEvents: (taskId: string, afterSeq = 0) =>
    req<TaskEvent[]>(`/tasks/${taskId}/events?after_seq=${afterSeq}`),
  cancelTask: (taskId: string) => post<Task>(`/tasks/${taskId}/cancel`, {}),

  getPackage: (workId: string) => req<PublishPackage | null>(`/works/${workId}/publish-package`),

  // ---------- T05 数字人口播 ----------
  //
  // 分成三块：**看**（能力与费用视图，只读）、**做**（提交与确认）、**判**（门禁与人工审核）。
  // 判断类接口一律把"谁在判"写进参数：本项目没有视觉理解能力，
  // 口型/身份/表情的结论只能由人给出，接口必须能区分"用户判的"与"系统猜的"。

  // 带 work_id 时后端会把最终音频时长并入费用提示，给出具体估价；
  // 不带则金额留空——没有计费时长就不给数。
  getTalkingHeadRoutes: (workId?: string) =>
    req<RoutePriceView>(`/talking-head/routes${workId ? `?work_id=${workId}` : ''}`),
  getTalkingHeadQueue: (workId?: string) =>
    req<QueueView>(`/talking-head/queue${workId ? `?work_id=${workId}` : ''}`),
  getTalkingHeadAdapters: () => req<AdapterStatusView>('/talking-head/adapters'),
  getTalkingHeadPreflight: (workId: string, route?: GenerationRoute) =>
    req<TalkingHeadPreflight>(`/works/${workId}/talking-head/preflight${route ? `?route=${route}` : ''}`),
  getTalkingHeadCost: (workId: string, route?: GenerationRoute) =>
    req<TalkingHeadCostView>(`/works/${workId}/talking-head/cost${route ? `?route=${route}` : ''}`),
  // 摘要由服务端从当前绑定推导，客户端不自报摘要：否则"确认的清单"与
  // "实际提交的清单"可能不是同一件事，而两者金额完全相同。
  confirmTalkingHeadCost: (
    workId: string,
    input: { route: GenerationRoute; prompt: string; resolution: string },
  ) =>
    post<TalkingHeadCostView['confirmation']>(`/works/${workId}/talking-head/cost-confirmation`, {
      ...input,
      actor_id: 'user_local',
    }),
  createSegmentPlan: (workId: string, limitMs?: number) =>
    post<SegmentPlanView>(`/works/${workId}/talking-head/segments`, { limit_ms: limitMs }),
  getSegmentPlan: (workId: string) =>
    req<SegmentPlanView>(`/works/${workId}/talking-head/segments`),
  // 动作意图必须**落库**：底片是从作品上读 motion_intent 的，
  // 只在下拉框里选一下不发请求，M2 会在提交时才报 MOTION_REQUIRED。
  listMotions: (identityId: string) => req<MotionCatalogView>(`/identities/${identityId}/motions`),
  setMotionIntent: (
    workId: string,
    input: { motion_key: string; motion_ref_id?: string; params?: Record<string, number> },
  ) => post<MotionIntentResult>(`/works/${workId}/motion-intent`, input),
  // 准入判定：不合格时逐条返回原因，界面照抄展示，不自己另编一套说法
  // 画风必须由调用方显式声明：门禁不接受"未声明画风"，空串会被判 review 而非 pass。
  admitVariant: (workId: string, variantId: string, style = '') =>
    post<VariantAdmitResult>(`/works/${workId}/variants/${variantId}/admit`, { style }),

  getPlateStatus: (workId: string) => req<PlateStatusView>(`/works/${workId}/talking-head/plate`),
  createPlate: (workId: string, outputSeconds: number, variantId?: string) =>
    post<{ registered: boolean; is_mock: boolean; note: string; duration_ms: number }>(
      `/works/${workId}/talking-head/plate`,
      { output_seconds: outputSeconds, ...(variantId ? { variant_id: variantId } : {}) },
    ),
  // 底片审核：通过必须是用户给出的（身份是否漂移只能由人目检）。
  reviewPlate: (plateId: string, input: { reviewer: string; outcome: string; note?: string }) =>
    post<Record<string, unknown>>(`/talking-head/plates/${plateId}/review`, input),

  submitTalkingHead: (
    workId: string,
    input: {
      route: GenerationRoute
      prompt: string
      resolution: string
      dry_run: boolean
      replacement_authorized?: boolean
    },
  ) => post<SubmissionResult>(`/works/${workId}/talking-head/submissions`, input),
  getSubmissions: (workId: string) =>
    req<SubmissionListView>(`/works/${workId}/talking-head/submissions`),
  pollRun: (runId: string) =>
    post<Record<string, unknown>>(`/talking-head/runs/${runId}/poll`, {}),
  settleRun: (runId: string, note: string) =>
    post<Record<string, unknown>>(`/talking-head/runs/${runId}/settle`, { note }),

  getVideos: (workId: string) => req<VideoAsset[]>(`/works/${workId}/talking-head/videos`),
  getVideoGate: (videoId: string) => req<VideoGateView>(`/talking-head/videos/${videoId}/gate`),
  getTalkingHeadGate: (workId: string) =>
    req<TalkingHeadGateSummary>(`/works/${workId}/talking-head/gate`),
  // 四维审核：每条 pass 必须带引用（资产 + 毫秒区间），没有引用的通过等于没有通过。
  reviewVideo: (
    videoId: string,
    input: {
      reviewer: string
      outcome: string
      dimensions: Record<string, string>
      references: Record<string, { asset_id: string; start_ms: number; end_ms: number; method?: string }>
      note?: string
    },
  ) => post<Record<string, unknown>>(`/talking-head/videos/${videoId}/review`, input),
  recordAudioTrackCheck: (
    videoId: string,
    input: {
      audio_asset_id: string
      method: string
      outcome: string
      measured_offset_ms?: number
      evidence: string
      note?: string
    },
  ) => post<Record<string, unknown>>(`/talking-head/videos/${videoId}/audio-track-checks`, input),
  // 确认最终原片。`review_ack` 是用户的声明"我看过这条原片"——
  // 本项目没有视频理解能力，所以界面必须由用户显式勾选，不能替用户默认勾上。
  confirmFinalVideo: (workId: string, videoId: string, reviewAck: boolean, note = '') =>
    post<{ ok: boolean; video_id: string; duration_ms: number; note: string }>(
      `/works/${workId}/talking-head/final-video`,
      { video_id: videoId, actor_id: 'user_local', review_ack: reviewAck, note },
    ),
}
