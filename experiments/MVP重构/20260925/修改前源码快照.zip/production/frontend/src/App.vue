<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useStudioStore } from '@/stores/studio'
import { apiMode } from '@/api'
import StatusBadge from '@/components/StatusBadge.vue'

const store = useStudioStore()
const route = useRoute()

const toast = ref<{ kind: string; text: string } | null>(null)
let timer: ReturnType<typeof setTimeout> | undefined

watch(
  () => [store.notice, store.error] as const,
  ([n, e]) => {
    const next = e ? { kind: 'danger', text: e } : n ? { kind: n.kind, text: n.text } : null
    if (!next) return
    toast.value = next
    clearTimeout(timer)
    timer = setTimeout(() => {
      toast.value = null
      store.error = null
      store.clearNotice()
    }, 3500)
  },
  { deep: true, immediate: true },
)

const STEPS = [
  { to: '/avatar', num: '01', label: '人物形象' },
  { to: '/script', num: '02', label: '口播稿' },
  { to: '/tts', num: '03', label: '语音配音' },
  { to: '/video', num: '04', label: '视频合成' },
]
const PLANS = [
  { to: '/publish', num: '05', label: '发布' },
  { to: '/metrics', num: '06', label: '指标监控' },
  { to: '/models', num: '07', label: '模型选择' },
]

const showCreate = ref(false)
const form = ref({
  name: '', topic: '', content_type: 'AI 科普',
  audience: '对 AI 感兴趣的年轻受众', keywords: '', duration: 60,
})

const mode = computed(() => {
  const m = store.capabilities?.mode ?? (apiMode === 'mock' ? 'mock' : 'unknown')
  return m === 'mock' ? 'mock' : m === 'production' ? 'live' : m === 'integration' ? 'live' : 'err'
})
const modeText = computed(() => ({
  mock: 'MOCK', live: '生产', err: '未连接', unknown: '未连接',
}[mode.value] ?? '未连接'))

/** 侧栏每一步的推进状态：完成 / 进行中 / 待办 */
const stepState = computed<Record<string, 'ok' | 'run' | 'off'>>(() => {
  const w = store.currentWork
  return {
    '/avatar': w?.identity_id ? 'ok' : 'off',
    '/script': store.scriptReady ? 'ok' : store.busy === '写稿' ? 'run' : 'off',
    '/tts': store.confirmedAudio ? 'ok' : store.audios.length ? 'run' : 'off',
    '/video': store.pkg ? 'ok' : store.task && ['running', 'queued'].includes(store.task.state) ? 'run' : 'off',
  }
})

/** 侧栏卡片第二行：当前这一步的具体状态，不只显示进度点 */
const stepHint = computed<Record<string, string>>(() => {
  const s = stepState.value
  const dur = ((store.confirmedAudio?.duration_ms ?? 0) / 1000).toFixed(1)
  return {
    '/avatar': store.currentIdentity?.name ?? '未选择人物',
    '/script': s['/script'] === 'ok' ? '已采用一稿' : store.scriptBatch ? '三稿待选定' : '尚未生成',
    '/tts': store.confirmedAudio ? `已确认 ${dur}s` : store.audios.length ? '待试听确认' : '尚未合成',
    '/video': store.pkg ? '发布包已就绪' : s['/video'] === 'run' ? '合成进行中' : '尚未提交',
    '/publish': '待取得平台权限',
    '/metrics': '未接入平台数据',
    '/models': '配置页后续开放',
  }
})

/**
 * 下一步指向哪一页。**判断逻辑在 store 里（全应用唯一）**，这里只负责把
 * `store.nextStep.to` 映射成导航项，免得侧栏与各页各算一套、给出两个"下一步"。
 */
const nextStep = computed(() => {
  const to = store.nextStep.to
  if (!to) return null
  return [...STEPS, ...PLANS].find((s) => s.to === to) ?? null
})

async function createWork() {
  await store.createWork({
    name: form.value.name || form.value.topic || '未命名作品',
    topic: form.value.topic,
    content_type: form.value.content_type,
    audience: form.value.audience,
    keywords: form.value.keywords.split(/[,，\s]+/).filter(Boolean),
    target_duration_ms: form.value.duration * 1000,
  })
  showCreate.value = false
  form.value = { name: '', topic: '', content_type: 'AI 科普', audience: '对 AI 感兴趣的年轻受众', keywords: '', duration: 60 }
}

onMounted(() => store.bootstrap())
</script>

<template>
  <div class="shell">
    <!-- 侧栏 -->
    <aside class="sidebar">
      <div class="sidebar-head">
        <div class="logo">A</div>
        <div>
          <div class="sidebar-title">口播工作台</div>
          <div class="sidebar-sub">avatar_studio</div>
        </div>
      </div>

      <div class="sidebar-body">
        <div class="nav-group">
          <div class="nav-group-label">制作流程</div>
          <router-link
            v-for="s in STEPS"
            :key="s.to"
            :to="s.to"
            class="nav-item"
            :class="{ active: route.path === s.to }"
          >
            <span class="nav-num">{{ s.num }}</span>
            <span class="nav-text">
              <span class="nav-label">{{ s.label }}</span>
              <span class="nav-hint">{{ stepHint[s.to] }}</span>
            </span>
            <span class="nav-dot" :class="stepState[s.to]"></span>
          </router-link>
        </div>

        <div class="nav-group">
          <div class="nav-group-label">规划中</div>
          <router-link
            v-for="s in PLANS"
            :key="s.to"
            :to="s.to"
            class="nav-item"
            :class="{ active: route.path === s.to }"
          >
            <span class="nav-num">{{ s.num }}</span>
            <span class="nav-text">
              <span class="nav-label">{{ s.label }}</span>
              <span class="nav-hint">{{ stepHint[s.to] }}</span>
            </span>
            <span class="nav-dot off"></span>
          </router-link>
        </div>
      </div>

      <div class="sidebar-foot">
        <div class="mode-line">
          <span>运行模式</span>
          <span class="mode-tag" :class="mode">{{ modeText }}</span>
        </div>
        <div class="mode-line" style="margin-top: 5px">
          <span>单条额度</span>
          <span class="num">
            ¥{{ ((store.capabilities?.budget.per_task_limit_fen ?? 0) / 100).toFixed(2) }}
          </span>
        </div>
      </div>
    </aside>

    <!-- 主区 -->
    <div class="main">
      <header class="topbar">
        <div class="work-select">
          <select
            :value="store.currentWorkId ?? ''"
            @change="store.selectWork(($event.target as HTMLSelectElement).value)"
          >
            <option v-if="!store.works.length" value="">暂无作品</option>
            <option v-for="w in store.works" :key="w.id" :value="w.id">{{ w.name }}</option>
          </select>
        </div>
        <button class="sm" @click="showCreate = true">新建</button>

        <div class="topbar-spacer"></div>

        <span v-if="store.busy" class="st run">{{ store.busy }}…</span>
        <StatusBadge v-if="store.task" :text="store.task.state" />
      </header>

      <div class="content">
        <div class="page-wrap">
          <div v-if="!store.apiReady" class="empty">
            正在连接后端…若长时间无响应，确认 FastAPI 已在 8000 端口启动。
          </div>

          <router-view v-else />

          <!-- 下一步指引：不用框，避免又多一个视觉块 -->
          <div
            v-if="store.apiReady && nextStep && route.path !== nextStep.to"
            style="margin-top: 34px; font-size: 13.5px; color: var(--fg-3)"
          >
            下一步
            <router-link :to="nextStep.to" style="color: var(--fg); font-weight: 600">
              {{ nextStep.num }} {{ nextStep.label }} →
            </router-link>
          </div>
        </div>
      </div>
    </div>

    <!-- 新建作品 -->
    <div v-if="showCreate" class="modal-mask" @click.self="showCreate = false">
      <div class="modal">
        <div class="modal-head">新建作品</div>
        <div class="modal-body">
          <label class="field">
            <span>作品名称</span>
            <input v-model="form.name" type="text" placeholder="例如：RAG 科普 · 第 1 期" />
          </label>
          <label class="field">
            <span>选题 / 要求</span>
            <input v-model="form.topic" type="text" placeholder="例如：用三分钟讲清楚 RAG" />
          </label>
          <div class="grid-2">
            <label class="field"><span>文案类型</span><input v-model="form.content_type" type="text" /></label>
            <label class="field"><span>目标时长（秒）</span><input v-model.number="form.duration" type="number" min="45" max="90" /></label>
          </div>
          <label class="field">
            <span>目标受众</span>
            <input v-model="form.audience" type="text" />
          </label>
          <label class="field" style="margin-bottom: 0">
            <span>关键词（空格或逗号分隔）</span>
            <input v-model="form.keywords" type="text" placeholder="RAG 检索 科普" />
          </label>
        </div>
        <div class="modal-foot">
          <button @click="showCreate = false">取消</button>
          <button class="primary" :disabled="!form.topic || store.busy !== ''" @click="createWork">创建</button>
        </div>
      </div>
    </div>

    <!-- 浮层提示：不打断操作，3.5 秒自动消失 -->
    <div v-if="toast" class="toast" :class="toast.kind">
      <span class="st" :class="toast.kind">{{ toast.text }}</span>
    </div>
  </div>
</template>
