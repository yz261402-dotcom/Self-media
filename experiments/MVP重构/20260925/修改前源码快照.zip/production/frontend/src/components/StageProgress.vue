<script setup lang="ts">
import type { Task } from '@/api/types'
const props = defineProps<{ task: Task }>()
</script>

<template>
  <div>
    <!-- 无真实百分比时只显示不定态，不做匀速假进度 -->
    <div
      v-if="props.task.state === 'running' || props.task.state === 'queued'"
      class="bar"
      :class="{ indeterminate: props.task.percent === null }"
      style="margin: 12px 14px"
    >
      <i :style="{ width: (props.task.percent ?? 0) + '%' }"></i>
    </div>
    <div class="stage-list">
      <div
        v-for="s in props.task.stage_rows"
        :key="s.stage"
        class="stage-row"
        :class="s.state === 'done' ? 'done' : s.state === 'active' ? 'active' : s.state === 'blocked' ? 'blocked' : s.state === 'failed' ? 'failed' : ''"
      >
        <span class="stage-mark">
          <svg viewBox="0 0 10 10" fill="none">
            <path d="M1.5 5.2 4 7.5 8.5 2.5" stroke="#ffffff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
        </span>
        <span style="flex: 1">{{ s.label }}</span>
        <span class="faint mono">{{ s.stage }}</span>
      </div>
    </div>
  </div>
</template>
