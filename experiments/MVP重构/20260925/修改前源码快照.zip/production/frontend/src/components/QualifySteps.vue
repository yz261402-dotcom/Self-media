<script setup lang="ts">
import { computed } from 'vue'
import type { QualifyProgress } from '@/api/types'

/**
 * 定版链的四步进度。顺序、完成状态与"这一步为什么需要人做"全部来自后端
 * (`registry.qualify_steps`)，前端只负责渲染。
 *
 * 存在的理由：四步此前是四块同质的表单叠在一起，用户看不出自己停在哪里、
 * 下一步该点哪个，也看不出这四步与"选用"是前提/引用的关系而不是两条并列的路。
 */
const props = defineProps<{ qualify: QualifyProgress | null }>()

const steps = computed(() => props.qualify?.steps ?? [])
const currentIndex = computed(() => {
  const key = props.qualify?.current
  if (!key) return -1
  return steps.value.findIndex((s) => s.key === key)
})
const currentStep = computed(() => (currentIndex.value >= 0 ? steps.value[currentIndex.value] : null))
const allDone = computed(() => !!props.qualify && props.qualify.done_count === props.qualify.total)
</script>

<template>
  <div v-if="qualify" class="q">
    <div class="q-track">
      <div
        v-for="(s, i) in steps"
        :key="s.key"
        class="q-step"
        :class="{ done: s.done, now: i === currentIndex }"
      >
        <span class="q-mark">{{ s.done ? '✓' : i + 1 }}</span>
        <span class="q-label">{{ s.label }}</span>
      </div>
    </div>

    <!-- 说清"你现在停在哪、为什么"——没有这句话，四步只是四块表单 -->
    <div v-if="allDone" class="q-now ok">
      <b>四步已全部完成{{ qualify.frozen ? '，身份已冻结定版' : '' }}。</b>
      这个人物此后可以被任何作品直接选用；要换人只能新建版本，不能就地替换。
    </div>
    <div v-else-if="qualify.closed_incomplete" class="q-now warn">
      <b>已冻结定版，但四步留痕不全（{{ qualify.done_count }} / {{ qualify.total }}）。</b>
      <div class="q-why">
        该身份在四步流程建立之前就被直接冻结（早期预设登记）。这些空档
        <strong>无法事后补齐</strong>——冻结后口径不可再声明、不再接受新的基准。
        若需要完整留痕，只能新建版本重走一遍；旧作品仍引用旧版本。
      </div>
    </div>
    <div v-else-if="currentStep" class="q-now">
      <b>当前停在第 {{ currentIndex + 1 }} / {{ qualify.total }} 步 · {{ currentStep.label }}</b>
      <div class="q-why">{{ currentStep.why }}</div>
      <div class="q-why">
        这四步是「选用」的<strong>前提</strong>：未定版的人，后端在选择时会直接拒绝。
      </div>
    </div>
  </div>
</template>

<style scoped>
.q-track {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
}
.q-step {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 6px 12px 6px 7px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: var(--panel-2);
  font-size: 12.5px;
  color: var(--fg-3);
}
.q-step.done {
  background: rgba(18, 161, 80, 0.07);
  border-color: rgba(18, 161, 80, 0.3);
  color: var(--fg-2);
}
.q-step.now {
  background: var(--blue-wash);
  border-color: rgba(47, 111, 237, 0.42);
  color: var(--blue-d);
  font-weight: 600;
}
.q-mark {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 19px;
  height: 19px;
  border-radius: 999px;
  background: var(--panel-3);
  color: var(--fg-3);
  font-size: 11px;
  font-weight: 700;
  flex: none;
}
.q-step.done .q-mark {
  background: var(--green);
  color: #fff;
}
.q-step.now .q-mark {
  background: var(--blue);
  color: #fff;
}
.q-now {
  border-left: 3px solid var(--blue);
  background: var(--blue-wash);
  border-radius: 0 var(--r-xs) var(--r-xs) 0;
  padding: 10px 14px;
  font-size: 12.5px;
  color: var(--fg-2);
  line-height: 1.62;
}
.q-now.ok {
  border-left-color: var(--green);
  background: rgba(18, 161, 80, 0.06);
}
.q-now.warn {
  border-left-color: var(--amber);
  background: rgba(206, 138, 6, 0.07);
}
.q-why {
  margin-top: 3px;
  color: var(--fg-3);
}
</style>
