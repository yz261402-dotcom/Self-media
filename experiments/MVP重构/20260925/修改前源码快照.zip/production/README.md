# production · 数字人口播工作台（首版骨架）

单用户七入口工作台的可运行骨架：**前端（Vue 3 + Vite）＋ 后端（FastAPI）**，Provider 全部为 mock。
目标与验收标准以 `specs/0001-douyin-ai-studio/` 为准，本目录只做工程实现，不改写权威文档。

## v2.4 本轮调整

- 策划直接接收用户提示，不再调用网上搜索/抓取；内部历史查重只在 quality 阶段执行。
- 只注册 content/quality/avatar/audio 四类子 Agent，删除 editor、S07 及联网/字幕/渲染/打包的 Agent/MCP 工具。
- 后期转入 `backend/app/postprocess_worker.py` 内部代码入口；当前只完成依赖检查、持久执行记录与显式阻断，真实 ASR、合成、清晰度与交付能力尚未实现。不会因空 Agent 阶段直接声明完成，也不生成空壳发布包。
- 旧工作图需要迁移时明确阻断，不覆盖历史任务与实验；本轮没有调用收费模型。

## 当前能做什么

- 七个入口全部可进入：人物形象、口播稿生成、TTS 语音、视频合成形成真实交互闭环；
  发布、指标监控、领域模型选择展示真实规划/开发状态，未实现操作禁用。
- 制作闭环：建作品 → 三角度写稿 → 逐稿审核 → 用户选稿（硬门禁失败稿拒收）→ 试听选声 →
  全文合成 → 用户确认音频 → 选路线与预算（未确认则 `blocked`）→ 提交口播 → 阶段推进 →
  代码后期入口 → 缺真实媒体/处理能力时明确阻断；当前不能生成可下载真实成片。
- 后端持久化到 SQLite（`backend/runtime/studio.db`），重启后识别未完成任务并重新调度。

## 不能做什么（重要）

- **不调用任何付费服务、不提交 GPU 作业、不执行发布**：默认预算为 0，可计费次数为 0。
- **不产生真实媒体字节**：试听、音频、成片在 mock 模式下没有可播放文件，界面明确标注。
  不使用静态图、贴片嘴、假嘴型或卡通占位冒充数字人口播。
- **不伪造进度**：没有真实百分比时前端只显示阶段与等待时间（`percent = null`）。
- **后三项入口不填假数据**：指标显示“不可获取”，不记 0；发布状态停在 `ready`，不宣称已发布。
- Mock 通过 ≠ 真实能力验收。按 06 文档，本工程当前只覆盖 **L0 结构与契约**，
  L1（真实 Provider 与生产质量）、L2（官方发布）另行验收。

## 实施进度

- **T00 DeepAgents 离线最小编排与恢复**：已完成。离线编排（角色分工、依赖拒绝、伪造选择拦截、
  越权工具、幂等、检查点恢复）＋ DeepAgents 真实运行时；离线替身成功不代表模型接入成功。
- **T01 工程隔离、契约与配置**：已完成。要点：
  - 契约进入严格模式，未知字段与非法枚举一律拒绝，不靠宽松解析"兼容"。
  - 人工选择（`SelectionDecision`，actor 恒为 user）与质量审批（`ReviewDecision`）彼此独立，
    审批通过不能构造出选择；路线确认会把决定 id 冻结到 `route_selection_id`。
  - 默认预算 0、可计费次数 0；`integration` / `production` 需显式授权，未授权停留在 `mock`。
  - 供应商连接检查区分 未配置 / 认证失败 / 额度不足 / 模型不存在 / 能力不支持 / 网络故障 / 未实测，
    URL·Key·model 文本齐全不等于模型可用；对外只出脱敏视图。
- **T02 持久任务、MCP、预算与记忆**：已完成（持久层仍为 SQLite）。要点：
  - `jobs.py`：持久意图 → 幂等键 → 预算 → 资源的顺序不可颠倒；租约竞争只有一个赢家，
    过期 Worker 回写判为 `STALE_WRITER` / `LEASE_EXPIRED`；`unknown` 先对账，**不得创建替代计费任务**；
    单 GPU 互斥，占用作业未核实结束前不释放。
  - `mcp.py`：能力白名单 + 角色权限；本机纯函数不得走 `submit` 绕过台账，
    外部能力不得当本机函数调用；调用全部落审计。
  - `memory.py`：checkpoint / persona / history / experience 四层；分支只写隔离命名空间，
    共享经验必须 proposed → 审核合并，且按期望摘要做 CAS，冲突即拒。
  - `lineage.py`：改正文失效音频/嘴型/字幕/成片；**仅改字幕样式只重渲染**；失效不删除、保留原始摘要；
    旧候选迟到不得改写当前选择。
  - **PostgreSQL / pgvector 未验证**：不在本工程宣称已部署，见 `/api/v1/config/persistence`。
    排期（APScheduler）按计划留到 T13。
- **T03 人物库、人物候选与衣景动作资产**：已完成门禁与登记（不依赖授权的部分）。要点：
  - `avatar/registry.py`：登记必须带存储位置、**sha256 文件哈希**与来源证据，缺一即拒；
    身份冻结后**定妆原片不可覆盖**，显式换人必须 `bump_identity_version` 产生新版本并重新验收；
    参考集允许补齐但已定版文件不可替换；`Mock` 后代不进入生产。
  - `avatar/identity_gate.py`：审核摘要**绑定资产版本与文件哈希**，任一变化即失效；
    换脸候选（摘要与冻结基准不符）拒收；动作参考误作人物原片按种类不符拒收；
    卡通/二次元/SVG/CSS/几何/插画判 fail，未声明画风判 review，一律不进白名单；哈希篡改按 `ASSET_HASH_TAMPERED` 拒。
  - `avatar/licensing.py`：**算法名或代码许可证不能替代模型权重许可**（`covers_weights` 未声明即阻塞）；
    声称商用但缺证据与核验人自动回落 `unverified`。
  - `avatar/motion.py`：M2 只把意图映射到**已获准**动作参考与受支持参数；
    自由描述在 M2 下直接拒绝（OmniHuman 1.5 留到 T05）；短循环（<3s）不得转长期母版。
  - 预设 `av_base_b_v1` 保留但**不继承生产通过结论**：`/api/v1/identities/{id}/readiness`
    当前如实返回未就绪（未冻结 / 缺定妆原片 / 参考图不足 4 张）。
  - **实测核验结论（证据在 `experiments/图像编辑验证/`）**：
    - `gpt-image-2` 中转：接口可用（已按实测证据标 `ready`），**支持自定义尺寸**；
      但**忽略 mask 参数、整图重绘**，人脸每次被"精修"，**不能用于同一人物换装/换背景**。
      故 `reference_edit_verified` 保持 `false`。
    - 教训：请求尺寸的宽高比必须与参考图一致（941×1672 是 9:16，1024×1536 是 2:3），
      否则模型重构构图，像素差指标失去意义。
    - `InsightFace` 公共权重：官方条款限非商用研究（**代码 MIT ≠ 权重可商用**），
      已登记为 `blocked`，检测 Provider 启用被阻塞。
  - **替代路径已落地：`avatar/compose.py`（确定性抠图合成）**，证据在
    `experiments/抠图合成验证/结论.md`：
    - 硬保护区（人脸核心）内像素**严格逐像素相同**（最大通道差 == 0，四组产出实测均为 0），
      这是"身份零漂移"的可验证依据；模块**不做身份识别**，产出标记 `identity_claim=not_run`。
    - 分割只用**无预训练权重**算法（背景曲面拟合 / GrabCut / 颜色键控，许可随 OpenCV）。
      该图实测**只有背景曲面拟合可用**（四阶多项式拟合渐变背景 + 残差分割），
      另两种会把整块西装判为背景。
    - **自动 mask 是草稿**：`confirm_mask()` 是唯一定版入口，必须记录确认人，
      无自动通过路径；未确认的 mask 产出只能是候选（`production_ready=False`）。
    - mask 绑定**源图哈希 + 版本 + 尺寸**：源文件一换即失效，防止拿别人的抠图套在自己脸上。
    - **边缘去污 `edge_mode="unmix"`（证据 `experiments/抠图合成验证/CS-003/`）**：
      常规 alpha 混合会把轮廓半透明像素里**原影棚背景的贡献**原样保留下来，
      换成深色/异色背景即在轮廓外形成一圈肉眼可见的灰雾。改为代数闭式解
      `C' = C + (1-α)·(B_new - B_orig)`——由成像方程 `C = αF + (1-α)B` 相减得到，
      不出生成、不需要除以 α（不放大噪声）；**α==1 处校正量为 0**，
      故硬保护区的逐像素断言不受削弱。
    - **alpha 必须从图像反解，不能靠羽化（同上证据）**：二值 mask 高斯羽化出的 α 与真实
      混合比例无关，细发丝处恒接近 1，去污校正量随之退化为 0。改用局部 F/B 估计的闭式解
      `α = (C-B)·(F-B)/|F-B|²`（只用无权重算法）。trimap 由颜色距离自适应生成；
      前景种子额外要求**离轮廓足够远**——否则种子会落在轮廓外的混合区内部，
      出现"离我最近的前景就是我"的循环论证，α 恒为 1 且无从察觉。
      实测：轮廓过渡带与新背景的平均色差 23.7 → 15.2（降低 36%），三组硬保护区仍全为 0。
    - **场景背景（证据 `experiments/抠图合成验证/CS-004/`）**：AI 生成空景（教室 / 办公室 /
      公园小径），按目标宽高比裁切以排除生成服务的平台水印（标注在原图 x∈[872,1024]），
      规范化为 941×1672 后登记权属与哈希。合成保持 **1:1 像素复制（人物不缩放）**，
      故"硬保护区逐像素相同"继续成立；三组产出实测最大通道差均为 0。
      AI 生成素材的商用范围依生成服务条款，登记时已把依据与局限一并写入证据字段。
    - 质量边界：浅色近色背景无需去污；**深色/强对比背景必须用 `edge_mode="unmix"` +
      `alpha_source="matting"`**，否则轮廓外会残留原影棚灰雾。极细发丝处仍有少量残影，
      成因是原图本身的光晕，需人工精修 mask 或改用可商用抠图服务。
    - **人物大小（画框式缩放，证据 `experiments/抠图合成验证/CS-005/`）**：缩放的本质是
      "人物在画面里占多大"，不是"人物有多少像素"。故把两者解耦：人物层**永远 1:1 逐像素
      复制**（不重采样、不生成），缩放只改**画框**（放大=内收裁切，缩小=外扩补场景）。
      因此硬保护区断言在缩放前后**同样是"差 1 即失败"**（按整数偏移映射比对），
      身份零漂移的可验证性不因改构图而下降。
      · 放大：本素材可用区间 **[1.0, 1.415]**，上限由头顶余量（头顶之上仅 127px）决定，
        超出即拒（`FRAME_CUTS_HEAD`）；输出分辨率随之下降。
      · 缩小：源图是胸像特写，躯干在左/右/下三边被源图裁断，**整体外扩必露断面**
        （实测左右各 700+px 长的直线切口，人物像纸片贴在场景里），默认硬拒绝
        `FRAME_REVEALS_SOURCE_CUT`；`allow_frame_reveal=True` 仅作对照实验。
      · 零断面缩小：改用 `compose.fit_smaller_frame()` —— 把画框**下移**，让人物断面正好
        落在画框下沿（不可见），上半部分交给场景，人物占比可降到约 40~48%。代价如实记录：
        人物位于画面下半部，人脸位置比常规口播低。
        要"人物既小又居中"，正解是换**更宽构图的主图**，而不是把特写往外放。
      · 可用区间由 `compose.allowed_scale_range()` 从素材几何（头顶余量/硬保护区/边界断面）
        自动求得，不靠人工试。
    - 预览页：`experiments/抠图合成验证/背景变体预览.html`（纯色/渐变 4 张 + 场景 3 张）、
      `experiments/抠图合成验证/人物大小预览.html`（放大档可拖动 + 缩小两条路线对照）。
  - **仍待补**：参考图 ≥4 张、6 组服装/背景组合（服装变体无法确定性实现，只能作为新的
    人物候选重走身份审核）、动作母版（MT-001）权利核验、mask 的人工目视确认、
    **更宽构图的主图**（当前素材是胸像特写，四边都切着身体，限制了"人物置身场景"的构图空间）。

## 目录

```text
production/
  frontend/           Vue 3 + Vite 工作台
    src/api/          types（契约镜像）· http（真实后端）· mock（离线模拟）
    src/stores/       pinia 作品/任务状态
    src/views/        七个入口页面
  backend/
    app/contracts.py  Pydantic 契约（对齐 04 枚举；严格模式，未知字段拒绝）
    app/config.py     配置·模式越级拦截·预算策略·供应商受控连接检查（T01）
    app/storage.py    SQLite 仓储与初始预设（人物 B / 音色 3）；事务原语
    app/engine.py     编排推进器（等待用户选择时停住；可恢复清单与重启恢复）
    app/jobs.py       Provider 作业台账·租约·unknown 对账·GPU 互斥（T02）
    app/mcp.py        受限 MCP 通道：submit/query/register 与能力白名单（T02）
    app/memory.py     分层记忆与命名空间隔离（T02）
    app/lineage.py    产物血缘与依赖失效（T02）
    app/avatar/       人物资产：registry 登记·identity_gate 门禁·motion 映射·licensing 权属·
                      compose 确定性抠图合成 + 局部 F/B matting + 边缘代数去污（T03）
    app/mockdata.py   mock 稿件与包清单
    app/main.py       FastAPI 路由
    app/agents/
      contracts.py    Agent 契约（工作项/结果/表演计划/审核结论/记忆候选）
      roles.py        四类角色 + 总控，最小权限与 Skill 绑定
      tools.py        受控工具执行器（白名单·schema·幂等·审计）
      models.py       离线确定性替身 + DeepSeek 适配器（未配置即失败）
      supervisor.py   工作项 DAG、并行委派、选择门、重启恢复
      results.py      结果校验与选择伪造拦截
      framework.py    DeepAgents 运行时适配（T00 试验项）
    tests/            编排测试 + 框架运行时测试
      contract/       T01 契约与配置测试
      pipeline/       T02 作业台账·MCP 权限·记忆隔离·恢复与血缘测试
      avatar/         T03 资产登记·身份门禁负例·权属·动作映射·合成门禁与逐像素断言测试
    requirements.lock.txt  依赖锁（由实际验证过的环境生成）
  skills/             8 份业务 SKILL.md（版本与摘要由文件计算）
  scripts/
    e2e_smoke.mjs     端到端冒烟（离线）
    ingest_base_assets.py        定妆原片与参考集入库
    register_license_reviews.py  权属核验记录登记
    register_provider_evidence.py 供应商实测证据登记
    probe_image_edit*.py          gpt-image 中转换背景探针（含 mask 有效性）
    probe_matting.py              三种无权重分割算法对比探针
    probe_edge_unmix.py           边缘去污三方对比（羽化/去污/matting）
    compose_background_variants.py 纯色/渐变背景合成
    ingest_scene_backgrounds.py   场景背景规范化（裁切排除水印）与权属登记
    compose_scene_variants.py     场景背景合成（matting + unmix）
    compose_zoom_variants.py      人物大小三条路线实测（放大/缩小露断面/零断面构图）
    build_background_preview.py   背景变体预览页生成
    build_zoom_preview.py         人物大小交互预览页生成（放大档可拖动）
```

## 启动

后端（Python 3.13，`backend/.venv` 已安装依赖）：

```bash
cd production/backend
.venv/Scripts/python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

前端（已 `npm install`）：

```bash
cd production/frontend
node node_modules/vite/bin/vite.js --port 5173 --host 127.0.0.1
```

浏览器打开 `http://127.0.0.1:5173`。前端 `/api` 与 `/media` 经 Vite 代理到 8000。

冒烟测试（需后端已启动）：

```bash
cd production && node scripts/e2e_smoke.mjs
```

设置 `VITE_API_MODE=mock` 可让前端脱离后端运行（界面显示 MOCK 模式）。

## 与 04 接口契约的对应关系

| 04 文档 | 本工程实现 |
|---|---|
| `GET /api/v1/capabilities` `/features` | 同路径 |
| `POST/GET /api/v1/works` | 同路径；补充 `POST /works/{id}/identity`、`/voice`、`/scripts`、`/script-selection`、`/script-revisions`、`/audio`、`/audio-confirmation`、`/route`、`/variants`、`/publish-package` |
| `POST /api/v1/selections/{id}/decisions` | 本版以高层接口内部记录 `SelectionDecision`（`selections` 表），字段保留 kind / selected_ref / state |
| `GET /api/v1/voices`、`POST /api/v1/voice-previews` | 同路径 |
| `POST/GET /api/v1/tasks`、`/tasks/{id}/events`、`/tasks/{id}/cancel` | 同路径 |
| `GET /api/v1/publish-packages/{id}`、`/download` | 查询走 `GET /works/{id}/publish-package`；下载在 mock 下返回 `FEATURE_NOT_AVAILABLE` |
| `POST /api/v1/cost-estimates` | 同路径；`CostConfirmation` 写入 `confirmations` 表 |

补充路径是为前端交互必须的聚合操作，未新增新的状态枚举或并行契约。

## 智能体层（T00 已完成）

生产编排在 `backend/app/agents/`，由 `AVATAR_STUDIO_ORCHESTRATOR=agents` 启用，
不是框架默认路径：

- **四类角色 + 总控**：`content` / `quality` / `avatar` / `audio`，
  各自最小工具白名单，越权调用在 `tools.invoke` 处被拒（`ToolDenied`）。
- **受控工具执行器**：权限、schema、幂等键、路径校验、审计落表；
  硬门禁由业务层按规则复算，**不采信 Agent 自报的放行**。
- **红线拦截**：Agent 结果中不得夹带 `selection` / `approve` 等字段，
  出现即 `SELECTION_FORGERY`；审核通过不替代用户采用。
- **离线确定性替身**：默认 `deterministic` 后端，不联网、不计费、同输入同输出。
  DeepSeek 适配器未配置密钥时抛 `CAPABILITY_NOT_CONFIGURED`，绝不静默降级。

测试：

```bash
cd production/backend
.venv/Scripts/python.exe -m pytest tests -q     # 运行当前后端全部离线测试
```

### DeepAgents 框架运行时（试验项，非生产路径）

已装 `deepagents 0.7.17` / `langgraph 1.2.12`，`app/agents/framework.py` 验证其可用性。
实测结论（`tests/test_agent_framework.py` 持续跟踪）：

- 构造成功：`create_deep_agent` 返回 `CompiledStateGraph`；子 Agent 通过 `task` 工具委派。
- 委派链路真实可用：总控 → `task` → `content` 子 Agent → 受控工具 → 落库（三稿已写入）。
- **默认会暴露 8 个文件/shell 工具**（`ls`/`read_file`/`write_file`/`edit_file`/`glob`/
  `grep`/`execute`/`delete`）。处理：换内存后端 `StateBackend` 并用
  `FilesystemMiddleware(tools=[...])` 白名单压制。
  实测 8 个中摘除 7 个，**仅剩框架强制的 `read_file`**（白名单不含它时构造直接报错），
  且其作用域为空的内存命名空间；写入与 shell 类残留为 0。
- 需实现 `bind_tools` 与 `_agenerate`，否则框架调度报 `NotImplementedError`。
- 受控工具包装须 `args_schema=None, infer_schema=False`，
  否则 LangChain 会丢弃 schema 未声明的参数（表现为参数静默丢失）。

生产编排暂不切到框架：DAG 的选择门、重启恢复与预算门禁已在自研编排中验证，
框架路径待 T01 补齐并行/退回/恢复证据后再评估切换。

## 工程选型（待 05/T10 正式验收）

- 前端 Vue 3：为实现首版闭环所选（模板直观、单文件组件、体积小）。
  文档 T10 要求用同一七入口流程对比 Vue 3 与 React 后再冻结，正式对比证据待补。
- 后端 FastAPI + SQLite（标准库 sqlite3）：首版为最小依赖与稳定启动。
  文档建议的 PostgreSQL + SQLAlchemy 属 `PROPOSED`，持久后端在 T02 试验后定版；
  仓储层已隔离，替换不影响接口。

## 下一步（按 05 实施计划）

1. **T01**：补齐框架路径的并行依赖、审核退回、跨进程恢复证据；再评估是否从自研 DAG 切换到框架。
   （T00 的离线编排、模型替身、选择门与重启恢复已完成，见上节。）
2. **T02**：PostgreSQL/pgvector 与持久 checkpoint 试验；受限 MCP 工具（`studio-core` / `studio-media`）。
3. **T03–T05**：真实接入人物 B 变体、MiniMax 全文 TTS、M2 长片；OmniHuman 单独验收。
4. **T06–T12**：内容、后期、质量门禁、发布包、七入口浏览器证据与日产 5 条验收。

真实调用前必须在预算策略中授权（默认 0），并在生成前展示路线、模型、时长、估价与重做收费风险。
