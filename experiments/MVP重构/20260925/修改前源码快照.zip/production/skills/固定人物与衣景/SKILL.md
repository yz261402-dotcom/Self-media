# S04 固定人物与衣景

版本：0.2.0 · 使用者：数字人导演（avatar），质量审核检查 · 状态：拟建，未验收

## 1. 触发条件
需要为作品确认/创建基础人物、或生成服装与背景变体时。

## 2. 输入引用
`AvatarIdentity`（`identity_digest`、`hero_asset_id`、`approval_state`）、已审变体记录、参考图来源。

## 3. 工作步骤
1. 读取当前已定版人物档案（只读），确认身份摘要与审批状态。
2. 新建人物：收集性别、年龄、外貌、气质关键词与自由描述，生成候选交用户选定。
3. 变体：以已定版人物为参考做服装/背景编辑，继承身份描述，追加服装与背景关键词。
4. 每次生成后做身份一致性检查，写入 `identity_report`，保留来源链。
5. 未通过身份检查的变体保持 `pending`，不得进入生产。

## 4. 允许调用的工具
`get_presenter_profile`、`list_approved_assets`、`prepare_motion_assets`、`get_media_job`、`get_media_result`、`propose_memory`

## 5. 输出契约
`AvatarVariant`（`identity_id/outfit/background/approval_state/identity_report`），
派生资产登记到业务库，`AgentResult.output_refs` 含资产或作业 ID。

## 6. 拒收 / 返工条件
- 换装后变成另一个人（身份摘要不一致）→ 拒收。
- 未经批准覆盖基础人物或复用旧审核摘要 → 拒收。
- 无来源链的新人物图 → 拒收。

## 7. 正反例
正例："同一个人换成针织衫、背景 AI 实验室，身份比对通过后登记为变体 v2"。
反例："换装后脸型发型明显不同，仍标成同一人物变体"。

## 8. 版本
0.2.0（2026-09-23 四角色与代码后期修订；参考图编辑与身份检测器均未实测）
