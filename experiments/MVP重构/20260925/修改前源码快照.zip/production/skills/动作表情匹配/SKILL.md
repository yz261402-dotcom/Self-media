# S05 动作表情匹配

版本：0.2.0 · 使用者：数字人导演（avatar），质量审核检查 · 状态：拟建，未验收

## 1. 触发条件
已定版人物与已确认音频就绪，需要按路线组织动作与口型作业时。

## 2. 输入引用
`AvatarIdentity`、`PerformancePlan.motion`、`GenerationRoute`、最终音频与预算确认记录。

## 3. 工作步骤
1. 把意图层的 `motion` 映射到已验证的动作参考与受支持参数，记录支持/近似/不支持。
2. M2：先准备动态底片（LivePortrait），再以最终音频做 MuseTalk 1.5 嘴型。
3. `OMNIHUMAN_1_5`：以人物图＋最终音频＋可选表演提示直接提交云生成，不再跑 MuseTalk。
4. 音频未确认或预算未授权时只做准备登记，不提交作业。
5. 检查循环接缝、肢体异常与嘴部异常；异常即登记问题与返工目标。

## 4. 允许调用的工具
`get_presenter_profile`、`prepare_motion_assets`、`submit_motion`、`submit_lipsync`、`submit_avatar_video`、`get_media_job`、`get_media_result`、`propose_memory`

## 5. 输出契约
作业 ID 与结果引用写入 `AgentResult.output_refs`；不支持的动作明确记录，不承诺任意动作。

## 6. 拒收 / 返工条件
- 承诺任意动作或把动作描述直接当成模型控制接口 → 拒收。
- M2 失败后静默切换到收费路线 → 拒收（必须阻断并等待用户选择）。
- 循环接缝明显、肢体/嘴部异常 → 返工。

## 7. 正反例
正例："表演意图『讲述、轻微点头』映射到已验证动作参考 `talk_calm_v1`"。
反例："用户写『边走边挥手』，直接声称支持并生成"。

## 8. 版本
0.2.0（2026-09-23 四角色与代码后期修订；长片、正式动作母版与 OmniHuman 均未验收）
