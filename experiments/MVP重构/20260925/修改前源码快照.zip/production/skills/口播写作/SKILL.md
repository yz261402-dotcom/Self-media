# S02 口播写作

版本：0.2.0 · 使用者：策划文案（content），声音/数字人只读产物 · 状态：拟建，未验收

## 1. 触发条件
用户已输入提示词，需要直接产出三个不同角度的候选口播稿及表演意图时，不等待网上检索。

## 2. 输入引用
S01 的角度说明、`Work.brief.target_duration_ms`、`ScriptVersion` 既有版本与审核结论。

## 3. 工作步骤
1. 按目标时长分配开头、解释、例子、收尾四段的字数（中文按每秒约 4.5–5 字估算）。
2. 三个候选分别走不同角度；标题、简介与正文必须一致。
3. 需要事实支撑处写明断言与已有材料引用，供 S03 核对；无依据的关键断言标待复核，不生成假链接。新稿不以提供资料为前提。
4. 生成 `PerformancePlan` 意图：每段 `segment_id/text/emotion/pace/emphasis/motion`，
   使用受控情绪词，不预造精确时间戳。
5. 不在正文里混入表达标记、时间戳或动作标签。

## 4. 允许调用的工具
`register_script_candidates`、`compile_performance_plan`、`propose_memory`

## 5. 输出契约
`ScriptBatch.candidates` 三个，各自带 `angle/title/description/tags/text/duration_estimate_ms/claims`；
写稿工作项的 `AgentResult.output_refs` 含 `batch_id`；用户选稿后的表演计划工作项才要求 `plan_id`。

## 6. 拒收 / 返工条件
- 论文腔、书面长句、与标题不符的正文 → 返工。
- 捏造事实或无法定位来源的数字 → 拒收（硬门禁）。
- 表达标记污染正文、不足三个角度 → 拒收。

## 7. 正反例
正例："开头 3 秒抛问题，15 秒给结论，再用一个具体例子解释，收尾给一句可执行建议"。
反例："正文中出现 `[emotion:excited]`、`00:12-00:15` 这类控制标记"。

## 8. 版本
0.2.0（2026-09-23 四角色与代码后期修订，写作质量与真实并行尚未验收）
