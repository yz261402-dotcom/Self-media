"""Qwen3 ASR/强制对齐 provider 的契约测试（不触网、不依赖 GPU）。

钉的是几条不能松的口子：
- 没配 worker 就是 blocked，不许用任何替代时间轴；
- 时间轴来源必须在白名单，均分时长不算对齐；
- 对齐没覆盖全文 → 阻断（"差不多"不能出字幕）；
- 断句只能落在标点后，拼接后与冻结正文逐字符一致。
"""
from __future__ import annotations

import os

import pytest

from app.video import asr as v_asr
from app.video import subtitles as v_sub
from app.video.errors import VideoBlocked


def test_unconfigured_worker_is_blocked(monkeypatch, tmp_path):
    monkeypatch.setenv("AVATAR_STUDIO_ASR_PROVIDER", "qwen3_cloud")
    monkeypatch.delenv("AVATAR_STUDIO_ASR_WORKER_URL", raising=False)
    adapter = v_asr.get_adapter()
    assert adapter is not None
    with pytest.raises(VideoBlocked) as e:
        adapter.transcribe(str(tmp_path / "a.wav"), "正文")
    assert e.value.code == "ASR_NOT_CONFIGURED"


def test_provider_registered_with_allowed_source():
    spec = v_asr.KNOWN_PROVIDERS["qwen3_cloud"]
    adapter = spec["adapter"]()
    assert adapter.alignment_source in v_asr.ALLOWED_ALIGNMENT_SOURCES
    assert adapter.simulated is False, "真实 provider 不得标 simulated"


def test_even_split_source_is_rejected(monkeypatch):
    """均分时长不算对齐：白名单之外的来源一律拒。"""
    monkeypatch.setenv("AVATAR_STUDIO_ASR_PROVIDER", "qwen3_cloud")

    class EvenSplit:
        provider_id = "even_split_fake"
        alignment_source = "even_split"
        simulated = False

        def transcribe(self, audio_path, script_text):
            return [{"start_ms": 0, "end_ms": 1000, "text": script_text}]

    monkeypatch.setitem(v_asr.KNOWN_PROVIDERS, "even_split_fake",
                        {"adapter": EvenSplit})
    monkeypatch.setenv("AVATAR_STUDIO_ASR_PROVIDER", "even_split_fake")
    with pytest.raises(VideoBlocked) as e:
        v_asr.require_adapter()
    assert e.value.code == "ASR_ALIGNMENT_SOURCE_INVALID"


def test_incomplete_coverage_is_blocked():
    items = [{"text": "你", "start": 0.0, "end": 0.2},
             {"text": "好", "start": 0.2, "end": 0.4}]
    # 正文里还有第三个字，对齐只给了两条
    with pytest.raises(VideoBlocked) as e:
        v_asr._restore_punctuation(items, "你好吗")
    assert e.value.code == "ALIGN_COVERAGE_INCOMPLETE"


def test_punctuation_restored_and_grouped_at_punctuation():
    text = "你有没有发现，越是想写好开头，越容易卡住？其实开头不需要惊艳，只需要具体。"
    words = [c for c in text if c not in "，。？"]
    items = [{"text": w, "start": 0.2 * i, "end": 0.2 * (i + 1)}
             for i, w in enumerate(words)]
    units = v_asr._restore_punctuation(items, text)
    assert "".join(u["text"] + u["tail"] for u in units) == text

    cues = v_asr._group_units(units)
    assert cues, "有声正文必须有字幕行"
    for c in cues:
        assert c["text"][-1] in "，。？！、；：", f"断句没落在标点上：{c['text']!r}"
    assert v_sub.normalize_text("".join(c["text"] for c in cues)) == \
        v_sub.normalize_text(text)


def test_cues_pass_subtitle_hard_checks():
    """分组结果要能过下游 check_cues：覆盖、顺序、越界、末句不贴边。"""
    text = "你有没有发现，越是想写好开头，越容易卡住？其实开头不需要惊艳，只需要具体。"
    words = [c for c in text if c not in "，。？"]
    items = [{"text": w, "start": 0.2 * i, "end": 0.2 * (i + 1)}
             for i, w in enumerate(words)]
    cues = v_asr._group_units(v_asr._restore_punctuation(items, text))

    class TL:
        def map_source_to_final(self, ms: int) -> int:
            return ms

    cue_objs = v_sub.map_cues(cues, TL())
    final_ms = int(items[-1]["end"] * 1000) + 3000
    res = v_sub.check_cues(cue_objs, final_duration_ms=final_ms, script_text=text)
    assert int(res["cue_count"]) == len(cues)
