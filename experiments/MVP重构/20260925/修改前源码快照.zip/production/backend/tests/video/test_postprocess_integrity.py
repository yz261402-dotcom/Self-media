"""后期版本绑定与失败证据回归；不提交任何远端作业。"""
from pathlib import Path

import pytest

from app import postprocess_worker as pw
from app import storage as st
from app.video import asr, ffmpeg
from app.video.errors import VideoBlocked


@pytest.fixture(autouse=True)
def isolated_database(monkeypatch, tmp_path):
    monkeypatch.setattr(st, "DB_PATH", str(tmp_path / "postprocess.db"))
    st.init_db()


def test_final_audio_uses_selected_id_and_current_script():
    work = {"id": "w", "final_audio_id": "selected", "voice_asset_id": "voice",
            "script_version_id": "script-current"}
    audio = {"id": "selected", "work_id": "w", "kind": "full", "approved": True,
             "confirmed": True, "voice_asset_id": "voice", "is_mock": False,
             "script_version_id": "script-current"}
    old = {**audio, "id": "old", "script_version_id": "script-old"}
    assert pw._final_audio(work, [old, audio])["id"] == "selected"
    assert pw._final_audio(work, [old]) is None
    assert pw._final_audio(work, [{**audio, "is_mock": True}]) is None
    assert pw._final_audio(work, [{**audio, "script_version_id": "script-old"}]) is None


def test_changed_script_or_provider_never_reuses_cached_alignment(monkeypatch, tmp_path):
    audio_path = tmp_path / "audio.wav"
    audio_path.write_bytes(b"audio hash fixture")
    calls = []

    class Adapter:
        provider_id = "one"
        alignment_source = "forced_alignment"
        simulated = False

        def transcribe(self, path, text):
            calls.append((self.provider_id, text))
            return [{"start_ms": 0, "end_ms": 500, "text": text}]

    adapter = Adapter()
    monkeypatch.setattr(asr, "require_adapter", lambda: adapter)
    audio = {"id": "a"}
    first = pw._asr_cues_cached(audio, str(audio_path), "甲")
    assert pw._asr_cues_cached(audio, str(audio_path), "甲")["reused"]
    changed = pw._asr_cues_cached(audio, str(audio_path), "乙")
    adapter.provider_id = "two"
    provider_changed = pw._asr_cues_cached(audio, str(audio_path), "乙")
    assert changed["reused"] is False
    assert provider_changed["reused"] is False
    assert calls == [("one", "甲"), ("one", "乙"), ("two", "乙")]
    assert st.get("alignment_records", first["id"])["cues"][0]["text"] == "甲"


def test_ffmpeg_installed_only_on_path_is_found(monkeypatch, tmp_path):
    exe = tmp_path / "ffmpeg.exe"
    exe.touch()
    monkeypatch.delenv(ffmpeg._ENV_BIN, raising=False)
    monkeypatch.setattr(ffmpeg, "_KNOWN_DIRS", ())
    monkeypatch.setattr(ffmpeg.shutil, "which", lambda name: str(exe))
    assert ffmpeg._candidates() == [str(exe)]


def test_failed_qwen_job_is_explicit_block_not_typeerror(monkeypatch):
    from app.digital_human import worker_client
    monkeypatch.setenv(asr.ASR_WORKER_URL_ENV, "http://worker.invalid")
    monkeypatch.setattr(worker_client, "transport", lambda *a, **k: {
        "json": {"state": "failed", "code": "GPU_OOM", "job_id": "job"}})
    with pytest.raises(VideoBlocked) as error:
        asr.Qwen3CloudAdapter()._run_stage("align", "http://audio.invalid", "sha256:x", "正文")
    assert error.value.code == "ASR_STAGE_FAILED"
    assert error.value.detail["job_id"] == "job"


def test_simulated_asr_cannot_enter_real_worker(monkeypatch):
    class Fixture:
        provider_id = "fixture"
        alignment_source = "forced_alignment"
        simulated = True

    monkeypatch.setattr(asr, "get_adapter", lambda: Fixture())
    with pytest.raises(VideoBlocked) as error:
        asr.require_adapter()
    assert error.value.code == "ASR_SIMULATED"


def test_word_alignment_preserves_latin_tokens_and_quoted_punctuation():
    units = asr._restore_punctuation([
        {"text": "试", "start": 0.0, "end": 0.2},
        {"text": "用", "start": 0.2, "end": 0.4},
        {"text": "RAG", "start": 0.4, "end": 0.9},
    ], "“试用 RAG”。")
    cues = asr._group_units(units)
    assert "".join(c["text"] for c in cues) == "“试用RAG”。"
    assert cues[-1]["end_ms"] == 900


def test_word_alignment_rejects_invalid_intervals():
    with pytest.raises(VideoBlocked) as error:
        asr._restore_punctuation([{"text": "字", "start": 1.0, "end": 0.2}], "字")
    assert error.value.code == "ALIGN_TIMING_INVALID"


def test_runtime_path_cannot_escape_media_root():
    with pytest.raises(VideoBlocked) as error:
        pw._runtime_path("../../outside.wav")
    assert error.value.code == "MEDIA_PATH_INVALID"
