"""T06 表演计划：分段必须是稿件的一个划分，计划随稿件变化而失效。

这里锁住 T04 已确立的不变量：各段按序拼接后与稿件**逐字符相同**，
一旦破坏，"保留原文"与字词对齐就都失去可核对的基准。
"""
from __future__ import annotations

import pytest

from app import storage as st
from app.tts import plan as tts_plan
from app.tts.errors import TtsRejected

WORK = "w_plan"
SCRIPT = "s_plan"


def _setup(text: str) -> None:
    st.put("script_batches", WORK,
           {"id": "b1", "work_id": WORK,
            "candidates": [{"id": SCRIPT, "angle": "生活类比", "title": "标题",
                            "text": text, "duration_estimate_ms": 1000,
                            "quality_report": {"checks": [], "overall": "pass",
                                               "review_required": False},
                            "claims": []}]},
           {"work_id": WORK})
    st.put("works", WORK,
           {"id": WORK, "name": "测试作品", "script_version_id": SCRIPT,
            "brief": {"topic": "RAG", "target_duration_ms": 60000}},
           {"id": WORK})


@pytest.mark.parametrize("text", [
    "第一句。\n第二句。\n第三句。",
    "只有一段。",
    "甲。\n\n\n乙。",          # 连续空行
    "\n前导空行的稿件。\n第二段。",
    "结尾带换行的段落。\n",
])
def test_segments_join_equals_script_exactly(text):
    """划分性质：拼接后逐字符等于原稿（换行留在前一段末尾）。"""
    segs = tts_plan.derive_segments(text)
    if not text.strip():
        assert segs == []
        return
    assert "".join(s["text"] for s in segs) == text


def test_created_plan_is_usable_and_bound_to_script():
    _setup("第一句。\n第二句。")
    plan = tts_plan.create_plan(WORK, SCRIPT)
    assert plan["script_version_id"] == SCRIPT
    assert tts_plan.is_usable(plan) is True


def test_plan_digest_follows_script_change():
    _setup("甲。\n乙。")
    first = tts_plan.create_plan(WORK, SCRIPT)
    batch = st.get("script_batches", WORK)
    batch["candidates"][0]["text"] = "甲。\n乙。\n丙。"
    st.put("script_batches", WORK, batch, {"work_id": WORK})
    second = tts_plan.create_plan(WORK, SCRIPT)
    assert first["script_digest"] != second["script_digest"], "稿件变了计划摘要必须变"


def test_tampered_plan_is_not_usable():
    _setup("甲。\n乙。")
    plan = tts_plan.create_plan(WORK, SCRIPT)
    plan["segments"][0]["text"] = "被改坏的文字"
    assert tts_plan.is_usable(plan) is False, "摘要不符即不可用，不得放行"


def test_missing_script_rejected():
    with pytest.raises(TtsRejected) as caught:
        tts_plan.create_plan("no_work", "no_script")
    assert caught.value.code == "STALE_SELECTION"


def test_empty_script_rejected():
    _setup("   ")
    with pytest.raises(TtsRejected) as caught:
        tts_plan.create_plan(WORK, SCRIPT)
    assert caught.value.code == "PLAN_SCRIPT_EMPTY"
