"""真实网络传输层契约测试：urllib_transport 对本地 mock 服务器发起真实 HTTP。

不触碰任何真实密钥、不访问外网；只验证传输层确实把请求发出去并把字节拿回来，
契约与 digital_human/providers.py 的 _resp_json 对齐（{status_code, body}）。
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

from app.digital_human import providers as pv


def _server_return(payload: dict):
    class H(BaseHTTPRequestHandler):
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0) or 0)
            self.rfile.read(n)
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    server = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, server.server_address[1]


def test_submit_request_url_carries_signed_query():
    """回归钉子（2026-09-23 实测踩坑）：签名覆盖的 Action/Version 必须真实
    出现在请求 URL 上，否则网关报 "missing Action parameter"。
    本测试不联网——只钉请求构造的 URL 形态。"""
    req = pv.build_submit_request(
        image_url="https://example.com/i.png", audio_url="https://example.com/a.wav",
        output_resolution="1080p",
        ak="AKLT-test", sk="c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0", x_date="20260923T000000Z")
    assert "Action=CVSubmitTask" in req["url"], req["url"]
    assert "Version=2022-08-31" in req["url"], req["url"]
    # output_resolution 必须转成 int（"1080p" 字符串会被云端预处理拒绝）
    assert req["json"]["output_resolution"] == 1080, req["json"]
    assert pv.normalize_resolution("720p") == 720
    assert pv.normalize_resolution("999") is None
    q_req = pv.build_query_request(task_id="t-1", ak="AKLT-test",
                                   sk="c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0",
                                   x_date="20260923T000000Z")
    assert "Action=CVGetResult" in q_req["url"], q_req["url"]
    assert "Version=2022-08-31" in q_req["url"], q_req["url"]


def test_urllib_transport_post_returns_status_and_body():
    server, port = _server_return({"data": {"task_id": "t1"}})
    try:
        resp = pv.urllib_transport(
            {"url": f"http://127.0.0.1:{port}/x", "method": "POST",
             "headers": {"X-Test": "1"}, "body": b"{}"})
        assert resp["status_code"] == 200
        assert json.loads(resp["body"]) == {"data": {"task_id": "t1"}}
    finally:
        server.shutdown()


def test_urllib_transport_get_works():
    server, port = _server_return({"ok": True})
    try:
        resp = pv.urllib_transport({"url": f"http://127.0.0.1:{port}/y", "method": "GET"})
        assert resp["status_code"] == 200
        assert json.loads(resp["body"]) == {"ok": True}
    finally:
        server.shutdown()


def test_urllib_transport_http_error_status():
    class H(BaseHTTPRequestHandler):
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0) or 0)
            self.rfile.read(n)
            self.send_response(403)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def log_message(self, *a):
            pass

    server = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        resp = pv.urllib_transport(
            {"url": f"http://127.0.0.1:{server.server_address[1]}/z", "method": "POST",
             "body": b"{}"})
        assert resp["status_code"] == 403
    finally:
        server.shutdown()
