
import json, sys
job_path, result_path = sys.argv[1], sys.argv[2]
job = json.load(open(job_path, encoding="utf-8"))
mode = __import__("os").environ.get("FAKE_RUNNER_MODE", "ok")
d = __import__("pathlib").Path(job_path).parent
if mode == "fail":
    json.dump({"state": "failed", "code": "OOM", "error": "显存不足"},
              open(result_path, "w", encoding="utf-8"))
elif mode == "crash":
    raise SystemExit(9)
elif mode == "slow":
    __import__("time").sleep(300)
    raise SystemExit(0)
else:
    out = d / "out.mp4"
    payload_path = __import__("os").environ["FAKE_PAYLOAD"]
    out.write_bytes(__import__("pathlib").Path(payload_path).read_bytes())
    json.dump({"state": "succeeded", "output_path": str(out), "duration_ms": 4200},
              open(result_path, "w", encoding="utf-8"))
