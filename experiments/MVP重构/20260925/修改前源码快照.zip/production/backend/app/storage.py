"""SQLite 仓储。首版以 JSON 列承载聚合体，写入走事务；后续可拆为列式表，不影响接口契约。

业务库是任务、选择、审批与账本的事实来源，Agent 只能经受控工具提交。
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional

DB_PATH = os.environ.get(
    "AVATAR_STUDIO_DB",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "runtime", "studio.db"),
)

_local = threading.local()

STAGE_LABEL = {
    "topic": "确定选题与来源",
    "script": "三角度写稿与表演说明",
    "content_review": "内容门禁与查重",
    "avatar_variant": "人物与表演准备",
    "tts": "试听选择与全文合成",
    "talking_head": "口播生成",
    "postprocess": "字幕、封面与编码",
    "video_review": "成片终审",
    "publish_package": "冻结发布包",
}

STAGE_ORDER = [
    "topic",
    "script",
    "content_review",
    "avatar_variant",
    "tts",
    "talking_head",
    "postprocess",
    "video_review",
    "publish_package",
]


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def conn() -> sqlite3.Connection:
    c: Optional[sqlite3.Connection] = getattr(_local, "conn", None)
    if c is None:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        c = sqlite3.connect(DB_PATH, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        _local.conn = c
    return c


def init_db() -> None:
    c = conn()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS works (id TEXT PRIMARY KEY, data TEXT NOT NULL, version INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS identities (id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS variants (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS voices (id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS script_batches (work_id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audios (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS task_events (task_id TEXT, seq INTEGER, data TEXT NOT NULL, PRIMARY KEY (task_id, seq));
        CREATE TABLE IF NOT EXISTS packages (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS confirmations (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS selections (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_work_items (id TEXT PRIMARY KEY, task_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_results (id TEXT PRIMARY KEY, work_item_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_tool_audit (id TEXT PRIMARY KEY, work_item_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS performance_plans (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS quality_decisions (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS memory_candidates (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS media_jobs (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS provider_jobs (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS provider_jobs_idem (idem_key TEXT PRIMARY KEY, job_id TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS resource_locks (id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS memory_entries (id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS mask_specs (id TEXT PRIMARY KEY, identity_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS lineage (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS avatar_assets (id TEXT PRIMARY KEY, identity_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS identity_reviews (id TEXT PRIMARY KEY, asset_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS motion_references (id TEXT PRIMARY KEY, identity_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS license_records (id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS provider_evidence (id TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS voice_previews (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audition_sentences (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS alignment_records (id TEXT PRIMARY KEY, audio_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS source_records (id TEXT PRIMARY KEY, subject TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audio_reviews (id TEXT PRIMARY KEY, audio_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS voice_samples (id TEXT PRIMARY KEY, voice_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS videos (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS provider_runs (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS plate_reviews (id TEXT PRIMARY KEY, video_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS video_reviews (id TEXT PRIMARY KEY, video_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audio_track_checks (id TEXT PRIMARY KEY, video_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS price_snapshots (id TEXT PRIMARY KEY, route TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS cost_confirmations (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS segment_plans (id TEXT PRIMARY KEY, work_id TEXT, data TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_video_work ON videos(work_id);
        CREATE INDEX IF NOT EXISTS idx_prun_work ON provider_runs(work_id);
        CREATE INDEX IF NOT EXISTS idx_plate_review ON plate_reviews(video_id);
        CREATE INDEX IF NOT EXISTS idx_video_review ON video_reviews(video_id);
        CREATE INDEX IF NOT EXISTS idx_segplan_work ON segment_plans(work_id);
        CREATE INDEX IF NOT EXISTS idx_vpreview_work ON voice_previews(work_id);
        CREATE INDEX IF NOT EXISTS idx_align_audio ON alignment_records(audio_id);
        CREATE INDEX IF NOT EXISTS idx_srcrec_subject ON source_records(subject);
        CREATE INDEX IF NOT EXISTS idx_audio_review ON audio_reviews(audio_id);
        CREATE INDEX IF NOT EXISTS idx_vsample_voice ON voice_samples(voice_id);
        CREATE INDEX IF NOT EXISTS idx_awi_task ON agent_work_items(task_id);
        CREATE INDEX IF NOT EXISTS idx_asset_identity ON avatar_assets(identity_id);
        CREATE INDEX IF NOT EXISTS idx_review_asset ON identity_reviews(asset_id);
        CREATE INDEX IF NOT EXISTS idx_motion_identity ON motion_references(identity_id);
        CREATE INDEX IF NOT EXISTS idx_audit_item ON agent_tool_audit(work_item_id);
        CREATE INDEX IF NOT EXISTS idx_pjob_work ON provider_jobs(work_id);
        CREATE INDEX IF NOT EXISTS idx_mem_ns ON memory_entries(data);
        """
    )
    c.commit()
    _seed()


def _seed() -> None:
    """初始预设来自本项目已定版资产（人物 B / 音色 3），登记不继承生产质量通过结论。"""
    c = conn()
    n = c.execute("SELECT COUNT(*) AS n FROM identities").fetchone()["n"]
    if n == 0:
        put(
            "identities",
            "av_base_b_v1",
            {
                "id": "av_base_b_v1",
                "name": "人物 B",
                "persona": "约 22 岁成年女性，专业、亲和、自然；正面半身构图",
                "hero_asset_id": "img_hero_b_v1",
                "identity_digest": "sha256:preset-identity-b-v1",
                "default_voice_asset_id": "voice_minimax_warm_bestie_v1",
                "approval_state": "approved",
                "is_preset": True,
                "note": "本项目已选初始预设；原图 941×1672，参考集与变体仍待补齐验收",
            },
        )
    n = c.execute("SELECT COUNT(*) AS n FROM voices").fetchone()["n"]
    if n == 0:
        sample = "大家好，今天我们用三分钟讲清楚一个容易被忽略的细节。"
        put(
            "voices",
            "voice_minimax_warm_bestie_v1",
            {
                "id": "voice_minimax_warm_bestie_v1",
                "name": "音色 3 · Warm Bestie",
                "provider": "minimax",
                "model": "speech-2.8-hd",
                "region": "cn",
                "remote_voice_id": "Chinese (Mandarin)_Warm_Bestie",
                "approval_state": "approved",
                "is_preset": True,
                "sample_text": sample,
                "supported_emotions": ["calm"],
                "note": "已选初始预设；其他情绪、多稿件与长稿仍待验收。"
                        "作用域/来源/权属/基准合成证据由 tts.preset.bootstrap_preset_voice 补登记",
            },
        )
        put(
            "voices",
            "voice_minimax_calm_v1",
            {
                "id": "voice_minimax_calm_v1",
                "name": "音色 2 · Calm（候选）",
                "provider": "minimax",
                "model": "speech-2.8-hd",
                "region": "cn",
                "remote_voice_id": "Chinese (Mandarin)_Calm_Woman",
                "approval_state": "pending",
                "is_preset": False,
                "sample_text": sample,
                "supported_emotions": ["calm"],
                "note": "候选：remote_voice_id 未经本项目实测，且缺来源/权属/基准合成证据，"
                        "不得直接用于生产；经明确选择后须创建独立绑定并重新验收",
            },
        )

    # 预设音色 3 的受控登记（作用域/来源/权属/基准合成证据）。幂等；
    # 缺少素材时只登记能登记的部分并把缺口写进 note，不静默跳过。
    try:
        from .tts import preset as tts_preset

        tts_preset.bootstrap_preset_voice()
    except Exception as e:  # 初始化不得因缺素材而整体失败
        print(f"[seed] 预设音色基准证据登记未完成：{type(e).__name__}: {e}")


@contextmanager
def transaction():
    """写事务（BEGIN IMMEDIATE）：租约竞争与预算预留必须在同一事务内检查-写入，
    否则两个 Worker 会同时读到"空闲"并各自占槽。
    """
    c = conn()
    c.execute("BEGIN IMMEDIATE")
    try:
        yield c
        c.execute("COMMIT")
    except Exception:
        c.execute("ROLLBACK")
        raise


def put(table: str, key: str, data: dict, extra: Optional[Dict[str, Any]] = None) -> None:
    c = conn()
    insert_row(c, table, key, data, extra)
    c.commit()


def insert_row(c: sqlite3.Connection, table: str, key: str, data: dict,
               extra: Optional[Dict[str, Any]] = None) -> None:
    """写入但不提交：供 transaction() 内使用，避免 put() 的隐式 COMMIT 打断事务。"""
    cols = {"works": "id", "identities": "id", "variants": "id", "voices": "id",
            "audios": "id", "tasks": "id", "packages": "id", "confirmations": "id",
            "selections": "id", "script_batches": "work_id",
            "agent_work_items": "id", "agent_results": "id", "agent_tool_audit": "id",
            "performance_plans": "id", "quality_decisions": "id",
            "memory_candidates": "id", "media_jobs": "id",
            "provider_jobs": "id", "memory_entries": "id", "lineage": "id",
            "resource_locks": "id", "avatar_assets": "id", "identity_reviews": "id",
            "motion_references": "id", "license_records": "id",
            "mask_specs": "id",
            "provider_evidence": "id",
            "voice_previews": "id", "audition_sentences": "id",
            "alignment_records": "id", "source_records": "id",
            "audio_reviews": "id", "voice_samples": "id",
            "videos": "id", "provider_runs": "id", "plate_reviews": "id",
            "video_reviews": "id", "audio_track_checks": "id",
            "price_snapshots": "id",
            "cost_confirmations": "id", "segment_plans": "id"}[table]
    payload = json.dumps(data, ensure_ascii=False)
    if extra:
        names = [cols] + list(extra.keys())
        marks = ",".join("?" * (len(names) + 1))
        vals = [key] + list(extra.values()) + [payload]
        c.execute(f"INSERT OR REPLACE INTO {table} ({','.join(names)},data) VALUES ({marks})", vals)
    else:
        c.execute(f"INSERT OR REPLACE INTO {table} ({cols},data) VALUES (?,?)", [key, payload])


def get(table: str, key: str) -> Optional[dict]:
    c = conn()
    cols = {"script_batches": "work_id"}.get(table, "id")
    row = c.execute(f"SELECT data FROM {table} WHERE {cols}=?", [key]).fetchone()
    return json.loads(row["data"]) if row else None


def all_rows(table: str, where: Optional[str] = None, args: Optional[list] = None) -> List[dict]:
    c = conn()
    sql = f"SELECT data FROM {table}"
    if where:
        sql += f" WHERE {where}"
    rows = c.execute(sql, args or []).fetchall()
    return [json.loads(r["data"]) for r in rows]


def add_event(task_id: str, event: dict) -> dict:
    c = conn()
    seq = c.execute("SELECT COALESCE(MAX(seq),0)+1 AS s FROM task_events WHERE task_id=?", [task_id]).fetchone()["s"]
    event["seq"] = seq
    c.execute("INSERT OR REPLACE INTO task_events (task_id,seq,data) VALUES (?,?,?)",
              [task_id, seq, json.dumps(event, ensure_ascii=False)])
    c.commit()
    return event


def events_since(task_id: str, after_seq: int = 0) -> List[dict]:
    c = conn()
    rows = c.execute(
        "SELECT data FROM task_events WHERE task_id=? AND seq>? ORDER BY seq", [task_id, after_seq]
    ).fetchall()
    return [json.loads(r["data"]) for r in rows]


def stage_rows(stage: str, state: str) -> List[dict]:
    idx = STAGE_ORDER.index(stage) if stage in STAGE_ORDER else 0
    out = []
    for i, s in enumerate(STAGE_ORDER):
        st = "pending"
        if state == "failed" and i == idx:
            st = "failed"
        elif state == "blocked" and i == idx:
            st = "blocked"
        elif i < idx:
            st = "done"
        elif i == idx:
            st = "done" if state == "succeeded" else "active"
        out.append({"stage": s, "label": STAGE_LABEL[s], "state": st, "detail": ""})
    return out
