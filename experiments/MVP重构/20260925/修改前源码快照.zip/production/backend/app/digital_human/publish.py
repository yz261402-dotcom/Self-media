"""把本地素材发布到火山 TOS 公开读，返回 VOLC 境内可直连 GET 的 https URL。

背景
----
OmniHuman 标准接口只接受 `image_url` / `audio_url` 两个 **http(s) 媒体 URL**
（见 `providers.build_submit_request` 与 `submission._require_public_url`），
本地相对路径一律被拒。本项目资产默认落在本机磁盘，真实链路跑批前必须先发布到
**大陆可达的公开存储**。TOS 与 VOLC 同属火山引擎，境内机房直连、VOLC 必能抓取。

实现
----
使用火山官方 TOS Python SDK（`tos`，即 ve-tos-python-sdk），而非裸 boto3——
TOS 网关不认 boto3 的请求/签名格式（直接调会 400 Bad Request）。
- `endpoint`：`tos-<region>.volces.com`；`region`：`cn-beijing`（华北2·北京）。
- 发布时给对象打 `ACLType.PUBLIC_READ`，使对象可被匿名 GET；桶保持私有。
- 公开访问域名：`<bucket>.tos-<region>.volces.com/<key>`。

注意：本模块不替你下"法律结论"——public-read 意味着任何人可下载该对象，
只放脱敏的口播素材（人物图/音频），不放密钥/PII。
"""
from __future__ import annotations

import os
from typing import Optional

import tos
from tos.enum import ACLType

TOS_DEFAULT_ENDPOINT = "tos-cn-beijing.volces.com"
TOS_DEFAULT_REGION = "cn-beijing"


def public_url(bucket: str, region: str, key: str) -> str:
    """TOS 虚拟主机风格公开访问地址（对象已 PUBLIC_READ 时可直接 GET）。"""
    return f"https://{bucket}.tos-{region}.volces.com/{key}"


class TosPublisher:
    """极简 TOS 发布器：本地文件 -> PUBLIC_READ 对象 -> 公开 https URL。"""

    def __init__(self, ak: str, sk: str, bucket: str, region: str = TOS_DEFAULT_REGION,
                 endpoint: Optional[str] = None) -> None:
        if not ak or not sk:
            raise ValueError("TOS 发布需要 ak/sk（与 VOLC 共用同一套火山 IAM 凭据）")
        if not bucket:
            raise ValueError("必须指定 TOS bucket 名（全局唯一）")
        self.bucket = bucket
        self.region = region
        self.client = tos.TosClientV2(
            ak, sk, endpoint or TOS_DEFAULT_ENDPOINT, region
        )

    def ensure_bucket(self) -> None:
        """不存在则建桶；已存在则忽略；未开通/无权限等异常向上抛出。"""
        try:
            self.client.create_bucket(self.bucket)
        except Exception as e:  # noqa: BLE001
            code = getattr(e, "code", "")
            if code in ("BucketAlreadyExists", "BucketAlreadyOwnedByYou"):
                return
            raise

    def publish_file(self, local_path: str, key: Optional[str] = None,
                     content_type: Optional[str] = None) -> str:
        """上传本地文件为 PUBLIC_READ 对象，返回公开 URL。"""
        if not os.path.isfile(local_path):
            raise FileNotFoundError(f"待发布文件不存在: {local_path}")
        if key is None:
            key = os.path.basename(local_path)
        self.client.put_object_from_file(
            self.bucket, key, local_path,
            content_type=content_type, acl=ACLType.ACL_Public_Read,
        )
        return public_url(self.bucket, self.region, key)

    def exists(self, key: str) -> bool:
        """对象是否已存在（用于幂等：已发布则直接返回 URL）。"""
        try:
            self.client.head_object(self.bucket, key)
            return True
        except Exception:  # noqa: BLE001 - 任意 404/403 都视为不存在
            return False
