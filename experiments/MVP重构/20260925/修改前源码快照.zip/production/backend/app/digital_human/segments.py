"""OmniHuman 约 60 秒分段（AC-TH-05）。

分段的唯一合法来源是**同一条已确认音轨的句子边界**：

- 切点来自对齐产物（provider 时间戳/强制对齐/ASR 对齐）的真实毫秒位置，
  不是按字符数平均切、也不是按目标时长反推；
- 每段严格小于当前规范上限（60 秒），超限在提交前就拒绝；
- **禁止加速、禁止截字**：为了让音频塞进上限而改速度或砍掉字词，
  是把约束违约伪装成通过；
- 每段保存相对统一音轨的全局偏移，拼接与字幕映射都靠它。
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .. import storage as st
from ..contracts import now_iso
from ..tts import audio as tts_audio
from ..tts import gate as tts_gate
from .errors import TalkingHeadBlocked, TalkingHeadRejected
from .routes import OMNIHUMAN_LIMIT

SEGMENT_PLAN_TABLE = "segment_plans"

# 句子结束标点。切点只允许落在这些字符之后——在句子中间切开会让每段的
# 语调重新起头，听感上"每段都像第一句"。
SENTENCE_ENDINGS = "。！？!?…；;\n"
# 段内最小时长：过短的尾段（比如只剩一个字）会单独产生一次计费调用，先合并
MIN_SEGMENT_MS = 900


def _limit_ms() -> int:
    return int(OMNIHUMAN_LIMIT["audio_max_seconds_exclusive"] * 1000)


def _sentence_bounds(text: str) -> List[int]:
    """返回句子结束字符的 index（该字符本身归属前一句）。"""
    return [i for i, ch in enumerate(text) if ch in SENTENCE_ENDINGS]


def build_segments(text: str, words: List[Dict[str, Any]], duration_ms: int,
                   *, limit_ms: Optional[int] = None) -> List[Dict[str, Any]]:
    """按句边界把文本映射到真实音频时间。要求词级时间戳覆盖全文。"""
    limit = limit_ms or _limit_ms()
    if not words:
        raise TalkingHeadBlocked(
            "SEGMENTATION_REQUIRES_ALIGNMENT",
            "分段必须基于真实字词时间戳：均分时长或未验证逐句时长不能作为切分依据；"
            "先完成并登记对齐产物",
        )
    if not text:
        raise TalkingHeadRejected("SEGMENT_TEXT_EMPTY", "稿件正文为空，无法分段")

    ordered = sorted(words, key=lambda w: (int(w.get("start_char", 0)), int(w.get("start_ms", 0))))
    char_to_ms: Dict[int, int] = {}
    for w in ordered:
        sc, ec = int(w.get("start_char", 0)), int(w.get("end_char", 0))
        for c in range(sc, ec):
            char_to_ms.setdefault(c, int(w.get("start_ms", 0)))
        if ec > 0:
            char_to_ms[ec - 1] = int(w.get("end_ms", w.get("start_ms", 0)))

    ends = _sentence_bounds(text)
    cuts: List[int] = []
    for e in ends:
        if not cuts or e + 1 - cuts[-1] >= 40:
            cuts.append(e + 1)
    if not cuts or cuts[-1] != len(text):
        cuts.append(len(text))

    def ms_at(char_index: int) -> int:
        """字符位置对应的起始时间。

        边界时间必须**按定义**取同一个函数值：第 i 段的结束就是第 i+1 段的开始，
        否则拼起来要么漏字要么重字。文本末尾直接取音频总时长。
        """
        if char_index >= len(text):
            return int(duration_ms)
        for c in range(char_index, -1, -1):
            if c in char_to_ms:
                return char_to_ms[c]
        raise TalkingHeadRejected(
            "SEGMENT_TIMING_GAP",
            f"对齐结果未覆盖字符位置 {char_index}，无法建立可信切点；"
            "不得用估算值补齐",
        )

    raw: List[Dict[str, Any]] = []
    prev_char = 0
    for cut in cuts:
        seg_text = text[prev_char:cut]
        if not seg_text.strip():
            prev_char = cut
            continue
        raw.append({"index": len(raw), "text": seg_text,
                    "start_char": prev_char, "end_char": cut,
                    "start_ms": ms_at(prev_char), "end_ms": ms_at(cut)})
        prev_char = cut

    # 过短的尾段并入前一段：单独一次调用既贵又容易在接缝处出问题。
    # 但合并后若会顶到上限，就不合并——上限优先于省钱，且超限必须暴露而不是被"顺手"绕过。
    merged: List[Dict[str, Any]] = []
    for seg in raw:
        prev = merged[-1] if merged else None
        if prev and (seg["end_ms"] - seg["start_ms"]) < MIN_SEGMENT_MS \
                and (seg["end_ms"] - prev["start_ms"]) < limit:
            prev["text"] += seg["text"]
            prev["end_char"] = seg["end_char"]
            prev["end_ms"] = seg["end_ms"]
            continue
        merged.append(seg)

    out: List[Dict[str, Any]] = []
    for i, seg in enumerate(merged):
        seg["index"] = i
        seg["segment_id"] = f"oh_seg_{i + 1}"
        seg["duration_ms"] = seg["end_ms"] - seg["start_ms"]
        seg["global_offset_ms"] = seg["start_ms"]
        seg["over_limit"] = seg["duration_ms"] >= limit
        out.append(seg)
    total = sum(s["duration_ms"] for s in out)
    return out


def assert_segments_submittable(segments: List[Dict[str, Any]]) -> Dict[str, Any]:
    """提交前拦截：任一超限、拼接不覆盖全文、或偏移不连续都拒绝。"""
    if not segments:
        raise TalkingHeadRejected("SEGMENTS_EMPTY", "没有可提交的分段")
    limit = _limit_ms()
    over = [s for s in segments if s["duration_ms"] >= limit]
    if over:
        raise TalkingHeadRejected(
            "SEGMENT_EXCEEDS_LIMIT",
            f"分段 {[s['segment_id'] for s in over]} 达到或超过 {limit}ms 上限；"
            "规范要求严格小于上限，禁止加速或截字",
            {"over": [{"segment_id": s["segment_id"], "duration_ms": s["duration_ms"]}
                      for s in over]},
        )
    for i, s in enumerate(segments):
        if s["index"] != i:
            raise TalkingHeadRejected("SEGMENT_INDEX_NONCONTIGUOUS", "分段序号不连续")
        if i and s["global_offset_ms"] != segments[i - 1]["end_ms"]:
            raise TalkingHeadRejected(
                "SEGMENT_OFFSET_GAP",
                f"分段 {s['segment_id']} 的全局偏移与上一段结束时间不连续；"
                "拼接后会出现漏字或重字",
            )
    return {
        "segments": len(segments),
        "total_ms": sum(s["duration_ms"] for s in segments),
        "max_segment_ms": max(s["duration_ms"] for s in segments),
        "limit_ms": limit,
        "speedup_applied": False,
        "truncation_applied": False,
        "note": "按同一确认音轨的句子边界切分；未加速、未截字，偏移为音频全局时间",
    }


def create_plan(work_id: str, *, limit_ms: Optional[int] = None,
                text: Optional[str] = None) -> Dict[str, Any]:
    """为作品建立分段计划。要求已确认最终音频 + 可用对齐 + 冻结计划正文。"""
    work = st.get("works", work_id)
    if not work:
        raise TalkingHeadRejected("WORK_NOT_FOUND", f"作品不存在：{work_id}")
    audio = tts_audio.final_audio(work_id)
    if not audio:
        raise TalkingHeadBlocked("FINAL_AUDIO_REQUIRED", "尚无已确认最终音频，分段无从谈起")
    if audio.get("is_mock"):
        raise TalkingHeadBlocked("FINAL_AUDIO_IS_MOCK", "占位音频不得用于分段与提交")
    alignment = tts_gate.alignment_status(work_id)
    if not alignment.get("aligned"):
        raise TalkingHeadBlocked("SEGMENTATION_REQUIRES_ALIGNMENT",
                                alignment.get("reason", "对齐未完成，无法取真实切点"))
    rows = st.all_rows("alignment_records", "audio_id=?", [audio["id"]])
    latest = sorted(rows, key=lambda r: r.get("created_at", ""))[-1]

    body = text
    if body is None:
        plan_id = work.get("performance_plan_id")
        if not plan_id:
            raise TalkingHeadRejected("PLAN_REQUIRED", "缺少冻结 PerformancePlan，正文来源不明")
        from ..tts import compiler as tts_compiler

        # 正文只从**冻结计划**读：分段与朗读映射必须同一来源，
        # 不允许因为"works 里也存了一份正文"就绕过冻结校验。
        frozen = tts_compiler.load_frozen_plan(plan_id)
        body = tts_compiler.script_text_of(work_id, frozen["script_version_id"])

    segments = build_segments(body, latest.get("words", []),
                              int(audio.get("duration_ms") or 0), limit_ms=limit_ms)
    summary = assert_segments_submittable(segments)
    plan = {
        "id": st.new_id("segplan"), "work_id": work_id,
        "audio_asset_id": audio["id"], "audio_digest": audio.get("file_hash", ""),
        "audio_duration_ms": int(audio.get("duration_ms") or 0),
        "alignment_id": latest.get("id"), "alignment_source": latest.get("source"),
        "text_digest": latest.get("audio_digest", ""),
        "limit_ms": _limit_ms(), "segments": segments, "summary": summary,
        "created_at": now_iso(),
        "note": "分段只从冻结计划正文与同一音轨的真实时间派生；不维护第二份可编辑分段稿",
    }
    st.put(SEGMENT_PLAN_TABLE, plan["id"], plan, {"work_id": work_id})
    return plan


def latest_plan(work_id: str) -> Optional[Dict[str, Any]]:
    rows = st.all_rows(SEGMENT_PLAN_TABLE, "work_id=?", [work_id])
    if not rows:
        return None
    return sorted(rows, key=lambda r: r.get("created_at", ""))[-1]


def segment_status(work_id: str) -> Dict[str, Any]:
    plan = latest_plan(work_id)
    if not plan:
        return {"work_id": work_id, "planned": False,
                "reason": "尚未建立分段计划（需要已确认音频与可用对齐）"}
    return {"work_id": work_id, "planned": True, "plan_id": plan["id"],
            **plan["summary"],
            "segments": [{"segment_id": s["segment_id"], "duration_ms": s["duration_ms"],
                          "global_offset_ms": s["global_offset_ms"]}
                         for s in plan["segments"]]}
