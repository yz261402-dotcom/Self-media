"""M2 远端 GPU Worker 的客户端运输层。

补的是 providers.build_liveportrait_request / build_musetalk_request 与
urllib_transport 之间**缺的那一段**：

    build_*_request() -> {"stage","model","args"}        ← 没有 url！
    urllib_transport(req) -> 读 req["url"]               ← 因此会 KeyError

也就是说，在补这层之前，「把 M2 的 request 直接喂给 urllib_transport」是跑不通的，
而 HTTP 端点又从来没有传过 transport，所以 M2 从界面发起必然是
M2_TRANSPORT_UNAVAILABLE——这与"M2 有没有部署好"无关，纯粹是接线没做。

本模块负责：
  1. 把 stage/model/args 翻译成 POST /v1/jobs 的真实 HTTP 请求；
  2. 提交后轮询 GET /v1/jobs/{id} 直到终态（LivePortrait 实测 53s、
     MuseTalk 182s，同步等待一次调用不合理，必须轮询）；
  3. 让 worker 的 output_url 也能下载（自动补 Bearer token）。
     ——download_and_verify 传进来的只有 {"method","url"}，不加 token 会被 401 拒。

**判定纪律**（与 provider 层一致）：
  - 未配置 worker 地址 → TalkingHeadBlocked（等配置，不是改输入）；
  - 超时未完成 → 报 running/unknown，**绝不改判失败**；作业还在远端跑着，
    排队不是失败，这是本项目既有的红线。
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Callable, Dict, Optional

from .errors import TalkingHeadBlocked
from .providers import M2_TOKEN_ENV, M2_URL_ENV, urllib_transport

DEFAULT_POLL_INTERVAL_SEC = 5.0
DEFAULT_MAX_WAIT_SEC = 1800.0  # 30 分钟：覆盖实测 182s 并留足排队与冷启动
MAX_WAIT_ENV = "AVATAR_STUDIO_M2_MAX_WAIT_SEC"
POLL_INTERVAL_ENV = "AVATAR_STUDIO_M2_POLL_INTERVAL_SEC"

_SUBMIT_PATH = "/v1/jobs"
# parse_m2_response 认识的状态词：succeeded / failed / queued / running / error
_TERMINAL = ("succeeded", "failed")


def worker_url() -> str:
    return (os.environ.get(M2_URL_ENV) or "").strip().rstrip("/")


def worker_token() -> str:
    return (os.environ.get(M2_TOKEN_ENV) or "").strip()


def configured() -> bool:
    return bool(worker_url())


def _auth_headers(token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {token}"} if token else {}


def build_job_request(stage_request: Dict[str, Any], *, base_url: str,
                      token: str = "", allowed_stages=("motion", "lipsync")) -> Dict[str, Any]:
    """把 build_*_request 的产物翻译成真实 HTTP 请求。

    stage_request 里缺关键的 stage/args 时不补默认值——那是请求不成立，
    应该在 needs_repair 之前就暴露出来。

    `allowed_stages` 默认仍是 M2 两阶段；字幕链路（asr/align）复用同一个
    worker 程序与同一套轮询语义，只是阶段不同，因此显式传入而不是改默认值，
    免得把"M2 只认两个阶段"这条既有约束悄悄放宽。
    """
    stage = str(stage_request.get("stage") or "").strip()
    args = stage_request.get("args")
    if stage not in allowed_stages:
        raise TalkingHeadBlocked(
            "M2_REQUEST_SHAPE_INVALID",
            f"无法构造 worker 请求：stage={stage!r} 不在 {tuple(allowed_stages)}；"
            "这说明 build_*_request 的输出形状与 worker 契约不一致",
            {"stage": stage})
    if not isinstance(args, dict):
        raise TalkingHeadBlocked(
            "M2_REQUEST_SHAPE_INVALID",
            "无法构造 worker 请求：args 缺失或不是对象",
            {"args_type": type(args).__name__})

    body = json.dumps({"stage": stage,
                       "model": stage_request.get("model") or "",
                       "args": args},
                      ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    headers.update(_auth_headers(token))
    return {"method": "POST", "url": f"{base_url}{_SUBMIT_PATH}",
            "headers": headers, "body": body}


def build_status_request(base_url: str, job_id: str, *, token: str = "") -> Dict[str, Any]:
    url = f"{base_url}{_SUBMIT_PATH}/{job_id}"
    headers = {"Accept": "application/json"}
    headers.update(_auth_headers(token))
    return {"method": "GET", "url": url, "headers": headers}


def _inject_token(request: Dict[str, Any], base_url: str, token: str) -> Dict[str, Any]:
    """给指向 worker 的请求补鉴权。外部对象存储 URL 不动——token 不外泄。"""
    if not token:
        return request
    url = str(request.get("url") or "")
    headers = dict(request.get("headers") or {})
    if url.startswith(base_url) and not headers.get("Authorization"):
        headers["Authorization"] = f"Bearer {token}"
        request = dict(request, headers=headers)
    return request


def _doc_of(resp: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if isinstance(resp.get("json"), dict):
        return resp["json"]
    body = resp.get("body")
    if not body:
        return None
    if isinstance(body, str):
        body = body.encode("utf-8", "replace")
    try:
        parsed = json.loads(body.decode("utf-8"))
    except Exception:  # noqa: BLE001 - 非 JSON 由上层 parse 归类
        return None
    return parsed if isinstance(parsed, dict) else None


def transport(request: Dict[str, Any], *, base_url: Optional[str] = None,
              token: Optional[str] = None, inner: Optional[Callable] = None,
              poll_interval: Optional[float] = None,
              max_wait: Optional[float] = None,
              allowed_stages=("motion", "lipsync"),
              sleep: Callable[[float], None] = time.sleep,
              clock: Callable[[], float] = time.monotonic) -> Dict[str, Any]:
    """提交（必要时轮询）到 worker，返回最终响应（dict 形态，喂给 parse_m2_response）。

    返回体兼容 _resp_json 的两种取法：优先放 "json"，同时保留原始 body。
    """
    base = (base_url if base_url is not None else worker_url()).rstrip("/")
    tok = token if token is not None else worker_token()
    send = inner or urllib_transport

    if not base:
        # transport 存在但没有目标地址：这是"还没配好"，不是"提交被拒"。
        raise TalkingHeadBlocked(
            "M2_TRANSPORT_UNAVAILABLE",
            f"未配置 {M2_URL_ENV}：M2 推理在算力云上执行，未接通时不得假装已提交",
            {"env": M2_URL_ENV})

    # 下载请求：原样透传，只对 worker 域名补 token
    if request.get("url") and "stage" not in request:
        return send(_inject_token(request, base, tok))

    submit_req = build_job_request(request, base_url=base, token=tok,
                                   allowed_stages=allowed_stages)
    resp = send(submit_req)
    status = resp.get("status_code")
    if status is None or (status and status >= 400):
        return resp  # 网络层错误/4xx/5xx：交给 parse_m2_response 归类为 unknown

    doc = _doc_of(resp) or {}
    job_id = str(doc.get("job_id") or "")
    state = str(doc.get("state") or "").strip()
    if not job_id:
        return resp  # 没有 job_id 就无法追踪，同样交给上层判定
    if state in _TERMINAL:
        return resp

    interval = float(poll_interval if poll_interval is not None
                     else os.environ.get(POLL_INTERVAL_ENV, "") or DEFAULT_POLL_INTERVAL_SEC)
    budget = float(max_wait if max_wait is not None
                   else os.environ.get(MAX_WAIT_ENV, "") or DEFAULT_MAX_WAIT_SEC)
    started = clock()
    while True:
        remaining = budget - (clock() - started)
        if remaining <= 0:
            break
        sleep(min(interval, remaining))
        poll_resp = send(build_status_request(base, job_id, token=tok))
        p_status = poll_resp.get("status_code")
        if p_status is None:
            return poll_resp  # 网络中断：结果未知，归 unknown
        if p_status >= 400:
            return poll_resp
        poll_doc = _doc_of(poll_resp) or {}
        if str(poll_doc.get("state") or "").strip() in _TERMINAL:
            return {"status_code": 200, "body": json.dumps(
                poll_doc, ensure_ascii=False).encode("utf-8"), "json": poll_doc}

    timed_out = dict(doc, state="running", job_id=job_id, waited_seconds=round(
        clock() - started, 1),
        note=(f"轮询 {budget:.0f}s 内未到终态；作业仍在远端执行，"
              "不改判失败，可稍后继续查询"))
    return {"status_code": 200, "json": timed_out,
            "body": json.dumps(timed_out, ensure_ascii=False).encode("utf-8")}


def make_transport(*, base_url: Optional[str] = None, token: Optional[str] = None,
                   poll_interval: Optional[float] = None,
                   max_wait: Optional[float] = None) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """给 HTTP 端点用的工厂：未配置地址时返回 None 语义由调用方处理。

    这里故意不返回一个"看起来能用"的空实现——返回 None 会让既有的
    M2_TRANSPORT_UNAVAILABLE blocked 路径生效，那是正确的行为。
    """
    if not configured() and base_url is None:
        return None  # type: ignore[return-value]

    def _t(request: Dict[str, Any]) -> Dict[str, Any]:
        return transport(request, base_url=base_url, token=token,
                         poll_interval=poll_interval, max_wait=max_wait)
    return _t
