"""口播提交编排：路线选择 → 前置门禁 → 费用门禁 → 提交 → 查询 → 登记产物。

这里集中体现 T05 的几条"不许含糊"：

- **提交前的门禁是叠加的，不是或的关系。** 路线确认、人物/变体审核、稿件与计划冻结、
  音频确认、底片审核（M2）、费用确认与预算授权，任何一个不过都停在原地。
- **失败保留，不自动回退。** OmniHuman 失败不会切到 M2，也不会自动改用别的云口播；
  M2 失败不会偷偷跑一次 MuseTalk 修补。失败文件、远端 ID、参数、费用一律留证。
- **结果未知先对账。** 提交丢响应 → `unknown`。既不重提（可能已有费用），
  也不改判（没有证据）。要重做必须显式授权。
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from .. import config, jobs, storage as st
from ..contracts import ProviderRun, now_iso
from ..tts import audio as tts_audio
from . import cost as dh_cost
from . import providers as pv
from . import routes as dh_routes
from . import segments as sg
from . import videos as vd
from .errors import TalkingHeadBlocked, TalkingHeadRejected

RUN_TABLE = "provider_runs"


def call_list_digest(route: str, *, audio_id: str, audio_hash: str, variant_id: Optional[str],
                     motion_ref_id: Optional[str], prompt: str, resolution: str,
                     segment_count: int, plate_id: Optional[str] = None) -> str:
    """调用清单摘要。金额/输入/路线变化必须导致摘要变化，从而触发重新确认。"""
    payload = {
        "route": route, "audio_id": audio_id, "audio_hash": audio_hash,
        "variant_id": variant_id, "motion_ref_id": motion_ref_id,
        "plate_id": plate_id, "prompt": prompt, "resolution": resolution,
        "segment_count": int(segment_count),
    }
    return jobs.args_digest(payload)


def current_call_list(work_id: str, *, route: str, prompt: str = "",
                      resolution: str = "1080p") -> Dict[str, Any]:
    """从作品当前绑定推导"这次要提交什么"及其摘要。

    提交与费用确认必须调用同一个函数。否则会出现"用户确认的和实际提交的不是一件事"，
    而这种不一致在金额上完全看不出来——金额一致、清单不同，正是最危险的一类偏差。
    """
    work = st.get("works", work_id) or {}
    audio = tts_audio.final_audio(work_id) or {}
    if not audio:
        raise TalkingHeadBlocked("FINAL_AUDIO_REQUIRED", "尚无已确认最终音频，调用清单不成立")
    audio_id = audio["id"]
    audio_hash = audio.get("file_hash", "")
    variant_id = work.get("variant_id")

    if route == dh_routes.ROUTE_OMNIHUMAN:
        audio_ms = int(audio.get("duration_ms") or 0)
        limit = int(dh_routes.OMNIHUMAN_LIMIT["audio_max_seconds_exclusive"] * 1000)
        segment_count = 1
        if audio_ms >= limit:
            plan = sg.latest_plan(work_id)
            if not plan or plan.get("audio_asset_id") != audio_id:
                raise TalkingHeadBlocked(
                    "SEGMENT_PLAN_REQUIRED",
                    "音频达到上限：必须先建立分段计划，段数与金额才能确定",
                    {"audio_duration_ms": audio_ms},
                )
            segment_count = len(plan["segments"])
        return {
            "route": route, "audio_id": audio_id, "audio_hash": audio_hash,
            "variant_id": variant_id, "motion_ref_id": None, "plate_id": None,
            "prompt": prompt, "resolution": resolution, "segment_count": segment_count,
            "digest": call_list_digest(route, audio_id=audio_id, audio_hash=audio_hash,
                                       variant_id=variant_id, motion_ref_id=None,
                                       prompt=prompt, resolution=resolution,
                                       segment_count=segment_count),
        }

    from . import plates as pl

    plate = pl.approved_plate_for(work_id)
    return {
        "route": route, "audio_id": audio_id, "audio_hash": audio_hash,
        "variant_id": variant_id,
        "motion_ref_id": (plate or {}).get("motion_ref_id"),
        "plate_id": (plate or {}).get("id"),
        "prompt": "", "resolution": "native", "segment_count": 1,
        "digest": call_list_digest(route, audio_id=audio_id, audio_hash=audio_hash,
                                   variant_id=variant_id,
                                   motion_ref_id=(plate or {}).get("motion_ref_id"),
                                   prompt="", resolution="native", segment_count=1,
                                   plate_id=(plate or {}).get("id")),
    }


def _require_public_url(storage_uri: str, what: str) -> str:
    """供应商只能读 URL。内部相对路径不是"差不多能用"，而是不成立。"""
    if not storage_uri or not storage_uri.startswith(("http://", "https://")):
        raise TalkingHeadBlocked(
            "MEDIA_URL_NOT_READABLE",
            f"{what} 缺少供应商可读取的媒体 URL（当前：{storage_uri or '空'}）；"
            "接口只接受可读取 URL，不接受内部存储路径",
            {"what": what, "storage_uri": storage_uri or ""},
        )
    return storage_uri


def _credentials() -> tuple:
    ak = os.environ.get(pv.SECRET_ENV_AK, "")
    sk = os.environ.get(pv.SECRET_ENV_SK, "")
    if not ak or not sk:
        raise TalkingHeadBlocked(
            "OMNIHUMAN_CREDENTIALS_MISSING",
            f"未配置 {pv.SECRET_ENV_AK} / {pv.SECRET_ENV_SK}：不发起真实请求，也不假装已提交",
        )
    return ak, sk


# ---------- ProviderRun ----------

def start_run(work_id: str, *, route: str, provider: str, model: str, capability: str,
              request_digest: str, idempotency_key: str, task_id: Optional[str] = None,
              is_mock: bool = False, provider_params: Optional[Dict[str, Any]] = None,
              cost_reservation_id: Optional[str] = None) -> Dict[str, Any]:
    run = ProviderRun(
        id=st.new_id("prun"), work_id=work_id, task_id=task_id, route=route,
        provider=provider, model=model, capability=capability,
        capability_snapshot_id="t05-2026-09-23",
        request_digest=request_digest, idempotency_key=idempotency_key,
        state="intent", is_mock=is_mock, provider_params=provider_params or {},
        cost_reservation_id=cost_reservation_id,
    )
    st.put(RUN_TABLE, run.id, run.model_dump(), {"work_id": work_id})
    return run.model_dump()


def get_run(run_id: str) -> Optional[Dict[str, Any]]:
    return st.get(RUN_TABLE, run_id)


def runs_for_work(work_id: str) -> List[Dict[str, Any]]:
    rows = st.all_rows(RUN_TABLE, "work_id=?", [work_id])
    return sorted(rows, key=lambda r: r.get("created_at", ""))


def _update_run(run_id: str, **fields: Any) -> Dict[str, Any]:
    run = get_run(run_id)
    if not run:
        raise TalkingHeadRejected("PROVIDER_RUN_NOT_FOUND", f"运行记录不存在：{run_id}")
    run.update(fields)
    run["updated_at"] = now_iso()
    st.put(RUN_TABLE, run_id, run, {"work_id": run.get("work_id")})
    return run


def mark_run_unknown(run_id: str, reason: str) -> Dict[str, Any]:
    """提交丢响应：记未知，等对账。不回写 succeeded/failed。"""
    run = get_run(run_id) or {}
    job_id = run.get("job_id")
    if job_id:
        try:
            jobs.mark_unknown(job_id, reason=reason)
        except jobs.JobRejected:
            pass
    return _update_run(run_id, state="unknown",
                       last_error={"code": "RESULT_UNKNOWN", "message": reason})


def record_blocked_attempt(work_id: str, *, route: str, provider: str, model: str,
                           capability: str, request_digest: str, error,
                           provider_params: Optional[Dict[str, Any]] = None,
                           task_id: Optional[str] = None) -> Dict[str, Any]:
    """被门禁拦下的提交尝试也要入账。

    这类尝试没有外部副作用，所以"看起来可以不留痕"。但审计真正要回答的问题是
    "谁在什么时候试过提交、被哪条规则拦下"——不记就无法回答，
    也无法证明门禁确实拦住了，而不是碰巧没跑。状态用 `blocked`，
    与真正的失败 `failed` 区分开：前者没出去，后者出去了但没成。
    """
    run = start_run(work_id, route=route, provider=provider, model=model,
                    capability=capability, request_digest=request_digest,
                    idempotency_key=f"blocked:{work_id}:{request_digest}",
                    task_id=task_id, is_mock=False,
                    provider_params=provider_params or {})
    return _update_run(run["id"], state="blocked",
                       last_error={"code": error.code, "message": error.message})


def _gate_with_ledger(work_id: str, *, route: str, provider: str, model: str,
                      capability: str, digest: str, estimated_fen: int,
                      task: Optional[Dict[str, Any]],
                      provider_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """费用/预算门禁。被拦下时先把这次尝试记进台账，再抛出原错误。"""
    try:
        return dh_cost.assert_submission_allowed(work_id, route=route,
                                                 request_digest=digest,
                                                 estimated_fen=estimated_fen)
    except (TalkingHeadBlocked, TalkingHeadRejected) as e:
        record_blocked_attempt(work_id, route=route, provider=provider, model=model,
                               capability=capability, request_digest=digest, error=e,
                               provider_params=provider_params,
                               task_id=(task or {}).get("id"))
        raise


def record_failure(run_id: str, *, code: str, message: str,
                   evidence: str = "") -> Dict[str, Any]:
    """失败落证：文件、远端 ID、参数、费用都留着；并显式声明没有自动回退。"""
    run = get_run(run_id)
    if not run:
        raise TalkingHeadRejected("PROVIDER_RUN_NOT_FOUND", f"运行记录不存在：{run_id}")
    if run.get("is_mock"):
        return _update_run(run_id, state="failed",
                           last_error={"code": code, "message": message},
                           auto_fallback=False)
    job_id = run.get("job_id")
    if job_id:
        job = jobs.get_job(job_id)
        if job and job.get("state") == "leased":
            try:
                jobs.fail(job_id, job["lease"]["worker_id"],
                          {"code": code, "message": message})
            except jobs.JobRejected:
                pass
    config.record_provider_evidence(
        run.get("provider", ""), run.get("capability", ""), "failed",
        evidence or f"作业失败：{code}",
        detail=f"run={run_id} route={run.get('route')} remote={run.get('remote_job_id')}")
    return _update_run(run_id, state="failed",
                       last_error={"code": code, "message": message},
                       auto_fallback=False)


def resubmit_guard(work_id: str, request_digest: str,
                   *, replacement_authorized: bool = False) -> Dict[str, Any]:
    """同一清单失败/未知过，就不能"再点一次"：先对账或显式授权重做。"""
    prior = [r for r in runs_for_work(work_id)
             if r.get("request_digest") == request_digest
             and r.get("state") in ("failed", "unknown")]
    if not prior:
        return {"ok": True, "prior": []}
    unknown = [r for r in prior if r.get("state") == "unknown"]
    if unknown and not replacement_authorized:
        raise TalkingHeadBlocked(
            "RESUBMIT_REQUIRES_RECONCILIATION",
            "同一调用清单存在结果未知的作业：先按原远端 ID 对账，再决定是否重做；"
            "直接重提可能产生重复费用",
            {"runs": [r["id"] for r in unknown]},
        )
    if not replacement_authorized:
        raise TalkingHeadBlocked(
            "RESUBMIT_REQUIRES_AUTHORIZATION",
            "同一调用清单此前失败过：重做属于新的付费尝试，需显式授权（仍可能计费）",
            {"runs": [r["id"] for r in prior]},
        )
    return {"ok": True, "prior": [r["id"] for r in prior], "replacement_authorized": True}


def settle_unknown(run_id: str, outcome: str, evidence: Dict[str, Any]) -> Dict[str, Any]:
    """对账结论落定。必须带证据，不允许无证据改判。"""
    run = get_run(run_id)
    if not run:
        raise TalkingHeadRejected("PROVIDER_RUN_NOT_FOUND", f"运行记录不存在：{run_id}")
    job_id = run.get("job_id")
    if job_id:
        jobs.resolve_unknown(job_id, outcome, evidence)
    return _update_run(run_id, state=outcome, reconciliation={"evidence": evidence,
                                                              "at": now_iso()})


# ---------- OmniHuman ----------

def _omnihuman_segments(work_id: str, audio: Dict[str, Any]) -> List[Dict[str, Any]]:
    """严格小于 60 秒是硬约束；超限必须走句子边界分段，不允许加速截字。"""
    audio_ms = int(audio.get("duration_ms") or 0)
    limit = int(dh_routes.OMNIHUMAN_LIMIT["audio_max_seconds_exclusive"] * 1000)
    if audio_ms < limit:
        return [{"index": 0, "segment_id": "oh_seg_1", "start_ms": 0, "end_ms": audio_ms,
                 "duration_ms": audio_ms, "global_offset_ms": 0, "over_limit": False,
                 "text": "", "single_call": True}]
    plan = sg.latest_plan(work_id)
    if not plan or plan.get("audio_asset_id") != audio.get("id"):
        plan = sg.create_plan(work_id)
    sg.assert_segments_submittable(plan["segments"])
    if len(plan["segments"]) < 2:
        raise TalkingHeadRejected("OMNIHUMAN_SEGMENTATION_INSUFFICIENT",
                                 "音频达到上限却只切出一段：切分没有生效，不得提交")
    return plan["segments"]


def submit_omnihuman(work_id: str, *, task: Optional[Dict[str, Any]] = None,
                     prompt: str = "", resolution: str = "1080p", transport=None,
                     dry_run: Optional[bool] = None,
                     replacement_authorized: bool = False) -> Dict[str, Any]:
    """OmniHuman：固定人物图 + 已确认最终 TTS + 可选表演描述 → 原片（单阶段）。"""
    work = st.get("works", work_id)
    if not work:
        raise TalkingHeadRejected("WORK_NOT_FOUND", f"作品不存在：{work_id}")
    require = dh_routes.require_preflight(work_id, task=task, route=dh_routes.ROUTE_OMNIHUMAN,
                                          require_plate=False)
    audio = tts_audio.final_audio(work_id)
    audio_ms = int(audio.get("duration_ms") or 0)
    segments = _omnihuman_segments(work_id, audio)
    # 上限是**单次调用**的上限，不是整条音轨的上限：约 60 秒音频之所以合法，
    # 正是因为它在句子边界处被拆成多段。若拿整轨时长去撞上限，
    # 约 60 秒这条主流程会被自己的校验挡死。
    for seg in segments:
        pv.assert_omnihuman_input(audio_duration_ms=int(seg["duration_ms"]),
                                  prompt=prompt, resolution=resolution)
    listing = current_call_list(work_id, route=dh_routes.ROUTE_OMNIHUMAN, prompt=prompt,
                               resolution=resolution)
    if listing["segment_count"] != len(segments):
        raise TalkingHeadRejected(
            "CALL_LIST_INCONSISTENT",
            "分段结果与调用清单不一致：清单、段数与金额必须来自同一份推导",
            {"listing": listing["segment_count"], "segments": len(segments)},
        )
    digest = listing["digest"]
    zone = resubmit_guard(work_id, digest, replacement_authorized=replacement_authorized)
    est = dh_cost.estimate(dh_routes.ROUTE_OMNIHUMAN, duration_ms=audio_ms,
                           segment_count=len(segments), resolution=resolution)
    authorization = _gate_with_ledger(
        work_id, route=dh_routes.ROUTE_OMNIHUMAN, provider="volcengine",
        model="omnihuman-1.5", capability=dh_routes.CAP_AVATAR_VIDEO_CLOUD,
        digest=digest, estimated_fen=est["estimated_fen"], task=task,
        provider_params={"prompt": prompt, "resolution": resolution,
                         "segments": len(segments)})

    is_mock = config.resolve_mode() == "mock" if dry_run is None else bool(dry_run)
    if is_mock:
        run = start_run(work_id, route=dh_routes.ROUTE_OMNIHUMAN, provider="volcengine",
                        model="omnihuman-1.5", capability=dh_routes.CAP_AVATAR_VIDEO_CLOUD,
                        request_digest=digest, idempotency_key=f"oh:{work_id}:{digest}",
                        task_id=(task or {}).get("id"), is_mock=True,
                        provider_params={"prompt": prompt, "resolution": resolution,
                                         "segments": len(segments)})
        return {"submitted": False, "is_mock": True, "route": dh_routes.ROUTE_OMNIHUMAN,
                "runs": [run], "segments": segments, "estimate": est,
                "authorization": authorization, "resubmit": zone,
                "note": "dry_run：未发起真实调用、未登记原片；占位产物不得进入审核与后期"}

    if not transport:
        raise TalkingHeadBlocked("OMNIHUMAN_TRANSPORT_UNAVAILABLE", "未提供网络通道，不假装已提交")
    ak, sk = _credentials()
    image_url = _require_public_url(
        (st.get("avatar_assets", _variant_asset_id(work)) or {}).get("storage_uri", ""),
        "人物参考图")
    audio_url = _require_public_url(audio.get("storage_uri", ""), "最终音频")

    runs: List[Dict[str, Any]] = []
    per_seg_fen = max(1, int(est["estimated_fen"] / max(1, len(segments))))
    for seg in segments:
        key = f"oh:{work_id}:{digest}:{seg['segment_id']}"
        run = start_run(work_id, route=dh_routes.ROUTE_OMNIHUMAN, provider="volcengine",
                        model="omnihuman-1.5", capability=dh_routes.CAP_AVATAR_VIDEO_CLOUD,
                        request_digest=digest, idempotency_key=key,
                        task_id=(task or {}).get("id"),
                        cost_reservation_id=authorization["confirmation_id"],
                        provider_params={"prompt": prompt, "resolution": resolution,
                                         "segment_index": seg["index"],
                                         "segment_count": len(segments),
                                         "global_offset_ms": seg.get("global_offset_ms", 0)})
        job = jobs.submit(
            work_id=work_id, capability=dh_routes.CAP_AVATAR_VIDEO_CLOUD,
            provider="volcengine", model="omnihuman-1.5",
            args={"route": dh_routes.ROUTE_OMNIHUMAN, "segment": seg["segment_id"],
                  "prompt": prompt, "resolution": resolution,
                  "audio_asset_id": audio["id"], "audio_hash": audio.get("file_hash", ""),
                  "request_digest": digest},
            idempotency_key=key, task_id=(task or {}).get("id"),
            billable=True, amount_fen=per_seg_fen,
            note="OmniHuman 云端生成（不占本地 GPU，可与本地重型作业并行）",
        )
        if job["state"] == "blocked":
            record_failure(run["id"], code=job.get("block_code", "JOB_BLOCKED"),
                           message=job.get("block_detail", "作业被阻断"))
            raise TalkingHeadBlocked(job.get("block_code", "JOB_BLOCKED"),
                                    job.get("block_detail", "作业被阻断"),
                                    {"run_id": run["id"], "job_id": job["id"]})
        run = _update_run(run["id"], job_id=job["id"], state="submitted")
        request = pv.build_submit_request(image_url=image_url, audio_url=audio_url,
                                          prompt=prompt, output_resolution=resolution,
                                          ak=ak, sk=sk)
        parsed = pv.parse_submit_response(transport(request))
        if parsed["state"] == "submitted":
            run = _update_run(run["id"], state="waiting_provider",
                              remote_job_id=parsed["remote_job_id"])
        elif parsed["state"] == "unknown":
            run = mark_run_unknown(run["id"], parsed.get("reason", "提交结果未知"))
        else:
            run = record_failure(run["id"], code="OMNIHUMAN_SUBMIT_FAILED",
                                 message=parsed.get("reason", "提交失败"))
        runs.append(run)
    return {"submitted": all(r["state"] == "waiting_provider" for r in runs),
            "is_mock": False, "route": dh_routes.ROUTE_OMNIHUMAN, "runs": runs,
            "segments": segments, "estimate": est, "authorization": authorization,
            "note": "已受理不等于成功：按原 task_id 查询，下载后仍须通过媒体校验"}


def _variant_asset_id(work: Dict[str, Any]) -> str:
    variant = st.get("variants", work.get("variant_id") or "") or {}
    return variant.get("asset_id") or ""


def poll_run(run_id: str, *, transport=None) -> Dict[str, Any]:
    """按原 remote_job_id 查询。running 只是 running；done 还要能下载并通过校验。"""
    run = get_run(run_id)
    if not run:
        raise TalkingHeadRejected("PROVIDER_RUN_NOT_FOUND", f"运行记录不存在：{run_id}")
    if run["state"] in ("succeeded", "failed", "cancelled"):
        return {"run": run, "state": run["state"], "note": "已是终态，不再查询"}
    if run.get("is_mock"):
        raise TalkingHeadBlocked("MOCK_RUN_NOT_POLLABLE",
                                "占位运行没有真实远端任务，不可查询")
    if not run.get("remote_job_id"):
        return {"run": mark_run_unknown(run_id, "缺 task_id：无法查询，先对账"),
                "state": "unknown", "note": "无远端 ID 不得改判"}
    if not transport:
        raise TalkingHeadBlocked("OMNIHUMAN_TRANSPORT_UNAVAILABLE", "未提供网络通道")
    if run.get("provider") == "m2_worker":
        return _poll_m2_run(run_id, transport=transport)
    ak, sk = _credentials()
    request = pv.build_query_request(task_id=run["remote_job_id"], ak=ak, sk=sk)
    parsed = pv.parse_query_response(transport(request))
    if parsed["state"] == "running":
        return {"run": _update_run(run_id, state="waiting_provider",
                                   poll_after=now_iso()),
                "state": "waiting_provider", "remote_status": parsed.get("remote_status")}
    if parsed["state"] == "unknown":
        return {"run": mark_run_unknown(run_id, parsed.get("reason", "状态未知")),
                "state": "unknown"}
    if parsed["state"] == "failed":
        return {"run": record_failure(run_id, code="OMNIHUMAN_REMOTE_FAILED",
                                      message=parsed.get("reason", "远端失败")),
                "state": "failed"}

    downloaded = pv.download_and_verify(parsed["video_url"], transport)
    return _register_original(run_id, downloaded, note="OmniHuman 原片（下载并校验通过）")


def _poll_m2_run(run_id: str, *, transport=None) -> Dict[str, Any]:
    """按 worker 的 job_id 查询 M2 作业状态。

    查询本身只取真相、不推进作业：这里不会重提、不会重试、
    不会把没做完的作业改判成任何结论。重提是另一个显式动作，
    由 resubmit_guard 与幂等键约束，不能藏在轮询里偷偷发生。
    """
    from . import worker_client as dh_worker

    run = get_run(run_id)
    if not dh_worker.configured():
        raise TalkingHeadBlocked(
            "M2_TRANSPORT_UNAVAILABLE",
            "未配置 worker 地址：无法查询 M2 作业状态（这是通道未接通，不是作业失败）",
            {"env": "AVATAR_STUDIO_M2_WORKER_URL"})
    request = dh_worker.build_status_request(dh_worker.worker_url(),
                                             run["remote_job_id"],
                                             token=dh_worker.worker_token())
    parsed = pv.parse_m2_response(transport(request))
    if parsed["state"] == "running":
        return {"run": _update_run(run_id, state="waiting_provider", poll_after=now_iso()),
                "state": "waiting_provider", "remote_status": parsed.get("remote_status")}
    if parsed["state"] == "unknown":
        return {"run": mark_run_unknown(run_id, parsed.get("reason", "状态未知")),
                "state": "unknown"}
    if parsed["state"] == "failed":
        return {"run": record_failure(run_id, code="M2_REMOTE_FAILED",
                                      message=parsed.get("reason", "远端失败")),
                "state": "failed"}

    downloaded = pv.download_and_verify(parsed["output_url"], transport)
    return _register_original(run_id, downloaded, note="MuseTalk 原片（下载并校验通过）")


def _register_original(run_id: str, downloaded: Dict[str, Any], *, note: str) -> Dict[str, Any]:
    run = get_run(run_id)
    probe = downloaded["probe"]
    params = run.get("provider_params") or {}
    work_id = run["work_id"]
    work = st.get("works", work_id) or {}
    final = tts_audio.final_audio(work_id) or {}
    video = vd.register_video(
        work_id=work_id, kind=vd.KIND_ORIGINAL, route=run.get("route") or "M2",
        provider=run.get("provider", ""), model=run.get("model", ""),
        duration_ms=int(probe.get("duration_ms") or 0), file_hash=probe["file_hash"],
        is_mock=False, identity_id=work.get("identity_id"),
        variant_id=work.get("variant_id"), audio_asset_id=final.get("id"),
        provider_run_id=run_id, cost_reservation_id=run.get("cost_reservation_id"),
        has_video_track=bool(probe.get("has_video_track")),
        has_audio_track=bool(probe.get("has_audio_track")),
        width=probe.get("width"), height=probe.get("height"),
        fps=probe.get("fps"),
        segment_index=params.get("segment_index"),
        segment_count=params.get("segment_count"),
        global_offset_ms=int(params.get("global_offset_ms") or 0),
        checks=[], note=note,
    )
    video["storage_uri"] = vd.store_video_bytes(work_id, video["id"], downloaded["data"])
    st.put(vd.VIDEO_TABLE, video["id"], video, {"work_id": work_id})
    run = _update_run(run_id, state="succeeded", result_asset_ids=[video["id"]])
    return {"run": run, "state": "succeeded", "video": video, "probe": probe}


# ---------- M2 ----------

def submit_m2(work_id: str, *, task: Optional[Dict[str, Any]] = None, transport=None,
              dry_run: Optional[bool] = None,
              replacement_authorized: bool = False) -> Dict[str, Any]:
    """M2：已审底片 + 同一条最终音频 → MuseTalk 口型（两阶段中的第二阶段）。"""
    work = st.get("works", work_id)
    if not work:
        raise TalkingHeadRejected("WORK_NOT_FOUND", f"作品不存在：{work_id}")
    require = dh_routes.require_preflight(work_id, task=task, route=dh_routes.ROUTE_M2,
                                          require_plate=True)
    audio = tts_audio.final_audio(work_id)
    from . import plates as pl

    plate = pl.approved_plate_for(work_id)
    if not plate:
        raise TalkingHeadBlocked("PLATE_NOT_APPROVED", "M2 需要已审动态底片才能对口型")
    digest = call_list_digest(dh_routes.ROUTE_M2, audio_id=audio["id"],
                              audio_hash=audio.get("file_hash", ""),
                              variant_id=work.get("variant_id"),
                              motion_ref_id=plate.get("motion_ref_id"), prompt="",
                              resolution="native", segment_count=1, plate_id=plate["id"])
    resubmit_guard(work_id, digest, replacement_authorized=replacement_authorized)
    est = dh_cost.estimate(dh_routes.ROUTE_M2, duration_ms=int(audio.get("duration_ms") or 0))
    authorization = _gate_with_ledger(
        work_id, route=dh_routes.ROUTE_M2, provider="m2_worker", model="MuseTalk-1.5",
        capability=dh_routes.CAP_LIPSYNC, digest=digest, estimated_fen=0, task=task,
        provider_params={"plate_id": plate["id"]})

    is_mock = config.resolve_mode() == "mock" if dry_run is None else bool(dry_run)
    if is_mock:
        run = start_run(work_id, route=dh_routes.ROUTE_M2, provider="m2_worker",
                        model="MuseTalk-1.5", capability=dh_routes.CAP_LIPSYNC,
                        request_digest=digest, idempotency_key=f"mt:{work_id}:{digest}",
                        task_id=(task or {}).get("id"), is_mock=True,
                        provider_params={"plate_id": plate["id"]})
        return {"submitted": False, "is_mock": True, "route": dh_routes.ROUTE_M2,
                "runs": [run], "estimate": est, "authorization": authorization,
                "plate_id": plate["id"], "preflight": require,
                "note": "dry_run：未提交 GPU 作业、未登记原片"}

    if not transport:
        raise TalkingHeadBlocked("M2_TRANSPORT_UNAVAILABLE", "未提供算力云通道，不假装已提交")
    request = pv.build_musetalk_request(
        plate_url=plate.get("storage_uri", ""), audio_url=audio.get("storage_uri", ""),
        plate_hash=plate.get("file_hash", ""), audio_hash=audio.get("file_hash", ""))
    run = start_run(work_id, route=dh_routes.ROUTE_M2, provider="m2_worker",
                    model="MuseTalk-1.5", capability=dh_routes.CAP_LIPSYNC,
                    request_digest=digest, idempotency_key=f"mt:{work_id}:{digest}",
                    task_id=(task or {}).get("id"),
                    cost_reservation_id=authorization["confirmation_id"],
                    provider_params={"plate_id": plate["id"]})
    job = jobs.submit(work_id=work_id, capability=dh_routes.CAP_LIPSYNC, provider="m2_worker",
                      model="MuseTalk-1.5", args=request["args"],
                      idempotency_key=f"mt:{work_id}:{digest}",
                      task_id=(task or {}).get("id"), billable=True, amount_fen=0,
                      note="MuseTalk 口型（单 GPU 重型作业，排队互斥）")
    if job["state"] == "blocked":
        record_failure(run["id"], code=job.get("block_code", "JOB_BLOCKED"),
                       message=job.get("block_detail", "作业被阻断"))
        raise TalkingHeadBlocked(job.get("block_code", "JOB_BLOCKED"),
                                job.get("block_detail", "作业被阻断"),
                                {"run_id": run["id"], "job_id": job["id"]})
    run = _update_run(run["id"], job_id=job["id"], state="submitted")
    parsed = pv.parse_m2_response(transport(request))
    if parsed["state"] == "succeeded":
        run = _update_run(run["id"], state="waiting_provider",
                          remote_job_id=parsed.get("remote_job_id"))
    elif parsed["state"] == "unknown":
        run = mark_run_unknown(run["id"], parsed.get("reason", "结果未知"))
    elif parsed["state"] == "running":
        # 排队/推理中不是失败：它是"还没完"。把它记成 failed 会让用户
        # 以为还要重提一次，而重提会在 GPU 上再排一份队（还绕过幂等键）。
        run = _update_run(run["id"], state="waiting_provider",
                          remote_job_id=parsed.get("remote_job_id"),
                          poll_after=now_iso())
    else:
        run = record_failure(run["id"], code="M2_JOB_FAILED",
                             message=parsed.get("reason", "作业未完成"))
    return {"submitted": run["state"] == "waiting_provider", "is_mock": False,
            "route": dh_routes.ROUTE_M2, "runs": [run], "estimate": est,
            "authorization": authorization, "plate_id": plate["id"],
            "note": "M2 两阶段各有独立 ProviderRun；失败保留，不自动回退其他路线"}


def submission_status(work_id: str) -> Dict[str, Any]:
    runs = runs_for_work(work_id)
    return {
        "work_id": work_id,
        "runs": [{"id": r["id"], "route": r.get("route"), "capability": r.get("capability"),
                  "state": r["state"], "remote_job_id": r.get("remote_job_id"),
                  "is_mock": r.get("is_mock"), "result_asset_ids": r.get("result_asset_ids"),
                  "request_digest": r.get("request_digest")} for r in runs],
        "auto_fallback": False,
        "note": "失败与未知一律保留原记录；跨路线回退需要用户重新选择，不自动发生",
    }
