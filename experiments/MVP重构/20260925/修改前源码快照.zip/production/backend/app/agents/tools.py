"""受控工具层（M01–M04；代码后期不暴露为 Agent 工具）。

红线（10 文档 §6.3）：
- 工具不接受任意文件系统路径或任意 shell；路径类参数一律拒绝 `..`、绝对路径与盘符。
- 权限按角色授予，角色不能自填 allowlist；越权、未知工具名一律拒绝并记录审计。
- 不伪造证据：检索/检测未接入真实能力时返回空结果与 not_run，不返回编造的指标或来源。
- 默认额度 0：任何 billable 提交在授权前被 BUDGET_NOT_AUTHORIZED 阻断。
- 幂等：同一工作项 + 工具 + 参数摘要的重放返回原结果，不重复产生副作用。
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from typing import Any, Callable, Dict, List, Optional

from .. import storage as st
from ..contracts import ApiError, QualityCheck, now_iso
from . import contracts as ac
from .roles import ROLES, role_tools

MODE = os.environ.get("AVATAR_STUDIO_MODE", "mock")

_ABS_OR_TRAVERSAL = re.compile(r"(\.\.[/\\])|^([a-zA-Z]:)?[/\\\\]|^~")


class ToolDenied(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def _check_path(value: str) -> None:
    if _ABS_OR_TRAVERSAL.search(value or ""):
        raise ToolDenied("PATH_NOT_ALLOWED", f"路径参数不允许绝对地址或上级目录：{value!r}")


def _require(args: Dict[str, Any], fields: List[str]) -> None:
    for f in fields:
        v = args.get(f)
        if v is None or (isinstance(v, str) and not v.strip()):
            raise ToolDenied("VALIDATION_FAILED", f"缺少参数 {f}")
        if isinstance(v, str):
            _check_path(v)


def _media_job(work_id: str, kind: str, provider: str, model: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """登记媒体作业。Mock/未授权模式下不向外提交，state 记为 not_submitted。"""
    job = {
        "id": st.new_id("job"),
        "work_id": work_id,
        "kind": kind,
        "provider": provider,
        "model": model,
        "state": "not_submitted",
        "simulated": True,
        "remote_job_id": None,
        "payload": payload,
        "created_at": now_iso(),
        "note": "MOCK：未提交真实 Provider，不产生费用与外部副作用",
    }
    st.put("media_jobs", job["id"], job, {"work_id": work_id})
    return job


def _billable_guard(kind: str) -> None:
    """默认额度 0：未授权的可计费提交一律阻断。"""
    limit = int(os.environ.get("AVATAR_STUDIO_BUDGET_FEN", "0"))
    if limit <= 0:
        raise ToolDenied(
            "BUDGET_NOT_AUTHORIZED",
            f"{kind} 属于可计费作业，当前每日/单次额度为 0，未取得授权前不提交",
        )


# ---------------------------------------------------------------------------
# 工具实现
# ---------------------------------------------------------------------------

def t_search_content_history(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["query"])
    q = args["query"].strip()
    hits = []
    for w in st.all_rows("works"):
        topic = (w.get("brief") or {}).get("topic", "")
        if q and q in topic:
            hits.append({"work_id": w["id"], "topic": topic, "name": w.get("name", "")})
    for b in st.all_rows("script_batches"):
        for c in b.get("candidates", []):
            if q and (q in c.get("title", "") or q in c.get("text", "")):
                hits.append({"work_id": b.get("work_id"), "candidate_id": c.get("id"), "title": c.get("title", "")})
    return {"hits": hits, "count": len(hits), "note": "业务库全文子串匹配，非向量检索"}


def t_get_presenter_profile(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["identity_id"])
    ident = st.get("identities", args["identity_id"])
    if not ident:
        raise ToolDenied("ASSET_NOT_FOUND", "人物不存在")
    # 固定人设只读：不返回可写字段
    return {
        "id": ident["id"], "name": ident.get("name"), "persona": ident.get("persona"),
        "hero_asset_id": ident.get("hero_asset_id"), "identity_digest": ident.get("identity_digest"),
        "approval_state": ident.get("approval_state"), "readonly": True,
    }


def t_list_approved_assets(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    kind = args.get("kind") or "voice"
    table = {"voice": "voices", "identity": "identities"}.get(kind)
    if not table:
        raise ToolDenied("VALIDATION_FAILED", f"未知资产类型 {kind}")
    rows = st.all_rows(table)
    return {"assets": [r for r in rows if r.get("approval_state") == "approved"], "count": len(rows)}


def t_register_script_candidates(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """写候选稿。优先走真实 DeepSeek 生成；凭据不可用才在 mock 模式回落。

    回落也必须如实标注 `source_kind=mock`，绝不冒充模型产出；
    非 mock 模式下凭据缺失就是硬阻断，不静默造假稿。
    """
    _require(args, ["work_id", "topic"])
    from ..content.errors import ContentBlocked, ContentRejected

    work = st.get("works", args["work_id"]) or {}
    brief = work.get("brief") or {}
    materials = brief.get("materials") or args.get("materials") or []
    source_kind = "mock"
    shortfall_note = None
    repair_note = None
    repair_history: List[Dict[str, Any]] = []
    try:
        from ..content.generate import generate_candidates

        out = generate_candidates(
            work_id=args["work_id"], topic=args["topic"],
            content_type=brief.get("content_type", ""),
            audience=brief.get("audience", ""),
            keywords=brief.get("keywords") or args.get("keywords") or [],
            target_duration_ms=int(brief.get("target_duration_ms", 60000)),
            materials=materials,
        )
        cands = [c.model_dump() for c in out["candidates"]]
        source_kind = out["source_kind"]
        shortfall_note = out["shortfall_note"]
        # 自修复留痕必须一起落库：界面要能说明"这稿是模型自己改过的"，
        # 而不是让人以为模型一次就写对。契约 `ScriptBatch` 已同步这三个字段。
        repair_note = out.get("repair_note")
        repair_history = out.get("repair_history") or []
    except ContentBlocked as exc:
        if MODE != "mock":
            raise ToolDenied(exc.code, exc.message)
        from ..mockdata import make_candidates

        cands = [c.model_dump() for c in make_candidates(args["topic"])]
        shortfall_note = "模拟三稿（未取得 DeepSeek 凭据），不冒充模型产出"
    except ContentRejected as exc:
        raise ToolDenied(exc.code, exc.message)

    batch = {"id": st.new_id("batch"), "work_id": args["work_id"], "candidates": cands,
             "shortfall_note": shortfall_note, "source_kind": source_kind,
             "repair_note": repair_note, "repair_history": repair_history,
             "materials_count": len(materials)}
    st.put("script_batches", args["work_id"], batch)
    # 重新出稿后旧采用失效
    w = st.get("works", args["work_id"]) or {}
    w["script_version_id"] = None
    st.put("works", args["work_id"], w)
    return {"batch_id": batch["id"], "candidates": [c["id"] for c in batch["candidates"]],
            "angles": [c["angle"] for c in batch["candidates"]],
            "source_kind": source_kind, "shortfall_note": shortfall_note,
            "materials_count": len(materials), "repair_note": repair_note,
            "note": ("真实模型生成" if source_kind == "llm"
                     else "模拟三稿，已标注 mock，不冒充模型产出")}


def t_compile_performance_plan(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """由已审稿件生成 PerformancePlan（意图层），不预造精确时间戳。

    分段构造只有一份实现（`tts.plan.create_plan`）：角色工具与 API 路径共用它，
    否则会出现"计划里的分段"和"合成时的分段"两套边界，对齐时必然对不上。
    """
    _require(args, ["work_id", "script_version_id"])
    from ..tts import plan as tts_plan

    row = tts_plan.create_plan(args["work_id"], args["script_version_id"])
    return {"plan_id": row["id"], "plan_digest": row["plan_digest"],
            "segments": len(row.get("segments", [])),
            "note": "意图层计划；实际分段时间须来自最终音频与校验后的对齐"}


def t_submit_quality_report(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """登记审核结论。硬门禁由业务层按规则复算，不采信 Agent 自报的放行。

    subject_id 为空或 `__all__` 时逐稿审核该作品当前批次的全部候选。
    """
    _require(args, ["work_id"])
    reported = args.get("checks") or []
    batch = st.get("script_batches", args["work_id"]) or {}
    subject = args.get("subject_id")
    targets = ([c for c in batch.get("candidates", []) if c["id"] == subject]
               if subject and subject != "__all__" else list(batch.get("candidates", [])))
    if not targets:
        raise ToolDenied("STALE_SELECTION", "被审对象不存在")

    ids, hard_all = [], []
    for cand in targets:
        checks = [QualityCheck(**c) for c in cand.get("quality_report", {}).get("checks", [])]
        hard_fail = [c for c in checks if c.hard_gate and c.outcome != "pass"]
        if reported:
            # Agent 试图放宽：不允许改写已有检查项结论
            for rc in reported:
                code = str(rc.get("code", ""))
                if any(c.code == code for c in checks):
                    raise ToolDenied("QUALITY_REPORT_TAMPERING", f"不允许改写已有检查项结论：{code}")
        recommendation = "fail" if hard_fail else cand.get("quality_report", {}).get("overall", "not_run")
        d = ac.QualityDecision(
            id=st.new_id("qd"), work_item_id=ctx.get("work_item_id", ""), subject_id=cand["id"],
            subject_digest=ac.digest(cand["text"]), recommendation=recommendation,
            report_ids=[cand["id"]],
            issues=[{"code": c.code, "reason": c.message, "rework_target": "content"} for c in hard_fail],
            model_run_id=ctx.get("model_run_id"),
        )
        d.decision_digest = ac.digest({"subject": d.subject_digest, "recommendation": recommendation})
        st.put("quality_decisions", d.id, d.model_dump(), {"work_id": args["work_id"]})
        ids.append(d.id)
        hard_all += [c.code for c in hard_fail]
    return {"quality_decision_id": ids[0], "quality_decision_ids": ids, "reviewed": len(ids),
            "hard_gate_failures": hard_all,
            "note": "结论不含批准令牌；用户采用是独立决定"}


def t_compile_speech_expression(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """表达编译：与 API 路径共用 `tts.compiler`，不另写一套降级规则。

    降级与否、支持/近似/不支持都必须来自同一份编译结果，否则
    "Agent 看到的控制能力"和"实际提交的参数"会不一致。
    """
    _require(args, ["work_id", "performance_plan_id"])
    from ..tts import compiler as tts_compiler

    w = st.get("works", args["work_id"]) or {}
    voice_id = args.get("voice_asset_id") or w.get("voice_asset_id")
    if not voice_id:
        raise ToolDenied("SELECTION_REQUIRED", "未选定音色，无法编译表达")
    try:
        compiled = tts_compiler.compile_speech(args["performance_plan_id"], voice_id)
    except Exception as e:
        raise ToolDenied(getattr(e, "code", "TTS_COMPILE_FAILED"), str(e))
    return {
        "plan_id": compiled["plan_id"], "plan_digest": compiled["plan_digest"],
        "segment_count": len(compiled["segments"]),
        "provider_params": compiled["provider_params"],
        "control_summary": compiled["control_summary"],
        "supported": compiled["controls"]["supported"],
        "approximate": compiled["controls"]["approximate"],
        "unsupported": compiled["controls"]["unsupported"],
        "suspicious_tags": compiled["suspicious_tags"],
        "note": "派生视图：分段与表达的唯一来源是冻结计划，不支持项已在调用前报告",
    }


def t_submit_tts(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """登记 TTS 提交意图。不在此处发起真实计费合成（由用户触发的工作台接口执行）。

    提交前仍做两项硬校验：音色必须是本作品已选音色；必须有冻结计划。
    否则"Agent 提交了 TTS"会与真实可合成状态脱节。
    """
    _require(args, ["work_id"])
    w = st.get("works", args["work_id"]) or {}
    if not w.get("voice_asset_id"):
        raise ToolDenied("SELECTION_REQUIRED", "未选定音色，不能提交 TTS")
    from ..tts import plan as tts_plan

    if not tts_plan.is_usable(tts_plan.latest_plan_for_work(args["work_id"],
                                                            w.get("script_version_id"))):
        raise ToolDenied("PLAN_NOT_FROZEN", "缺少可用的冻结表演计划，不能提交 TTS")
    return _media_job(args["work_id"], "tts", "minimax", "speech-2.8-hd",
                      {"voice_asset_id": w["voice_asset_id"],
                       "plan_required": True})


def t_submit_motion(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["work_id", "route"])
    if args["route"] not in ("M2", "OMNIHUMAN_1_5"):
        raise ToolDenied("VALIDATION_FAILED", "路线取值非法")
    return _media_job(args["work_id"], "motion", "m2_worker", "LivePortrait", {"route": args["route"]})


def t_submit_lipsync(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["work_id", "route"])
    if args["route"] == "OMNIHUMAN_1_5":
        return {"skipped": True, "note": "OmniHuman 路线不创建 MuseTalk 嘴型作业"}
    return _media_job(args["work_id"], "lipsync", "m2_worker", "MuseTalk-1.5", {"route": args["route"]})


def t_submit_avatar_video(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """云增强路线：必须显式选择 + 预算授权，否则阻断（不自动切换）。"""
    _require(args, ["work_id", "route"])
    if args["route"] != "OMNIHUMAN_1_5":
        raise ToolDenied("ROUTE_NOT_SELECTED", "默认路线不走云增强；须用户显式选择")
    _billable_guard("OmniHuman 1.5")
    return _media_job(args["work_id"], "avatar_video", "volcengine", "omnihuman-1.5", {"route": args["route"]})


def t_inspect_audio(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """检测未接入时登记一条 not_run 检测记录：有产物引用，但不产生编造指标。"""
    _require(args, ["work_id"])
    job = _media_job(args["work_id"], "inspection_audio", "local", "detector-mock", {"target": "audio"})
    return {"inspection_id": job["id"], "outcome": "not_run", "metrics": {},
            "note": "检测能力未接入；not_run 不能当作 pass"}


def t_inspect_video(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["work_id"])
    job = _media_job(args["work_id"], "inspection_video", "local", "detector-mock", {"target": "video"})
    return {"inspection_id": job["id"], "outcome": "not_run", "metrics": {},
            "note": "检测能力未接入；not_run 不能当作 pass"}


def t_prepare_motion_assets(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """动作与变体准备：登记准备记录，不提交 GPU 作业（音频与预算未确认前不提交）。"""
    _require(args, ["work_id", "route"])
    ident = (st.get("works", args["work_id"]) or {}).get("identity_id")
    if not ident:
        raise ToolDenied("SELECTION_REQUIRED", "未选定已定版人物，不能准备动作资产")
    job = _media_job(args["work_id"], "motion_prep", "m2_worker", "prepare-only",
                     {"identity_id": ident, "route": args["route"]})
    return {"job_id": job["id"], "state": "not_submitted",
            "note": "仅登记准备意图；未提交 GPU 作业"}


def t_get_media_job(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["job_id"])
    job = st.get("media_jobs", args["job_id"])
    if not job:
        raise ToolDenied("VALIDATION_FAILED", "作业不存在")
    return job


def t_get_media_result(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["job_id"])
    job = st.get("media_jobs", args["job_id"])
    if not job:
        raise ToolDenied("VALIDATION_FAILED", "作业不存在")
    return {"job_id": job["id"], "state": job["state"], "result": None,
            "note": "MOCK：无真实产物字节"}


def t_cancel_media_job(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["job_id"])
    job = st.get("media_jobs", args["job_id"])
    if not job:
        raise ToolDenied("VALIDATION_FAILED", "作业不存在")
    if job["state"] == "not_submitted":
        job["state"] = "cancelled"
        st.put("media_jobs", job["id"], job, {"work_id": job.get("work_id")})
        return {"job_id": job["id"], "state": "cancelled", "note": "未向外提交，无费用可退"}
    return {"job_id": job["id"], "state": job["state"],
            "note": "已受理的外部作业需对账核实，不伪报取消"}


def t_propose_memory(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """只创建候选：审核合并前不参与跨任务检索。"""
    _require(args, ["namespace", "content_digest"])
    if args.get("state") not in (None, "proposed"):
        raise ToolDenied("MEMORY_WRITE_DENIED", "Agent 只能提交 proposed 候选，审核合并由业务服务执行")
    c = ac.MemoryCandidate(
        id=st.new_id("mem"), task_id=ctx.get("task_id", ""), work_item_id=ctx.get("work_item_id", ""),
        scope=args.get("scope", "role"), namespace=args["namespace"], content_digest=args["content_digest"],
        evidence_refs=args.get("evidence_refs") or [], applicability=args.get("applicability") or {},
    )
    st.put("memory_candidates", c.id, c.model_dump(), {"work_id": ctx.get("work_id", "")})
    return {"memory_candidate_id": c.id, "state": "proposed"}


def t_plan_work_items(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["task_id"])
    return {"task_id": args["task_id"], "note": "工作图由编排器生成并经业务校验登记，Agent 不能自填依赖"}


def t_get_progress(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["task_id"])
    task = st.get("tasks", args["task_id"])
    if not task:
        raise ToolDenied("VALIDATION_FAILED", "任务不存在")
    return {"stage": task.get("stage"), "state": task.get("state"),
            "pending_selection_ids": task.get("pending_selection_ids", [])}


def t_read_report(args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    _require(args, ["report_id"])
    d = st.get("quality_decisions", args["report_id"])
    return d or {"note": "无该报告"}


TOOLS: Dict[str, Callable[[Dict[str, Any], Dict[str, Any]], Dict[str, Any]]] = {
    "search_content_history": t_search_content_history,
    "get_presenter_profile": t_get_presenter_profile,
    "list_approved_assets": t_list_approved_assets,
    "register_script_candidates": t_register_script_candidates,
    "compile_performance_plan": t_compile_performance_plan,
    "submit_quality_report": t_submit_quality_report,
    "compile_speech_expression": t_compile_speech_expression,
    "submit_tts": t_submit_tts,
    "submit_motion": t_submit_motion,
    "submit_lipsync": t_submit_lipsync,
    "submit_avatar_video": t_submit_avatar_video,
    "prepare_motion_assets": t_prepare_motion_assets,
    "inspect_audio": t_inspect_audio,
    "inspect_video": t_inspect_video,
    "get_media_job": t_get_media_job,
    "get_media_result": t_get_media_result,
    "cancel_media_job": t_cancel_media_job,
    "propose_memory": t_propose_memory,
    "plan_work_items": t_plan_work_items,
    "get_progress": t_get_progress,
    "read_report": t_read_report,
}

# 会写入业务账本的受控工具（用于幂等重放）
SIDE_EFFECT_TOOLS = {
    "register_script_candidates", "compile_performance_plan", "submit_quality_report",
    "compile_speech_expression", "submit_tts", "submit_motion", "submit_lipsync",
    "submit_avatar_video", "prepare_motion_assets",
    "propose_memory",
}


def args_digest(args: Dict[str, Any]) -> str:
    return ac.digest(args)


# 成功调用的 `message` 里存的是**完整结果载荷**，它同时是幂等重放的取回来源。
# 所以这部分不能按日志长度截断：写稿结果带上自修复留痕后超过 300 字，就会被截成
# 非法 JSON → 重放时反序列化失败 → 退化成空结果 → 产物引用全丢 → 整个工作项被判
# `RESULT_INCOMPLETE` 失败（**真实发生过**）。日志可读性由 `outcome`/`replayed` 与界面
# 渲染负责，不靠牺牲"可回放"来换。
_RESULT_PAYLOAD_CAP = 8000
_LOG_MESSAGE_CAP = 300


def invoke(role: str, tool: str, args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """唯一工具入口：权限 → 存在性 → 参数 → 幂等 → 执行 → 审计。

    幂等的边界是**同一份输入的同一次尝试**：键里带输入摘要与 `attempt`。
    同一尝试内参数相同的重复调用仍然只执行一次（保护付费与外部副作用），但
    ①用户显式要求重跑（attempt 递增）、②工作项输入改变（例如补了参考资料）都必须
    真的重执行——否则"重新生成"永远只返回上次的结果，"补资料再出稿"根本不会执行。
    """
    work_item_id = ctx.get("work_item_id", "")
    ad = args_digest(args)
    attempt = ctx.get("attempt")
    inp = ctx.get("input_digest")
    idem = (f"{work_item_id}:{tool}:{ad}"
            + (f":i{inp}" if inp else "")
            + (f":a{attempt}" if attempt else ""))

    def audit(outcome: str, message: str, replayed: bool = False,
              cap: int = _LOG_MESSAGE_CAP) -> None:
        if role not in ROLES:
            # 拒绝审计也要保存旧/未知角色，不能套用当前 AgentRole 导致拒绝路径崩溃。
            # 原始调用者只存在审计表，不作为 AgentWorkItem 或可执行角色注册。
            record = {
                "id": st.new_id("audit"), "work_item_id": work_item_id,
                "role": role, "tool": tool, "args_digest": ad,
                "idempotency_key": idem, "outcome": "denied", "message": message[:300],
                "replayed": False, "created_at": now_iso(),
            }
            st.put("agent_tool_audit", record["id"], record, {"work_item_id": work_item_id})
            return
        rec = ac.ToolCallRecord(
            id=st.new_id("audit"), work_item_id=work_item_id, role=role, tool=tool,
            args_digest=ad, idempotency_key=idem, outcome=outcome, message=message[:cap],
            replayed=replayed,
        )
        st.put("agent_tool_audit", rec.id, rec.model_dump(), {"work_item_id": work_item_id})

    spec = ROLES.get(role)
    if spec is None:
        audit("denied", "未知角色")
        raise ToolDenied("ROLE_UNKNOWN", f"未知角色 {role}")
    if not isinstance(tool, str) or not re.fullmatch(r"[a-z_]{2,40}", tool):
        audit("denied", "非法工具名")
        raise ToolDenied("TOOL_NOT_ALLOWED", f"非法工具名：{tool!r}")
    if tool not in spec.tools:
        audit("denied", "角色无权调用")
        raise ToolDenied("TOOL_NOT_ALLOWED", f"角色 {role} 无权调用 {tool}（越权工具调用已拒绝）")
    fn = TOOLS.get(tool)
    if fn is None:
        audit("denied", "工具未实现")
        raise ToolDenied("TOOL_NOT_ALLOWED", f"工具未实现：{tool}")

    if tool in SIDE_EFFECT_TOOLS:
        for r in st.all_rows("agent_tool_audit", "work_item_id=?", [work_item_id]):
            if r.get("idempotency_key") == idem and r.get("outcome") == "ok":
                audit("ok", "幂等重放，未重复执行", replayed=True)
                try:
                    prev = json.loads(r.get("message") or "")
                    if not isinstance(prev, dict):
                        raise ValueError("原结果载荷不是 JSON 对象")
                except (TypeError, ValueError):
                    # 静默返回 `{}` 会让重放"看起来成功、却拿不到任何产物引用"，
                    # 调用方只能收到一句"结果不完整"，根因被藏起来。宁可明确报错。
                    audit("error", "幂等重放命中，但原结果载荷无法取回")
                    raise ToolDenied(
                        "REPLAY_PAYLOAD_MISSING",
                        "幂等重放命中，但无法取回原结果载荷；不接受空结果冒充已完成")
                return {"replayed": True, "idempotency_key": idem, "result": prev}

    try:
        result = fn(dict(args), dict(ctx))
    except ToolDenied:
        audit("denied", "业务门禁拒绝")
        raise
    except Exception as exc:
        audit("error", f"{type(exc).__name__}: {exc}")
        raise ToolDenied("TOOL_ERROR", f"{type(exc).__name__}: {exc}")

    audit("ok", json.dumps(result, ensure_ascii=False), cap=_RESULT_PAYLOAD_CAP)
    return {"replayed": False, "idempotency_key": idem, "result": result}


def tool_names() -> List[str]:
    return sorted(TOOLS.keys())
