"""总控编排器（supervisor）。

职责：把一期作品拆成显式工作项（AgentWorkItem），按依赖分层并行委派给四类角色，
遇到用户选择门即停住等待显式决定，重启后从业务库恢复未完成工作项继续推进。

边界：
- 质量通过不等于用户采用：选择门只认业务库里用户写入的 SelectionDecision。
- 依赖版本不符（稿件重生成、音频失效）时下游工作项标记 superseded 并重建。
- 重型 GPU 作业串行：复用 engine 的单飞行锁，逻辑并行不等于 GPU 并行。
"""
from __future__ import annotations

import asyncio
import os
from typing import Any, Dict, List, Optional

from .. import storage as st
from ..contracts import now_iso
from . import contracts as ac, results as res
from .models import build_model
from .roles import ROLES, require_skill_refs
from .tools import invoke

MAX_ATTEMPTS = int(os.environ.get("AVATAR_STUDIO_MAX_ATTEMPTS", "2"))
PARALLEL_LIMIT = int(os.environ.get("AVATAR_STUDIO_AGENT_PARALLEL", "3"))

# 阶段 → (角色, 目标, 依赖的阶段内序号, 需要的 Skill)
def _s(tool: str, **args) -> Dict[str, Any]:
    return {"tool": tool, "args": args}


STAGE_PLAN: Dict[str, List[Dict[str, Any]]] = {
    "script": [
        {"key": "script", "role": "content", "objective": "按用户提示词直接生成三个不同角度的候选稿", "skills": ["S01", "S02"],
         "inputs": ["work_id", "brief"],
         "script": [_s("register_script_candidates", work_id="{work_id}", topic="{topic}")]},
    ],
    "content_review": [
        {"key": "review", "role": "quality", "objective": "逐稿执行事实/查重/口语检查并登记结论", "skills": ["S03"],
         "inputs": ["work_id", "batch_digest"],
         "script": [_s("search_content_history", query="{topic}"),
                    _s("submit_quality_report", work_id="{work_id}", subject_id="__all__")]},
    ],
    "avatar_variant": [
        {"key": "perf_plan", "role": "content", "objective": "由已采用稿件生成表演意图计划", "skills": ["S02"],
         "inputs": ["work_id", "script_id"],
         "script": [_s("compile_performance_plan", work_id="{work_id}", script_version_id="{script_id}")]},
        {"key": "avatar_prep", "role": "avatar", "objective": "读取已定版人物，准备动作与变体", "skills": ["S04", "S05"],
         "inputs": ["work_id", "identity_id", "route"],
         "script": [_s("get_presenter_profile", identity_id="{identity_id}"),
                    _s("prepare_motion_assets", work_id="{work_id}", route="{route}")]},
    ],
    "tts": [
        # 表达编译依赖已冻结的 PerformancePlan：先出计划，声音分支才能编译
        {"key": "audio", "role": "audio", "objective": "编译表达并检查音频（合成由用户试听路径创建）", "skills": ["S06"],
         "inputs": ["work_id", "plan_id"],
         "depends": ["avatar_variant.perf_plan"],
         "script": [_s("list_approved_assets", kind="voice"),
                    _s("compile_speech_expression", work_id="{work_id}",
                       performance_plan_id="{plan_id}")]},
    ],
    "talking_head": [
        {"key": "talking_head", "role": "avatar", "objective": "按已选路线与已确认音频提交口播作业", "skills": ["S05"],
         "inputs": ["work_id", "route"],
         "script": [_s("submit_motion", work_id="{work_id}", route="{route}"),
                    _s("submit_lipsync", work_id="{work_id}", route="{route}")]},
    ],
    "video_review": [
        {"key": "video_review", "role": "quality", "objective": "成片技术检测与人工观感复核", "skills": ["S08"],
         "script": [_s("inspect_video", work_id="{work_id}")]},
    ],
}

# 选择门：阶段结束后必须由用户显式决定
SELECTION_GATES = {
    "content_review": "sel_script",
    "tts": "sel_audio",
}


def _wi_id(task_id: str, stage: str, key: str) -> str:
    return f"wi_{task_id}_{stage}_{key}"


def _dep_id(task_id: str, stage: str, dep: str) -> str:
    """依赖可写 `key`（同阶段）或 `stage.key`（跨阶段）。"""
    if "." in dep:
        s, k = dep.split(".", 1)
        return _wi_id(task_id, s, k)
    return _wi_id(task_id, stage, dep)


def _ctx(task: dict, work: dict) -> Dict[str, Any]:
    topic = (work.get("brief") or {}).get("topic", "")
    return {
        "work_id": task["work_id"],
        "task_id": task["id"],
        "topic": topic,
        "brief": work.get("brief") or {},
        "batch_digest": ac.digest(st.get("script_batches", task["work_id"]) or {}),
        "topic_digest": ac.digest(topic),
        "identity_id": work.get("identity_id") or "",
        "voice_asset_id": work.get("voice_asset_id") or "",
        "script_id": work.get("script_version_id") or "",
        "route": task.get("route") or work.get("route") or "M2",
        "plan_id": _latest_plan_id(task["work_id"]),
    }


def _spec_of(stage: str, key: str) -> Dict[str, Any]:
    for s in STAGE_PLAN.get(stage, []):
        if s["key"] == key:
            return s
    return {}


def _key_of(item_id: str, task_id: str, stage: str) -> str:
    """工作项 ID 形如 wi_{task_id}_{stage}_{key}，key 本身可含下划线。"""
    prefix = f"wi_{task_id}_{stage}_"
    return item_id[len(prefix):] if item_id.startswith(prefix) else item_id.rsplit("_", 1)[-1]


def _latest_plan_id(work_id: str) -> str:
    rows = st.all_rows("performance_plans", "work_id=?", [work_id])
    return rows[-1]["id"] if rows else ""


def build_work_items(task: dict, work: dict) -> List[ac.AgentWorkItem]:
    """生成整期工作图并落库（幂等：已存在且未过期则复用）。"""
    ctx = _ctx(task, work)
    items: List[ac.AgentWorkItem] = []
    for stage, specs in STAGE_PLAN.items():
        for spec in specs:
            wid = _wi_id(task["id"], stage, spec["key"])
            # 摘要只绑定该工作项真正依赖的输入：上游项不因下游版本变化而失效
            bound = spec.get("inputs", ["work_id", "topic"])
            input_digest = ac.digest({"stage": stage, "key": spec["key"],
                                      **{k: ctx[k] for k in bound}})
            existing = st.get("agent_work_items", wid)
            if existing and existing.get("input_digest") == input_digest:
                items.append(ac.AgentWorkItem(**existing))
                continue
            item = ac.AgentWorkItem(
                id=wid,
                task_id=task["id"],
                stage=stage,
                role=spec["role"],
                objective=spec["objective"],
                depends_on_ids=[_dep_id(task["id"], stage, d) for d in spec.get("depends", [])],
                input_refs=[{"work_id": task["work_id"], "script_version_id": ctx["script_id"] or None}],
                input_digest=input_digest,
                skill_refs=require_skill_refs(spec["skills"]) if spec["skills"] else [],
                namespace=f"{task['mode']}/{task['id']}/{wid}",
                mode=task.get("mode", "mock"),
            )
            st.put("agent_work_items", item.id, item.model_dump(), {"task_id": task["id"]})
            items.append(item)
    return items


def _save(item: ac.AgentWorkItem) -> ac.AgentWorkItem:
    item.updated_at = now_iso()
    st.put("agent_work_items", item.id, item.model_dump(), {"task_id": item.task_id})
    return item


def reset_stage(task_id: str, stage: str) -> int:
    """把一个已结束的阶段重新排队，供"用户显式要求重跑"使用（如「重新生成三稿」）。

    只重置本阶段工作项的状态：旧尝试的 `AgentResult` 仍留在结果表里作为证据，
    `attempt` 继续累加——"重跑过几次、每次结果如何"都可查。不清空任何产物台账，
    也不动其它阶段（重跑写稿不该把已完成的审核/配音一起推倒）。
    """
    reset = 0
    for row in st.all_rows("agent_work_items", "task_id=?", [task_id]):
        if row.get("stage") != stage:
            continue
        if row.get("state") in ("succeeded", "failed", "blocked"):
            row["state"] = "queued"
            _save(ac.AgentWorkItem(**row))
            reset += 1
    return reset


def _emit(task_id: str, type_: str, message: str, stage: Optional[str] = None, state: Optional[str] = None) -> None:
    from .. import engine

    engine.emit(task_id, type_, message, stage, state)


async def _run_work_item(task: dict, work: dict, item: ac.AgentWorkItem,
                         script: Optional[List[Dict[str, Any]]] = None) -> ac.AgentResult:
    """执行单个工作项：模型决策 → 受控工具 → 结果校验 → 落库。"""
    ctx = _ctx(task, work)
    ctx["work_item_id"] = item.id
    ctx["role"] = item.role
    # 幂等键按"这一次尝试"计算（见 tools.invoke）：把 attempt 带进上下文，
    # 否则用户要求重跑时参数没变 → 键没变 → 被当成幂等重放，按钮只会返回上次的结果。
    ctx["attempt"] = item.attempt
    # 还要带上本工作项的输入摘要：`attempt` 只在**同一份输入**下才连续。
    # 输入变了（例如给作品补了参考资料）时 `build_work_items` 会按新摘要重建工作项，
    # attempt 从 0 起算 → 键与上一轮撞上 → 被当成重放，**新的输入根本没有被执行**。
    # 曾因此让"补资料后重新出稿"返回旧批次、工作项反而判失败。
    ctx["input_digest"] = item.input_digest
    model = build_model(item.role, ctx, script=script)
    ctx["model_run_id"] = model.run_id

    tool_calls: List[Dict[str, Any]] = []
    output_refs: List[Dict[str, Any]] = []
    error: Optional[Dict[str, Any]] = None
    state = "succeeded"

    try:
        while True:
            decision = model.decide()
            if decision is None:
                break
            try:
                out = invoke(item.role, decision["tool"], decision["args"], ctx)
            except Exception as exc:
                code = getattr(exc, "code", "TOOL_ERROR")
                # 依赖未满足属于阻断，不是崩溃：保留证据并停止本工作项
                state = "blocked" if code in ("DEPENDENCY_NOT_MET", "SELECTION_REQUIRED",
                                              "BUDGET_NOT_AUTHORIZED", "ROUTE_NOT_SELECTED") else "failed"
                error = {"code": code, "message": getattr(exc, "message", str(exc))}
                tool_calls.append({"tool": decision["tool"], "outcome": "denied", "code": code})
                break
            tool_calls.append({"tool": decision["tool"], "outcome": "ok",
                               "replayed": out.get("replayed", False)})
            r = out.get("result") or {}
            # 单值引用
            for k in ("batch_id", "plan_id", "quality_decision_id", "package_id", "id",
                      "memory_candidate_id", "inspection_id", "job_id"):
                if r.get(k):
                    output_refs.append({"kind": k, "id": r[k]})
            # 批量引用（如逐稿审核）
            for k, v in r.items():
                if k.endswith("_ids") and isinstance(v, list):
                    output_refs += [{"kind": k[:-4], "id": x} for x in v]
    except Exception as exc:  # 编排异常不静默
        state = "failed"
        error = {"code": "AGENT_ERROR", "message": f"{type(exc).__name__}: {exc}"}

    result = res.make_result(item, state, output_refs, tool_calls,
                             model_run_id=model.run_id, error=error)
    try:
        res.validate_result(result, item)
    except res.ResultRejected as rej:
        result.state = "failed"
        result.error = {"code": rej.code, "message": rej.message}
        result.result_digest = ac.digest({"work_item": item.id, "state": "failed"})
    st.put("agent_results", result.id, result.model_dump(), {"work_item_id": item.id})
    item.state = result.state
    item.last_error = result.error
    _save(item)
    return result


def _deps_done(item: ac.AgentWorkItem, states: Dict[str, str]) -> bool:
    return all(states.get(d) == "succeeded" for d in item.depends_on_ids)


async def run_stage(task: dict, work: dict, stage: str) -> Dict[str, Any]:
    """执行一个阶段内的全部工作项。

    同阶段内无依赖关系的工作项并行执行；有依赖的分批推进（先跑完依赖，再跑后继）。
    """
    from .. import postprocess_worker

    if stage in postprocess_worker.STAGES:
        record = postprocess_worker.run_stage(task, work, stage)
        return {"executed": 1, "states": {record["id"]: record["state"]},
                "failures": [{"work_item_id": record["id"], "state": record["state"],
                              "error": record["error"]}] if record["state"] != "succeeded" else []}
    if not STAGE_PLAN.get(stage):
        return {"executed": 0, "states": {}, "failures": [
            {"state": "blocked", "error": {"code": "STAGE_NOT_REGISTERED",
                                             "message": f"阶段 {stage} 没有已注册执行器"}}]}

    sem = asyncio.Semaphore(PARALLEL_LIMIT)
    executed: List[ac.AgentResult] = []
    states: Dict[str, str] = {}

    async def one(item: ac.AgentWorkItem):
        async with sem:
            item.state = "running"
            item.attempt += 1
            _save(item)
            _emit(task["id"], "work_item.started", f"[{item.role}] {item.objective}", stage, task["state"])
            key = _key_of(item.id, task["id"], stage)
            return await _run_work_item(task, work, item, script=_spec_of(stage, key).get("script"))

    while True:
        all_items = build_work_items(task, work)
        items = [i for i in all_items if i.stage == stage]
        states = {i.id: i.state for i in all_items}
        pending = [i for i in items if i.state in ("queued", "retry_wait") and _deps_done(i, states)]
        if not pending:
            break
        round_results = await asyncio.gather(*[one(i) for i in pending])
        executed += round_results
        if all(r.state != "succeeded" for r in round_results):
            break  # 本轮全失败，避免死循环

    # 恢复时必须检查持久工作图，不能只检查本轮新执行的结果。
    failures = [{"work_item_id": i.id, "state": i.state,
                 "error": i.last_error or {"code": "DEPENDENCY_NOT_MET",
                                           "message": "阶段仍有未完成的工作项"}}
                for i in items if i.state != "succeeded"]
    return {
        "executed": len(executed),
        "states": {i.id: i.state for i in items},
        "failures": failures,
    }


async def advance(task_id: str) -> None:
    """推进任务：按阶段顺序执行，遇到选择门或阻断即停。"""
    from .. import engine

    task = engine.get_task(task_id)
    work = st.get("works", task["work_id"]) or {}
    if task["state"] in ("succeeded", "failed", "cancelled", "blocked", "waiting_selection"):
        return

    # 老工作图保留为证据，不把已移除的角色/研究节点静默跳过并继承成功。
    valid_ids = {_wi_id(task_id, stage, spec["key"])
                 for stage, specs in STAGE_PLAN.items() for spec in specs}
    old_items = st.all_rows("agent_work_items", "task_id=?", [task_id])
    if any(i.get("role") not in ROLES or i["id"] not in valid_ids for i in old_items):
        task["block_reason"] = "LEGACY_AGENT_GRAPH"
        engine.set_state(task, "blocked", task["stage"],
                         ("gate.blocked", "旧 Agent 工作图不兼容 v2.4，请新建执行；历史结果保留"))
        return

    order = ["script", "content_review", "avatar_variant", "tts", "talking_head",
             "postprocess", "video_review", "publish_package"]
    start = order.index(task["stage"]) if task["stage"] in order else 0

    for stage in order[start:]:
        task = engine.get_task(task_id)
        work = st.get("works", task["work_id"]) or {}
        if task["state"] in ("cancelled", "failed", "blocked", "waiting_selection"):
            return

        # 依赖门禁：口播必须等音频确认 + 路线与预算确认
        if stage == "talking_head":
            if not any(a.get("confirmed") for a in st.all_rows("audios", "work_id=?", [task["work_id"]])):
                engine.set_state(task, "blocked", stage, ("gate.blocked", "最终音频未确认，口播不可提交"))
                task["block_reason"] = "AUDIO_CONFIRMATION_REQUIRED"
                engine._save_task(task)
                return
            if not task.get("route_confirmed"):
                engine.set_state(task, "blocked", stage, ("gate.blocked", "未确认路线与预算，口播不可提交"))
                task["block_reason"] = "COST_CONFIRMATION_REQUIRED"
                engine._save_task(task)
                return

        engine.set_state(task, "running", stage, ("stage.started", f"进入阶段 {stage}"))
        summary = await run_stage(task, work, stage)
        if summary.get("failures"):
            f = summary["failures"][0]
            err = f.get("error") or {}
            if f.get("state") == "blocked" or err.get("code") in ("DEPENDENCY_NOT_MET", "SELECTION_REQUIRED",
                                   "BUDGET_NOT_AUTHORIZED", "ROUTE_NOT_SELECTED"):
                engine.set_state(task, "blocked", stage,
                                 ("gate.blocked", f"{err.get('code')}: {err.get('message')}"))
                task["block_reason"] = err.get("code")
                engine._save_task(task)
                return
            engine.set_state(task, "failed", stage, ("task.failed", f"{err.get('code')}: {err.get('message')}"))
            task["last_error"] = err
            engine._save_task(task)
            return

        gate = SELECTION_GATES.get(stage)
        if gate:
            task = engine.get_task(task_id)
            ids = list(task.get("pending_selection_ids") or [])
            if gate not in ids:
                ids.append(gate)
            task["pending_selection_ids"] = ids
            engine.set_state(task, "waiting_selection", stage,
                             ("selection.requested", f"等待用户决定：{gate}"))
            engine._save_task(task)
            return

        if stage == "talking_head":
            # 重型 GPU 作业串行：单飞行锁
            await engine.gpu_slot()

    task = engine.get_task(task_id)
    if task["stage"] == "publish_package" and task["state"] != "succeeded":
        engine.set_state(task, "succeeded", "publish_package", ("package.ready", "发布就绪包已生成"))


def plan_snapshot(task_id: str) -> Dict[str, Any]:
    """供检查与界面展示：当前工作图状态。"""
    rows = st.all_rows("agent_work_items", "task_id=?", [task_id])
    return {
        "count": len(rows),
        "by_state": {s: sum(1 for r in rows if r.get("state") == s)
                     for s in ("queued", "running", "succeeded", "failed", "blocked")},
        "items": [{"id": r["id"], "role": r["role"], "stage": r["stage"], "state": r["state"],
                   "objective": r["objective"]} for r in rows],
    }
