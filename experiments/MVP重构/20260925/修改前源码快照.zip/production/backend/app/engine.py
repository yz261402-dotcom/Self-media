"""任务编排推进器（Mock Provider）。

约束：
- 逻辑并行不等于 GPU 并行；单 GPU 重型作业串行排队（此处以单飞行锁表达）。
- 用户选择（SelectionDecision）与质量审批（ReviewDecision）分离，等待选择时停住。
- 提交结果未知时先对账，不盲目重发；取消只停止新提交。
"""
from __future__ import annotations

import asyncio
import os
import weakref
from typing import Any, Dict, List, Optional

from . import storage as st
from .contracts import ApiError, PublishPackage, now_iso
from .mockdata import PACKAGE_FILES

# 编排器选择：agents = Agent 编排（默认）；simple = 无 Agent 的确定性推进
ORCHESTRATOR = os.environ.get("AVATAR_STUDIO_ORCHESTRATOR", "agents").strip().lower()

# 单 GPU 重型作业互斥。锁按**事件循环**持有：生产只有一条循环，等价于全局串行；
# 而 asyncio.Lock 一旦被某个循环 acquire 就绑死那个循环，跨循环再用会直接抛
# `RuntimeError: ... is bound to a different event loop`——编排会把重型阶段丢给
# 后台任务执行，测试里每个 TestClient 一条循环，共用一把锁就会炸在与被测逻辑无关的地方。
_gpu_locks: "weakref.WeakKeyDictionary[Any, asyncio.Lock]" = weakref.WeakKeyDictionary()
_scheduled: Dict[str, asyncio.Task] = {}


def _gpu_lock() -> asyncio.Lock:
    loop = asyncio.get_running_loop()
    lock = _gpu_locks.get(loop)
    if lock is None:
        lock = asyncio.Lock()
        _gpu_locks[loop] = lock
    return lock


async def gpu_slot() -> None:
    """重型 GPU 作业串行位：逻辑并行不等于 GPU 并行。"""
    async with _gpu_lock():
        await asyncio.sleep(0)


def _save_task(task: dict) -> dict:
    task["stage_rows"] = st.stage_rows(task["stage"], task["state"])
    st.put("tasks", task["id"], task, {"work_id": task["work_id"]})
    return task


def emit(task_id: str, type_: str, message: str, stage: str | None = None, state: str | None = None) -> None:
    st.add_event(task_id, {"type": type_, "occurred_at": now_iso(), "stage": stage, "state": state, "message": message})


def get_task(task_id: str) -> dict:
    t = st.get("tasks", task_id)
    if not t:
        raise KeyError(task_id)
    t["stage_rows"] = st.stage_rows(t["stage"], t["state"])
    return t


def set_state(task: dict, state: str, stage: str | None = None, event: tuple | None = None) -> dict:
    task["state"] = state
    if stage:
        task["stage"] = stage
    if event:
        emit(task["id"], event[0], event[1], task["stage"], state)
    return _save_task(task)


async def _advance(task_id: str) -> None:
    """按依赖推进；遇到用户选择门即返回，等待显式决定后由 API 重新调度。"""
    if ORCHESTRATOR == "agents":
        from .agents import supervisor

        await supervisor.advance(task_id)
        return
    try:
        task = get_task(task_id)
        if task["state"] in ("cancelled", "failed", "blocked", "succeeded"):
            return

        if task["stage"] == "topic":
            set_state(task, "running", "script", ("stage.started", "开始资料检索与三角度写稿"))
            await asyncio.sleep(1.2)
            task = get_task(task_id)

        if task["stage"] == "script":
            set_state(task, "running", "content_review", ("stage.started", "逐稿执行事实、查重与口语检查"))
            await asyncio.sleep(1.5)
            task = get_task(task_id)

        if task["stage"] == "content_review":
            task["pending_selection_ids"] = ["sel_script"]
            set_state(task, "waiting_selection", None, ("selection.requested", "三稿已就绪，等待用户选稿"))
            return

        if task["stage"] == "avatar_variant":
            set_state(task, "running", "tts", ("stage.started", "声音、人物与剪辑准备并行推进"))
            await asyncio.sleep(1.2)
            task = get_task(task_id)

        if task["stage"] == "tts":
            task["pending_selection_ids"] = ["sel_audio"]
            set_state(task, "waiting_selection", None, ("selection.requested", "全文音频已合成，等待用户试听确认"))
            return

        if task["stage"] == "talking_head":
            # 真实实现：先原子预留预算并记录幂等键，再提交外部作业
            set_state(task, "waiting_provider", None, ("provider.submitted", f"{task['route']} 路线已提交，等待外部作业"))
            async with _gpu_lock:
                await asyncio.sleep(2.5)
            task = get_task(task_id)
            if task["state"] == "cancelled":
                return
            set_state(task, "running", "postprocess", ("provider.completed", "外部作业完成，进入后期"))
            await asyncio.sleep(1.2)
            task = get_task(task_id)

        if task["stage"] == "postprocess":
            set_state(task, "running", "video_review", ("stage.started", "成片技术检测与人工观感复核"))
            await asyncio.sleep(1.0)
            task = get_task(task_id)

        if task["stage"] == "video_review":
            set_state(task, "running", "publish_package", ("stage.started", "冻结交付版本并生成 manifest"))
            await asyncio.sleep(1.0)
            task = get_task(task_id)

        if task["stage"] == "publish_package":
            build_package(task)
            set_state(task, "succeeded", None, ("package.ready", "发布就绪包已生成，可预览与下载"))
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # 失败保留证据，不静默继续
        task = st.get("tasks", task_id)
        if task:
            task["state"] = "failed"
            task["last_error"] = ApiError(code="ENGINE_ERROR", message=str(exc)).model_dump()
            _save_task(task)
            emit(task_id, "task.failed", f"编排异常：{exc}", task.get("stage"), "failed")


def schedule(task_id: str) -> None:
    """调度推进；同一任务不重复并发执行。"""
    if task_id in _scheduled and not _scheduled[task_id].done():
        return
    _scheduled[task_id] = asyncio.create_task(_advance(task_id))


def build_package(task: dict) -> PublishPackage:
    work = st.get("works", task["work_id"]) or {}
    batch = st.get("script_batches", task["work_id"]) or {}
    chosen = None
    sel = st.all_rows("selections", "work_id=?", [task["work_id"]])
    decided = {s.get("kind"): s.get("selected_ref") for s in sel if s.get("state") == "selected"}
    for c in batch.get("candidates", []):
        if c.get("id") == decided.get("script"):
            chosen = c
            break
    pkg = PublishPackage(
        id=st.new_id("pkg"),
        work_id=task["work_id"],
        task_id=task["id"],
        mode=task.get("mode", "mock"),
        state="ready",
        title=(chosen or {}).get("title", work.get("name", "未命名作品")),
        description=(chosen or {}).get("description", ""),
        tags=(chosen or {}).get("tags", []),
        ai_label="本片人物与声音由 AI 生成（AI 标识规范版本待投产前核对）",
        files=[{"path": p, "bytes": 0, "sha256": "mock"} for p in PACKAGE_FILES],
        video_url=None,
        cover_url=None,
        download_url=f"/api/v1/publish-packages/{st.new_id('pkg')}/download",
        manifest_digest="sha256:mock-package-digest",
    )
    st.put("packages", pkg.id, pkg.model_dump(), {"work_id": pkg.work_id})
    return pkg


def resumable_tasks() -> List[str]:
    """可恢复任务清单：等待用户选择的任务不在其中，重启后不得被自动推进或代选。"""
    out = []
    for t in st.all_rows("tasks"):
        if t["state"] not in ("queued", "running", "waiting_provider"):
            continue
        if t.get("pending_selection_ids"):
            continue
        out.append(t["id"])
    return out


def recover_pending() -> int:
    """重启后识别未完成任务并重新调度（NFR-04）。

    没有运行中的事件循环时（离线工具、测试、启动前检查）只返回 0 并保留清单，
    不抛异常、也不声称已恢复——检查点不能代替账本。
    """
    ids = resumable_tasks()
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return 0
    for tid in ids:
        schedule(tid)
    return len(ids)
