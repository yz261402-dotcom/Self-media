"""ASR/对齐适配器接口（AC-MEDIA-04 的"ASR/对齐"能力位）。

红线（specs T07）：**ASR/对齐模型未选、未验前，不得假设已有能力。**
- 本模块默认**没有任何 provider**：`configured()` 为 False，真实 Worker 到字幕步
  必须 blocked（ASR_NOT_CONFIGURED），而不是用"按字数均分时间"之类的假时间轴；
- 对齐来源白名单沿用 T04 结论：provider / forced_alignment / asr_alignment；
  **均分时长不算对齐**——任何实现不得以均分充当时间戳来源；
- 测试可用注入 fixture adapter（显式标记 simulated），只证明处理逻辑，
  不得在生产路径出现。
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional, Protocol

from .errors import VideoBlocked

ALLOWED_ALIGNMENT_SOURCES = ("provider", "forced_alignment", "asr_alignment")

_ENV_PROVIDER = "AVATAR_STUDIO_ASR_PROVIDER"

# 已知 provider 占位：模型选型/许可/验证完成前保持空。
# 选型后在此登记，并附 validation_state 与证据（同 ProviderSpec 取向）。
KNOWN_PROVIDERS: Dict[str, Dict[str, Any]] = {}


class AsrAdapter(Protocol):
    """ASR/对齐适配器协议：输入音频路径，输出**源时间轴** cue 列表。"""

    provider_id: str
    alignment_source: str  # 必须在 ALLOWED_ALIGNMENT_SOURCES 内
    simulated: bool        # 测试夹具为 True；生产实现必须 False

    def transcribe(self, audio_path: str, script_text: str) -> List[Dict[str, Any]]:
        """返回 [{"start_ms", "end_ms", "text"}]，文本拼接须与 script_text 一致。"""
        ...


def configured() -> bool:
    return bool(os.environ.get(_ENV_PROVIDER))


def provider_id() -> Optional[str]:
    return os.environ.get(_ENV_PROVIDER)


def get_adapter() -> Optional[AsrAdapter]:
    """按环境取真实适配器。未配置返回 None；配置了未知 provider 明确报错。"""
    pid = provider_id()
    if not pid:
        return None
    impl = KNOWN_PROVIDERS.get(pid)
    if impl is None:
        raise VideoBlocked(
            "ASR_PROVIDER_UNKNOWN",
            f"ASR provider '{pid}' 未实现或未通过选型验证；已登记的 provider: "
            f"{sorted(KNOWN_PROVIDERS) or '无'}")
    return impl["adapter"]()


ASR_WORKER_URL_ENV = "AVATAR_STUDIO_ASR_WORKER_URL"
ASR_WORKER_TOKEN_ENV = "AVATAR_STUDIO_ASR_WORKER_TOKEN"
TOS_BUCKET_ENV = "AVATAR_STUDIO_TOS_BUCKET"

_QWEN_STAGES = ("asr", "align")
_SENTENCE_END = "。？！；!?"
_CLAUSE_END = ("，", "、", "；", "：", ",", ";", ":")
_TAIL_KEEP = "，。？！、；：,.?!;:"


def _restore_punctuation(items: List[Dict[str, Any]], alignment_text: str) -> List[Dict[str, Any]]:
    """把标点还回字级时间轴。

    强制对齐给出的是"字 → 时间"，标点不单独成条（`alignment` 里没有标点）。
    字幕却必须带标点：下游 `check_cues` 要求字幕去空白拼接与冻结正文逐字符一致，
    正文里的标点一个都不能少。做法是按顺序扫一遍 `alignment_text`，
    能与下一条 item 对上的算字，对不上的（标点/空白）挂到前一个字后面。
    字没扫完就说明时间轴没覆盖全文——这是硬错误，不是"差不多就行"。
    """
    units: List[Dict[str, Any]] = []
    i = 0
    for ch in alignment_text:
        if i < len(items) and ch == str(items[i].get("text") or ""):
            it = items[i]
            units.append({"start_ms": int(round(float(it["start"]) * 1000)),
                          "end_ms": int(round(float(it["end"]) * 1000)),
                          "text": ch, "tail": ""})
            i += 1
        elif units:
            units[-1]["tail"] += ch
    # 两个方向都要查：条目有剩余（正文短了）和正文有剩余（时间轴短了）
    # 都说明"字 → 时间"没覆盖全文，缺一块就不得出字幕。
    spoken = [c for c in alignment_text
              if c not in _TAIL_KEEP and c not in _SENTENCE_END and not c.isspace()]
    if i != len(items) or len(spoken) != len(items):
        raise VideoBlocked("ALIGN_COVERAGE_INCOMPLETE",
                           f"对齐覆盖不全：正文有效字 {len(spoken)} 字，"
                           f"时间轴 {len(items)} 条，匹配到 {i} 条；"
                           "时间轴未覆盖全文，不得据此生成字幕")
    return units


def _group_units(units: List[Dict[str, Any]], *, max_chars: int = 18,
                 max_ms: int = 5000, gap_ms: int = 320,
                 min_chars: int = 8) -> List[Dict[str, Any]]:
    """字级时间轴 → 句级字幕行。

    断句只用四类可核对的依据：句末标点、句中逗号且已够长、字间停顿、字数/时长上限。
    没有第五种来源——均分时长不算对齐，这里也不做"看起来差不多"的切分。
    """
    cues: List[Dict[str, Any]] = []
    cur: Optional[Dict[str, Any]] = None
    for u in units:
        tail = "".join(c for c in u["tail"] if c in _TAIL_KEEP)
        if cur is None:
            cur = {"start_ms": u["start_ms"], "end_ms": u["end_ms"],
                   "text": u["text"] + tail}
            continue
        gap = u["start_ms"] - cur["end_ms"]
        # 先把这个字（连同它后面的标点）并进来，再判断要不要收行——
        # 标点是"能断行"的信号，它必须先属于当前行，才谈得上"在它后面断"。
        cand = cur["text"] + u["text"] + tail
        body = "".join(c for c in cand if c not in _TAIL_KEEP)
        ended = cand[-1] in _SENTENCE_END
        clause = cand[-1] in _CLAUSE_END and len(body) >= min_chars
        too_long = len(body) >= max_chars
        too_wide = (u["end_ms"] - cur["start_ms"]) > max_ms
        if gap >= gap_ms:
            # 明显停顿：旧行到此为止，新行从这个字起
            cues.append(cur)
            cur = {"start_ms": u["start_ms"], "end_ms": u["end_ms"],
                   "text": u["text"] + tail}
        elif ended or clause or too_long or too_wide:
            cur["text"] = cand
            cur["end_ms"] = u["end_ms"]
            cues.append(cur)
            cur = None
        else:
            cur["text"] = cand
            cur["end_ms"] = u["end_ms"]
    if cur:
        cues.append(cur)
    return cues


class Qwen3CloudAdapter:
    """Qwen3-ASR-1.7B（识别）＋ Qwen3-ForcedAligner-0.6B（时间轴）。

    两个模型都跑在算力云 ASR-001 部署上，经 worker（HTTP + Bearer）提交，
    与 M2 共用同一套"提交 → 轮询 → 取产物"语义，只是阶段不同。

    音频要先发到火山 TOS 公开读：runner 在远端，拿不到本机磁盘路径，
    而公开 URL 也是 M2 一直在用的同一条素材通路（哈希声明 + 下载校验）。

    `alignment_source = forced_alignment`（白名单内）。识别文本另存
    `last_transcript`，用来核对"音频里到底说了什么"，不参与时间轴。
    """

    provider_id = "qwen3_cloud"
    alignment_source = "forced_alignment"
    simulated = False

    def __init__(self) -> None:
        self.last_transcript: str = ""
        self.last_asr_job: Dict[str, Any] = {}
        self.last_align_job: Dict[str, Any] = {}

    # ---- 素材发布 ----

    def _publish_audio(self, audio_path: str) -> tuple:
        import hashlib

        from ..digital_human import publish as pub

        h = hashlib.sha256()
        with open(audio_path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        digest = h.hexdigest()
        bucket = os.environ.get(TOS_BUCKET_ENV) or "douyin-avatar-studio"
        publisher = pub.TosPublisher(
            os.environ.get("AVATAR_STUDIO_VOLC_ACCESS_KEY", ""),
            os.environ.get("AVATAR_STUDIO_VOLC_SECRET_KEY", ""),
            bucket)
        key = f"audio/{digest}.wav"
        if not publisher.exists(key):
            publisher.ensure_bucket()
            publisher.publish_file(audio_path, key=key)
        return pub.public_url(bucket, pub.TOS_DEFAULT_REGION, key), f"sha256:{digest}"

    # ---- 远端作业 ----

    def _run_stage(self, stage: str, audio_url: str, declared: str,
                   script_text: str) -> Dict[str, Any]:
        from ..digital_human import worker_client as wc

        base = (os.environ.get(ASR_WORKER_URL_ENV) or "").strip().rstrip("/")
        token = (os.environ.get(ASR_WORKER_TOKEN_ENV)
                 or os.environ.get("AVATAR_STUDIO_M2_WORKER_TOKEN") or "")
        if not base:
            raise VideoBlocked(
                "ASR_NOT_CONFIGURED",
                f"未配置 {ASR_WORKER_URL_ENV}：Qwen3 ASR/对齐在算力云上执行，"
                "未接通时不得用任何替代时间轴（均分不算对齐）")
        request = {"stage": stage,
                   "model": "Qwen3-ASR-1.7B" if stage == "asr" else "Qwen3-ForcedAligner-0.6B",
                   "args": {"audio_url": audio_url, "audio_hash": declared,
                            "text": script_text}}
        resp = wc.transport(request, base_url=base, token=token,
                            allowed_stages=_QWEN_STAGES, poll_interval=5.0, max_wait=1800.0)
        doc = resp.get("json") or {}
        state = str(doc.get("state") or "").strip()
        if state != "succeeded":
            raise VideoBlocked(
                "ASR_STAGE_FAILED",
                f"{stage} 作业未成功（state={state or 'unknown'}，"
                f"code={doc.get('code')}，error={doc.get('error')}）；"
                "字幕时间轴只能来自成功的对齐，不得降级",
                {"job_id": doc.get("job_id"),
                 "tail": (doc.get("runner_output_tail") or "")[-500:]})

        out_url = str(doc.get("output_url") or "")
        if not out_url:
            raise VideoBlocked("ASR_OUTPUT_MISSING",
                               f"{stage} 作业没给出产物地址；无产物即无时间轴")
        # worker 的 public_base 是它自己那侧的 8081；本机经隧道访问的是另一个端口，
        # 这里换成本机 base，否则下载会被 401/连接拒绝挡住。
        if "/v1/outputs/" in out_url:
            out_url = base + "/v1/outputs/" + out_url.split("/v1/outputs/")[-1]
        raw = wc.transport({"method": "GET", "url": out_url}, base_url=base, token=token)
        body = raw.get("body")
        if isinstance(body, bytes):
            body = body.decode("utf-8", "replace")
        if not body:
            raise VideoBlocked("ASR_OUTPUT_UNREADABLE",
                               f"{stage} 产物下载为空（HTTP {raw.get('status_code')}）")
        try:
            parsed = json.loads(body)
        except Exception as e:  # noqa: BLE001
            raise VideoBlocked("ASR_OUTPUT_NOT_JSON",
                               f"{stage} 产物不是 JSON：{type(e).__name__}: {e}")
        return {"doc": parsed, "job": doc}

    def transcribe(self, audio_path: str, script_text: str) -> List[Dict[str, Any]]:
        # 先把"没接通"说清楚，再去上传素材：否则失败形态会变成 TOS 报错，
        # 真正的原因（没配 worker）被埋掉，还白白把素材发出去了。
        if not (os.environ.get(ASR_WORKER_URL_ENV) or "").strip():
            raise VideoBlocked(
                "ASR_NOT_CONFIGURED",
                f"未配置 {ASR_WORKER_URL_ENV}：Qwen3 ASR/对齐在算力云上执行，"
                "未接通时不得用任何替代时间轴（均分不算对齐）")
        audio_url, declared = self._publish_audio(audio_path)

        # 先识别：回答"音频里说了什么"，与稿件对照（只有一处读法差异也是差异）。
        asr = self._run_stage("asr", audio_url, declared, script_text)
        self.last_transcript = str(asr["doc"].get("text") or "")
        self.last_asr_job = asr["job"]

        align = self._run_stage("align", audio_url, declared, script_text)
        doc = align["doc"]
        self.last_align_job = align["job"]
        if str(doc.get("time_unit") or "seconds") != "seconds":
            raise VideoBlocked("ASR_ALIGN_UNIT_UNKNOWN",
                               f"对齐时间单位未知：{doc.get('time_unit')!r}")
        items = doc.get("alignment") or []
        if not items:
            raise VideoBlocked("ASR_ALIGN_EMPTY", "对齐结果为空；空时间轴不得进入字幕")
        units = _restore_punctuation(items, doc.get("alignment_text") or script_text)
        return _group_units(units)


KNOWN_PROVIDERS["qwen3_cloud"] = {
    "adapter": Qwen3CloudAdapter,
    "models": ["Qwen3-ASR-1.7B", "Qwen3-ForcedAligner-0.6B"],
    "validation_state": "deployed_inference_verified",
    "evidence": "ASR-001 部署（算力云 RTX 4080）+ 本项目真实音频作业；"
                "时间轴来源 forced_alignment，字级时间戳经标点还原后成句",
}


def require_adapter() -> AsrAdapter:
    """真实路径取适配器；取不到即 blocked（字幕必须有真实 ASR 时间轴）。"""
    adapter = get_adapter()
    if adapter is None:
        raise VideoBlocked(
            "ASR_NOT_CONFIGURED",
            f"未配置 ASR/对齐 provider（{_ENV_PROVIDER} 为空）；"
            "字幕时间轴只能来自真实 ASR/对齐，不得均分或臆造，故阻断")
    if adapter.alignment_source not in ALLOWED_ALIGNMENT_SOURCES:
        raise VideoBlocked(
            "ASR_ALIGNMENT_SOURCE_INVALID",
            f"对齐来源 '{adapter.alignment_source}' 不在白名单 "
            f"{ALLOWED_ALIGNMENT_SOURCES}（均分时长不算对齐）")
    return adapter
