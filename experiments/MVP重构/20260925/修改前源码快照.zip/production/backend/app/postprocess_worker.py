"""T07 代码后期 Worker：确定性执行，不创建 Agent、不走 MCP。

v2.4 边界不变：不把 mock 作业意图当作媒体产物；依赖/能力未就绪时登记
blocked 并保留证据；恢复相同输入复用记录，新输入保留独立执行证据。

T07 起 `postprocess` 阶段具备**真实执行路径**（mode=production 且依赖齐备）：
统一时间线（EditTimeline）→ 真实 ASR 时间轴（未配置即 blocked，绝不均分臆造）
→ 字幕检查与 ASS → FFmpeg 两遍响度/CFR/烧录/封面 → 规格/解码/响度实测验收。
失败与阻断一律留证，不伪造成功产物。`publish_package` 仍属 T09，保持 blocked。
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, List, Optional

from . import storage as st
from .contracts import now_iso
from .video import asr as v_asr
from .video import ffmpeg as v_ff
from .video import render as v_render
from .video import subtitles as v_sub
from .video import timeline as v_tl
from .video.errors import VideoBlocked, VideoRejected

STAGES = frozenset({"postprocess", "publish_package"})
WORKER_VERSION = "t07-media-1"


def _sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _runtime_path(rel_uri: str) -> str:
    """storage_uri（如 audio/<work>/<id>.wav）→ 本机绝对路径。"""
    backend_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(backend_root, "runtime", rel_uri.replace("/", os.sep))


def _snapshot(task: dict, work: dict, stage: str) -> dict:
    audios = st.all_rows("audios", "work_id=?", [task["work_id"]])
    media = [r for r in st.all_rows("media_jobs", "work_id=?", [task["work_id"]])
             if r.get("executor_kind") != "worker"]
    videos = st.all_rows("videos", "work_id=?", [task["work_id"]])
    batch = st.get("script_batches", task["work_id"]) or {}
    snapshot = {
        "task_id": task["id"], "mode": task.get("mode"), "stage": stage,
        "route": task.get("route"), "route_confirmed": task.get("route_confirmed"),
        "work": work, "script_batch": batch,
        # ASR provider 纳入摘要：配置从无到有/换 provider 属于新输入，
        # 恢复时不能复用"因缺 ASR 而 blocked"的旧记录。
        "asr_provider": v_asr.provider_id(),
        "audios": sorted(audios, key=lambda r: r["id"]),
        "videos": sorted(videos, key=lambda r: r["id"]),
        "media": sorted(media, key=lambda r: r["id"]),
        "quality": sorted(st.all_rows("quality_decisions", "work_id=?", [task["work_id"]]),
                          key=lambda r: r["id"]),
    }
    digest = hashlib.sha256(json.dumps(snapshot, ensure_ascii=False, sort_keys=True,
                                       separators=(",", ":")).encode("utf-8")).hexdigest()
    return snapshot, digest


def _selected_script(work: dict, batch: dict) -> Optional[dict]:
    sid = work.get("script_version_id")
    for c in batch.get("candidates", []):
        if c.get("id") == sid:
            return c
    return None


def _final_audio(work: dict, audios: List[dict]) -> Optional[dict]:
    return next((a for a in audios
                 if a.get("kind") == "full" and a.get("approved") and a.get("confirmed")
                 and a.get("voice_asset_id") == work.get("voice_asset_id")), None)


def _original_video(work_id: str) -> Optional[dict]:
    vids = [v for v in st.all_rows("videos", "work_id=?", [work_id])
            if v.get("kind") == "original" and not v.get("is_mock")]
    return vids[-1] if vids else None


def _asr_cues_cached(audio: dict, audio_path: str, script_text: str) -> Dict[str, Any]:
    """ASR 时间轴缓存：键 = audio_id，校验音频文件哈希。

    音频变更 → 哈希不符 → 重新对齐（旧时序绝不沿用）；同音频复用旧结果。
    """
    adapter = v_asr.require_adapter()
    file_hash = _sha256_file(audio_path)
    cache_id = f"asr_{audio['id']}"
    cached = st.get("alignment_records", cache_id)
    if cached and cached.get("file_hash") == file_hash:
        return {**cached, "reused": True}
    cues = adapter.transcribe(audio_path, script_text)
    if adapter.alignment_source not in v_asr.ALLOWED_ALIGNMENT_SOURCES:
        raise VideoBlocked("ASR_ALIGNMENT_SOURCE_INVALID",
                           f"对齐来源 {adapter.alignment_source} 不在白名单")
    rec = {
        "id": cache_id, "audio_id": audio["id"], "file_hash": file_hash,
        "provider_id": adapter.provider_id, "alignment_source": adapter.alignment_source,
        "simulated": bool(adapter.simulated), "cues": cues, "created_at": now_iso(),
        # 识别文本单独留痕：它回答"音频里说了什么"，用于和稿件对照，
        # 与时间轴是两件事，不能互相替代。
        "transcript": str(getattr(adapter, "last_transcript", "") or ""),
    }
    st.put("alignment_records", cache_id, rec, {"audio_id": audio["id"]})
    return {**rec, "reused": False}


def _run_real_postprocess(task: dict, work: dict, snapshot: dict) -> Dict[str, Any]:
    """真实后期执行。返回记录的状态字段；VideoBlocked/VideoRejected 由外层落库。"""
    audio = _final_audio(work, snapshot["audios"])
    if audio is None:
        raise VideoBlocked("DEPENDENCY_NOT_MET",
                           "真实后期需要已审且用户确认的当前全文音频（voice 与作品一致）")
    video = _original_video(task["work_id"])
    if video is None:
        raise VideoBlocked("MEDIA_NOT_READY",
                           "真实后期需要本作品的非 mock 口播原片（kind=original）")
    script = _selected_script(work, snapshot["script_batch"])
    if script is None:
        raise VideoBlocked("DEPENDENCY_NOT_MET", "真实后期需要当前已选稿件")
    script_text = script.get("text") or ""
    if not script_text.strip():
        raise VideoBlocked("DEPENDENCY_NOT_MET", "已选稿件正文为空")
    # ffmpeg 能力位（缺失即 blocked，不得以"跳过渲染"蒙混）
    v_ff.ffmpeg_bin()

    audio_path = _runtime_path(audio.get("storage_uri") or "")
    video_path = _runtime_path(video.get("storage_uri") or "")
    if not os.path.isfile(audio_path):
        raise VideoBlocked("MEDIA_FILE_MISSING", f"最终音频文件缺失: {audio_path}")
    if not os.path.isfile(video_path):
        raise VideoBlocked("MEDIA_FILE_MISSING", f"口播原片文件缺失: {video_path}")

    # 1) 真实 ASR/对齐（未配置 provider → ASR_NOT_CONFIGURED）
    asr_meta = _asr_cues_cached(audio, audio_path, script_text)

    # 2) 统一时间线：原片 probe 时长为准；本期单段全片（片头偏移 0）
    vinfo = v_ff.probe(video_path)
    v_stream = next(s for s in vinfo["streams"] if s["codec_type"] == "video")
    src_ms = int(round(float(vinfo["format"]["duration"]) * 1000))
    tl = v_tl.EditTimeline.single(src_ms)
    tl.validate()

    # 3) 字幕：映射到终时间轴 + 硬检查（覆盖/越界/重叠/末句截断）
    cues = v_sub.map_cues(asr_meta["cues"], tl)
    checks = v_sub.check_cues(cues, final_duration_ms=tl.final_duration_ms,
                              script_text=script_text)

    # 4) 渲染：两遍响度 + CFR + 烧录 + AI 标识 + 封面
    exec_tag = f"{task['id']}_postprocess"
    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "runtime", "deliverables", task["work_id"])
    os.makedirs(out_dir, exist_ok=True)
    ass_path = os.path.join(out_dir, f"{exec_tag}.ass")
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write(v_sub.build_ass(cues, title=script.get("title") or ""))
    master_path = os.path.join(out_dir, f"{exec_tag}.mp4")
    render_log = v_render.render_master(video_path=video_path, audio_path=audio_path,
                                        out_path=master_path, ass_path=ass_path)
    cover_path = os.path.join(out_dir, f"{exec_tag}_cover.jpg")
    v_render.render_cover(video_path=master_path, out_path=cover_path,
                          title=script.get("title") or "")

    # 5) 验收：规格 probe / 完整解码 / 响度实测 / 黑帧冻结粗筛 / faststart
    verify_log = v_render.verify_master(master_path)

    outputs = []
    for kind, p in (("master", master_path), ("subtitles_ass", ass_path),
                    ("cover", cover_path)):
        outputs.append({"kind": kind, "storage_uri":
                        os.path.relpath(p, os.path.join(os.path.dirname(out_dir), ".."))
                        .replace(os.sep, "/"),
                        "sha256": _sha256_file(p), "bytes": os.path.getsize(p)})

    return {"state": "succeeded", "processing_outcome": "rendered",
            "error": None,
            "timeline": {"source_ms": src_ms, "final_ms": tl.final_duration_ms,
                         "segments": [s.__dict__ for s in tl.segments]},
            "asr": {"provider_id": asr_meta["provider_id"],
                    "alignment_source": asr_meta["alignment_source"],
                    "simulated": asr_meta["simulated"], "reused": asr_meta["reused"],
                    "audio_id": audio["id"],
                    "cue_count": len(asr_meta["cues"])},
            "subtitle_checks": checks,
            "render_log": render_log, "verify_log": verify_log,
            "output_files": outputs}


def run_stage(task: dict, work: dict, stage: str) -> dict:
    if stage not in STAGES:
        raise ValueError(f"Not a postprocess worker stage: {stage}")

    snapshot, digest = _snapshot(task, work, stage)
    execution_id = f"worker_{task['id']}_{stage}_{digest[:20]}"
    existing = st.get("media_jobs", execution_id)
    if existing is not None:
        return existing

    record: Dict[str, Any] = {
        "id": execution_id, "task_id": task["id"], "work_id": task["work_id"],
        "kind": "stage_execution", "stage": stage,
        "executor_kind": "worker", "worker_kind": "postprocess",
        "worker_version": WORKER_VERSION, "mode": task.get("mode"),
        "simulated": task.get("mode") == "mock", "state": "blocked",
        "processing_outcome": "not_run", "input_digest": digest,
        "output_asset_ids": [], "output_files": [], "error": None,
        "created_at": now_iso(),
    }

    if stage == "publish_package":
        # T09 范围：打包在最终质量门禁通过后由 Worker 调内部打包服务。
        record["error"] = {"code": "PUBLISH_PACKAGE_NOT_IMPLEMENTED",
                           "message": "发布打包属 T09；当前不做空壳发布包"}
    elif task.get("mode") == "mock":
        record["error"] = _mock_block(snapshot, work)
    else:
        try:
            result = _run_real_postprocess(task, work, snapshot)
            record.update(result)
        except VideoBlocked as e:
            record["error"] = {"code": e.code, "message": e.message,
                               "detail": e.detail}
        except VideoRejected as e:
            record["error"] = {"code": e.code, "message": e.message,
                               "detail": e.detail}

    st.put("media_jobs", execution_id, record, {"work_id": task["work_id"]})
    return record


def _mock_block(snapshot: dict, work: dict) -> Dict[str, str]:
    """Mock 模式与 T07 前一致：Mock 无真实媒体与后期能力，不能生成交付包。"""
    batch = snapshot["script_batch"]
    audios = snapshot["audios"]
    selected = next((c for c in batch.get("candidates", [])
                     if c.get("id") == work.get("script_version_id")), None)
    if selected is None:
        return {"code": "DEPENDENCY_NOT_MET", "message": "代码后期需要当前已选稿件"}
    if not any(a.get("kind") == "full" and a.get("approved") and a.get("confirmed")
               and a.get("voice_asset_id") == work.get("voice_asset_id")
               for a in audios):
        return {"code": "DEPENDENCY_NOT_MET",
                "message": "代码后期需要已审且用户确认的当前全文音频"}
    return {"code": "MEDIA_NOT_READY",
            "message": "Mock 仅有模拟记录；缺少经审核的真实媒体与后期能力，不能生成交付包"}
