<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from './StatusBadge.vue'
import StageProgress from './StageProgress.vue'

const store = useStudioStore()
const reviewed = ref(false)
watch(() => [store.currentWorkId, store.postprocess?.execution?.id, store.postprocess?.preview_url], () => { reviewed.value = false })
const processing = computed(() => ['queued', 'running', 'waiting_provider', 'retry_wait'].includes(store.postprocess?.task?.state ?? ''))
const preview = computed(() => store.deliveryReady ? store.pkg?.video_url : store.postprocess?.preview_url)
</script>

<template>
  <section id="delivery" class="section">
    <div class="section-head">
      <span class="section-title">3. 生成字幕与成片，确认后下载</span>
      <StatusBadge v-if="store.postprocess?.task" :text="store.postprocess.task.state" />
    </div>
    <div class="panel panel-pad">
      <p v-if="store.postprocess?.error" role="alert" class="step-blocker">{{ store.postprocess.error.message }}</p>
      <template v-if="store.deliveryReady">
        <div class="step-result"><strong>作品已完成：{{ store.pkg?.title }}</strong><a :href="store.pkg?.download_url ?? undefined" class="action-link primary" download>下载完整作品包</a></div>
        <p class="muted">作品包包含视频、字幕、封面和投稿文案。自动发布在开发中，请下载后自行投稿。</p>
      </template>
      <template v-else>
        <p class="muted">先在上方观看并确认口播原片，再生成字幕和成片。最后看一次成片，确认无误后下载。</p>
        <div class="btn-row">
          <button class="primary" :disabled="!store.finalVideo || !!store.busy || processing" @click="store.startPostprocess()">
            {{ processing ? '正在制作成片…' : store.postprocess?.preview_url ? '重新生成字幕与成片' : '生成字幕与成片' }}
          </button>
          <button class="sm" :disabled="!!store.busy" @click="store.guard('刷新成片进度', () => store.refreshPostprocess())">刷新进度</button>
        </div>
        <p v-if="!store.finalVideo" class="faint" style="margin-top: 10px">还缺一条已观看审核并确认的口播原片。</p>
        <p class="faint" style="margin-top: 10px">此步骤复用已确认的人物口播与音频；字幕识别服务需已配置并可连接。</p>
        <StageProgress v-if="store.postprocess?.task" :task="store.postprocess.task" />
      </template>

      <video v-if="preview" :src="preview" controls preload="metadata" class="media-preview" aria-label="成片预览"></video>
      <template v-if="store.postprocess?.ready_for_review && !store.deliveryReady">
        <label class="ack-label"><input v-model="reviewed" type="checkbox" />我已观看这版成片，确认字幕、画面、声音和片尾没有问题</label>
        <button class="primary" :disabled="!reviewed || !!store.busy" @click="store.confirmPostprocess()">确认成片并生成下载包</button>
      </template>
      <div v-if="store.deliveryReady" class="btn-row" style="margin-top: 14px">
        <a v-if="store.pkg?.video_url" :href="store.pkg.video_url" class="action-link" download>单独下载视频</a>
        <a v-if="store.pkg?.cover_url" :href="store.pkg.cover_url" class="action-link" download>下载封面</a>
      </div>
    </div>
  </section>
</template>
