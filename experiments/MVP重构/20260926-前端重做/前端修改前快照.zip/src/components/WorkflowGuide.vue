<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useStudioStore } from '@/stores/studio'

defineEmits<{ create: [] }>()
const store = useStudioStore()
const route = useRoute()
const steps = computed(() => [
  { title: '创建作品', to: '', done: !!store.currentWork, detail: store.currentWork?.name ?? '填写本期主题' },
  { title: '确认人物', to: '/avatar', done: store.identityReady, detail: store.currentIdentity ? `${store.currentIdentity.name}${store.identityReady ? '' : ' · 需完善资料'}` : '选一个已定版人物' },
  { title: '三选一稿件', to: '/script', done: store.scriptReady, detail: store.selectedScript?.title ?? '生成、比较并采用一稿' },
  { title: '试听与确认', to: '/tts', done: !!store.confirmedAudio, detail: store.confirmedAudio ? `已确认 ${(store.confirmedAudio.duration_ms / 1000).toFixed(1)} 秒` : store.currentVoice?.name ?? '选音色并确认全文音频' },
  { title: '合成与下载', to: '/video', done: store.deliveryReady, detail: store.deliveryReady ? '成片已就绪' : store.finalVideo ? '原片已确认，继续制作成片' : '生成口播、审核后下载' },
])
const currentIndex = computed(() => {
  const first = steps.value.findIndex(step => !step.done)
  return first < 0 ? 4 : first
})
const onStepPage = computed(() => route.path === store.nextStep.to)
</script>

<template>
  <section class="workflow" aria-label="创作向导">
    <div class="workflow-heading">
      <div>
        <div class="workflow-title">{{ store.currentWork ? '这一期，做到哪一步了' : '从一个主题，做出一条口播视频' }}</div>
        <p>{{ store.currentWork?.brief.topic || '创建作品后，按下面五步完成。每次选择都会保存，可以随时回来继续。' }}</p>
      </div>
      <span v-if="store.currentWork" class="tag">{{ steps.filter(step => step.done).length }} / 5 已完成</span>
    </div>
    <ol class="workflow-steps" aria-label="创作进度">
      <li v-for="(step, index) in steps" :key="step.title" :class="{ done: step.done, current: index === currentIndex }">
        <component
          :is="step.to && store.currentWork ? 'router-link' : 'button'"
          :to="step.to || undefined"
          :disabled="!step.to && !!store.currentWork"
          :aria-current="index === currentIndex ? 'step' : undefined"
          @click="!store.currentWork && $emit('create')"
        >
          <span class="workflow-number">{{ index + 1 }}</span>
          <span class="workflow-step-copy"><strong>{{ step.title }}</strong><small>{{ step.detail }}</small></span>
          <span class="workflow-state">{{ step.done ? '完成' : index === currentIndex ? '当前' : '待办' }}</span>
        </component>
      </li>
    </ol>
    <div class="workflow-next">
      <div>
        <strong>{{ store.nextStep.title }}</strong>
        <p>{{ store.nextStep.detail }}</p>
      </div>
      <button v-if="!store.currentWork" class="primary" @click="$emit('create')">创建第一个作品</button>
      <router-link v-else-if="!onStepPage" :to="store.nextStep.to" class="action-link primary">{{ store.nextStep.label }}</router-link>
      <span v-else class="workflow-here">在下方完成这一步</span>
    </div>
  </section>
</template>
