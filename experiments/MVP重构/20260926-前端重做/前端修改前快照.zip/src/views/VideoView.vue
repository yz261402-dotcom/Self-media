<script setup lang="ts">
import { computed, onMounted, onUnmounted, reactive, ref, watch } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'
import VideoDelivery from '@/components/VideoDelivery.vue'
import type { CostNotice, GenerationRoute, RouteCapability, VideoAsset } from '@/api/types'

const store = useStudioStore()

/** 提交参数：它们参与调用清单摘要，因此必须由用户显式给出、界面可回溯。 */
const prompt = ref('')
const resolution = ref<'720p' | '1080p'>('1080p')
const showRaw = ref(false)

watch(prompt, (v) => (store.thPrompt = v))
watch(resolution, (v) => (store.thResolution = v))

onMounted(() => {
  prompt.value = store.thPrompt
  resolution.value = store.thResolution
  void refreshPage()
})
let refreshTimer: ReturnType<typeof setInterval> | undefined
let refreshing = false
async function refreshPage() {
  if (!store.currentWorkId || refreshing) return
  const workId = store.currentWorkId
  refreshing = true
  try {
    await store.loadTalkingHead()
    await store.guard('读取成片进度', () => store.refreshPostprocess())
  } finally {
    refreshing = false
    if (store.currentWorkId !== workId) void refreshPage()
  }
}
function scrollToDelivery() { document.getElementById('delivery')?.scrollIntoView({ behavior: 'smooth', block: 'start' }) }
watch(() => store.currentWorkId, () => {
  prompt.value = ''
  resolution.value = '1080p'
  review.videoId = ''
  review.reviewAck = false
  noticeFor.value = null
  void refreshPage()
})
onMounted(() => {
  refreshTimer = setInterval(async () => {
    if (refreshing || store.busy) return
    const state = store.postprocess?.task?.state
    if (state && ['queued', 'running', 'waiting_provider', 'retry_wait'].includes(state)) {
      refreshing = true
      try { await store.guard('更新成片进度', () => store.refreshPostprocess()) }
      finally { refreshing = false }
    }
  }, 3000)
})
onUnmounted(() => clearInterval(refreshTimer))

const routeOptions = computed(() => store.thRoutes?.routes ?? [])
const priceOf = (r: GenerationRoute) => store.thRoutes?.price_snapshots.find((p) => p.route === r) ?? null
const currentPrice = computed(() => priceOf(store.currentRoute))
const currentRoute = computed(() => store.currentRoute)

// ---------- 选项卡：是否加入肢体动作 ----------
// 产品口径：默认不加入 → M2（仅面部表情 + 对口型，本机 GPU，无云单价）；
// 只有用户主动加入肢体动作，才走 OmniHuman（云端 API，按生成秒计费）。
// 界面不暴露"选哪个模型"，只问"要不要肢体动作"：模型是实现细节，
// 成本与能力边界才是用户要权衡的东西。
const ROUTE_PLAIN: GenerationRoute = 'M2'
const ROUTE_BODY: GenerationRoute = 'OMNIHUMAN_1_5'

/** 是否已记录过一次真实选择。与默认指向区分开：默认不是授权。 */
const routeSelected = computed(() => store.routeSelected)
const wantsBodyMotion = computed(() => store.currentRoute === ROUTE_BODY)
const plainOption = computed(() => routeOptions.value.find((r) => r.route === ROUTE_PLAIN) ?? null)
const bodyOption = computed(() => routeOptions.value.find((r) => r.route === ROUTE_BODY) ?? null)

function choosePlain() {
  if (routeSelected.value && store.currentRoute === ROUTE_PLAIN) return
  void store.confirmRoute(ROUTE_PLAIN)
}

function chooseBodyMotion() {
  const r = bodyOption.value
  if (!r) return
  if (routeSelected.value && store.currentRoute === ROUTE_BODY) return
  // 后端硬门禁：高成本路线必须先摆出费用提示并拿到确认，否则选它会被 409 拦下。
  noticeFor.value = r
  noticeAck.value = false
}

/** 身体动作提示词只对云路线有意义：M2 走已获准的动作参考，没有自由文本入口。 */
const promptApplies = computed(() => wantsBodyMotion.value)

const promptLen = computed(() => prompt.value.length)
const promptLimit = computed(() => {
  const d = store.currentRouteSpec?.declared as Record<string, number> | undefined
  return d?.prompt_max_chars ?? 300
})
const promptOver = computed(() => promptLen.value > promptLimit.value)

// ---------- 加入肢体动作的费用提示 ----------
// 后端对 OmniHuman 有硬门禁：没确认费用提示就选它会被 409 拦下。
// 这里的弹窗是"把提示摆到用户面前"，不是门禁本身——门禁在服务端。
const noticeFor = ref<RouteCapability | null>(null)
const noticeAck = ref(false)

const notice = computed<CostNotice | null>(() => noticeFor.value?.cost_notice ?? null)
const noticeAmountKnown = computed(() => notice.value?.amount_known === true)

async function acceptNotice() {
  const r = noticeFor.value
  if (!r || !noticeAck.value) return
  await store.confirmRoute(r.route, true)
  noticeFor.value = null
  noticeAck.value = false
}

const audioSeconds = computed(() => ((store.thPreflight?.audio_duration_ms ?? 0) / 1000))
const needsSegments = computed(() => audioSeconds.value >= 60)
const yuan = (fen: number) => (fen / 100).toFixed(2)

/** 底片源图：默认沿用作品绑定；显式选了才覆盖。
 *  「已审」只筛掉明显不能用的，真正的判定由服务端给（见 admitVariant）。 */
const work = computed(() => store.currentWork)
const plateVariantId = ref('')
const approvedVariants = computed(() => store.variants.filter((v) => v.approval_state === 'approved'))

const estimate = computed(() => store.thCost?.estimate ?? null)
const confirmedCost = computed(() => store.thConfirmedCost)

/** 动作要求与构图要匹配：要求手势时，必须能看到手臂且能活动。 */
const gestureRequested = computed(() => /手势|比划|招手|指|挥|拿|举|点赞/.test(prompt.value))
const motionWarning = computed(() =>
  gestureRequested.value && !store.currentRouteSpec?.requires_motion_plate
    ? '你要求了手势/动作。云路线不承诺任意动作，且必须先确认人物构图里手臂与手可见、有活动空间；生成后需核肩臂、身体与手势的自然度和指令遵循程度。'
    : '',
)

// ---------- 原片人工审核表单 ----------
// 本项目没有视频理解能力：四项结论只能由人给出，且每条通过都要绑定引用。
const DIMENSIONS = [
  { key: 'lip_sync', label: '口型/音素同步' },
  { key: 'identity', label: '人物身份保持' },
  { key: 'body_motion', label: '身体动作与颈肩构图' },
  { key: 'expression', label: '眨眼/眉眼/表情自然度' },
] as const

const review = reactive({
  videoId: '',
  dimensions: {
    lip_sync: 'not_run',
    identity: 'not_run',
    body_motion: 'not_run',
    expression: 'not_run',
  } as Record<string, string>,
  refAsset: 'ref_local',
  refStart: 0,
  refEnd: 4000,
  reviewAck: false,
  trackOffset: 0,
  trackEvidence: '解码为 24kHz 单声道后取最佳偏移',
})

function openReview(v: VideoAsset) {
  review.videoId = v.id
  review.dimensions = { lip_sync: 'not_run', identity: 'not_run', body_motion: 'not_run', expression: 'not_run' }
  review.reviewAck = false
  review.refAsset = v.id
  review.refStart = 0
  review.refEnd = Math.min(v.duration_ms, 4000)
}

const allDimensionsDecided = computed(() =>
  DIMENSIONS.every((d) => ['pass', 'fail'].includes(review.dimensions[d.key])),
)
const allDimensionsPass = computed(() => DIMENSIONS.every((d) => review.dimensions[d.key] === 'pass'))

async function submitReview(outcome: 'pass' | 'fail') {
  const refs: Record<string, { asset_id: string; start_ms: number; end_ms: number }> = {}
  for (const d of DIMENSIONS) {
    // 每条结论都指向同一段"我看的那几秒"：没有引用的通过等于没有通过。
    refs[d.key] = { asset_id: review.refAsset, start_ms: review.refStart, end_ms: review.refEnd }
  }
  await store.reviewVideo(review.videoId, { ...review.dimensions }, refs, outcome, '界面人工标注')
}

async function submitTrackCheck(v: VideoAsset) {
  if (!v.audio_asset_id) {
    store.setNotice('danger', '该视频未绑定音频，无法核对音轨保持')
    return
  }
  await store.recordAudioTrackCheck(v.id, {
    audio_asset_id: v.audio_asset_id,
    measured_offset_ms: review.trackOffset,
    evidence: review.trackEvidence,
  })
}

function gateOf(id: string) {
  return store.videoGates[id]?.gate ?? null
}
const videos = computed(() => store.videos)
const originals = computed(() => videos.value.filter((v) => v.kind === 'original'))
const plates = computed(() => videos.value.filter((v) => v.kind === 'plate'))
</script>

<template>
  <div>
    <div class="page-head">
      <h1>视频合成</h1>
      <button class="sm" :disabled="!!store.busy" @click="refreshPage">刷新视频状态</button>
    </div>
    <div class="page-sub">
      选择生成方式 → 生成并观看口播原片 → 制作字幕成片 → 确认并下载
    </div>

    <div v-if="!store.confirmedAudio" class="step-blocker">还缺已确认的全文音频。<router-link to="/tts" class="action-link">返回试听与确认</router-link></div>
    <div v-else class="step-result"><div><strong>已确认全文音频，继续检查视频生成条件</strong><p class="muted">{{ store.currentIdentity?.name }} · {{ store.currentVoice?.name }} · {{ (store.confirmedAudio.duration_ms / 1000).toFixed(1) }} 秒</p></div><button @click="scrollToDelivery">查看成片与下载</button></div>

    <!-- 1) 适配器与能力：声明与实测分列 -->
    <details class="advanced">
      <summary>服务连接与路线能力（排查时展开）</summary>
      <div class="section-head">
        <span class="section-title">路线能力与适配器</span>
        <span class="section-note">声明口径 ≠ 本项目实测</span>
      </div>
      <div class="panel">
        <div class="panel-head">
          <span style="font-weight: 600; font-size: 14.5px">适配器状态</span>
          <div class="topbar-spacer"></div>
          <span v-if="store.thAdapters" class="faint" style="font-size: 12.5px">
            凭据存在 ≠ 可调用
          </span>
        </div>
        <div v-if="store.thAdapters" class="panel-pad">
          <div v-for="(a, key) in store.thAdapters" :key="key" class="check-row">
            <StatusBadge :text="a.state" />
            <span class="check-label">{{ a.provider }} · {{ a.model }}</span>
            <span class="check-hint">{{ a.detail }}</span>
          </div>
        </div>
        <div v-else class="empty">尚未取得适配器状态。</div>
      </div>
    </details>

    <!-- 2) 前置检查 -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">提交前置检查</span>
        <div class="topbar-spacer"></div>
        <StatusBadge :text="store.thReady ? 'pass' : 'blocked'" />
      </div>
      <div class="panel">
        <template v-if="store.thBlockers.length">
          <div class="panel-pad">
            <Note
              v-for="b in store.thBlockers"
              :key="b.code"
              :kind="b.kind === 'rejected' ? 'danger' : 'warn'"
              :label="b.kind === 'rejected' ? '需要改输入' : '需要等条件'"
            >
              <span class="mono">{{ b.code }}</span> — {{ b.message }}
            </Note>
          </div>
        </template>
        <div v-else-if="store.thReady" class="panel-pad">
          <div class="check-row">
            <span class="check-mark on">
              <svg viewBox="0 0 10 10" fill="none">
                <path d="M1.5 5.2 4 7.5 8.5 2.5" stroke="#ffffff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" />
              </svg>
            </span>
            <span class="check-label">人物、稿件、最终音频均已就绪</span>
            <span class="check-hint">
              音频 {{ audioSeconds.toFixed(1) }}s · 动作意图
              {{ store.thPreflight?.motion_intent.state ?? '—' }}
            </span>
          </div>
        </div>
        <div v-else class="panel-pad faint">正在读取前置条件。尚未取得通过结论。</div>
      </div>
    </div>

    <!-- 3) 是否加入肢体动作（决定走哪条口播路线） -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">1. 选择生成方式与费用</span>
        <span class="section-note">默认不加入：只做面部表情与对口型</span>
      </div>
      <div class="panel panel-pad">
        <div class="seg">
          <button
            class="seg-item"
            :class="{ on: routeSelected && !wantsBodyMotion }"
            :disabled="store.busy !== ''"
            @click="choosePlain()"
          >
            <div class="seg-head">
              <span class="seg-name">不加入肢体动作</span>
              <div class="topbar-spacer"></div>
              <span class="tier tier-low">默认</span>
            </div>
            <div class="seg-desc">只有面部表情 + 对口型，沿用该人物已获准的动作</div>
            <div class="seg-desc faint">费用：{{ plainOption?.cost_summary ?? '—' }}</div>
          </button>

          <button
            class="seg-item"
            :class="{ on: routeSelected && wantsBodyMotion }"
            :disabled="store.busy !== ''"
            @click="chooseBodyMotion()"
          >
            <div class="seg-head">
              <span class="seg-name">加入肢体动作</span>
              <div class="topbar-spacer"></div>
              <span class="tier tier-high">需先确认费用</span>
            </div>
            <div class="seg-desc">画面含头肩以外的肢体动作，由模型自由生成</div>
            <div class="seg-desc faint">费用：{{ bodyOption?.cost_summary ?? '—' }}</div>
          </button>
        </div>

        <Note v-if="!routeSelected" kind="warn" label="尚未选择" style="margin-top: 14px">
          上方「不加入肢体动作」是界面的<strong>默认指向</strong>，不是授权：点一下它才会记录你的选择。
          系统不替你选——后端也明确不接受把默认值当授权。
        </Note>

        <!-- 选中路线的能力披露：声明与实测分列，未决问题照实列出 -->
        <div v-if="store.currentRouteSpec" class="route-detail">
          <div class="sub">
            {{ routeSelected ? '当前路线' : '默认指向的路线（尚未选择）' }}：{{ store.currentRouteSpec.label }}
            <StatusBadge :text="store.currentRouteSpec.verified_state" style="margin-left: 8px" />
          </div>
          <div class="faint" style="font-size: 12.5px; margin-top: 6px">
            {{ store.currentRouteSpec.stage_count }} 阶段 · 需要底片：{{
              store.currentRouteSpec.requires_motion_plate ? '是' : '否'
            }} · {{ store.currentRouteSpec.consumes.join('、') }}
          </div>
          <div class="faint" style="font-size: 12.5px; margin-top: 4px">
            费用：{{ store.currentRouteSpec.cost_summary }}
          </div>
          <div class="faint" style="font-size: 12.5px; margin-top: 4px">
            肢体动作：{{ store.currentRouteSpec.body_motion.supported ? '有' : '无' }} ——
            {{ store.currentRouteSpec.body_motion.scope }}
          </div>
          <div class="faint" style="font-size: 12.5px; margin-top: 4px">
            未决问题：{{ store.currentRouteSpec.open_questions.join('、') || '无' }}
          </div>
        </div>

        <div class="divider" style="margin: 18px 0"></div>

        <div class="grid-2">
          <label>
            <div class="sub">分辨率</div>
            <select v-model="resolution" style="width: 100%">
              <option value="720p">720p</option>
              <option value="1080p">1080p</option>
            </select>
          </label>
          <div>
            <div class="sub">音频与分段</div>
            <div class="faint" style="font-size: 13px; line-height: 1.7">
              最终音频 {{ audioSeconds.toFixed(1) }}s
              <template v-if="needsSegments">
                · 达到单次调用上限，须按「同一音轨的句边界」分段，并保留全局偏移
              </template>
              <template v-else>· 单次调用即可，无需分段</template>
            </div>
          </div>
        </div>

        <div style="margin-top: 16px" v-if="promptApplies">
          <div class="sub">
            身体动作提示词（可选，≤ {{ promptLimit }} 字符）
            <span class="faint mono" style="margin-left: 8px">{{ promptLen }} / {{ promptLimit }}</span>
          </div>
          <textarea
            v-model="prompt"
            rows="3"
            placeholder="例如：自然讲述，少量点头，偶尔用手势强调重点"
            style="width: 100%; resize: vertical"
          ></textarea>
          <div class="faint" style="font-size: 12.5px; margin-top: 6px">
            动作由模型自由生成，不是逐帧指定：写了也不承诺一定照做，生成后需人工核对肩臂与手势。
          </div>
          <div v-if="promptOver" class="faint" style="color: var(--red); font-size: 12.5px; margin-top: 6px">
            超出声明上限：提交会被拒收（这不是"可能"，是确定被拦）。
          </div>
          <div v-if="motionWarning" class="faint" style="font-size: 12.5px; margin-top: 6px">
            {{ motionWarning }}
          </div>
        </div>
        <div v-else class="faint" style="font-size: 12.5px; margin-top: 16px">
          未加入肢体动作，就没有可填的动作提示词：画面沿用该人物下已获准的动作参考，
          换动作等于换一次人工选择，不是在这里输一句话。
        </div>

        <div v-if="estimate" class="divider" style="margin: 18px 0"></div>

        <template v-if="estimate">
          <div class="row">
            <div>
              <div class="sub">估价（不是账单）</div>
              <span class="num" style="font-size: 19px; font-weight: 600">¥{{ yuan(estimate.estimated_fen) }}</span>
              <span class="faint num" style="font-size: 13px; margin-left: 8px">
                上限 ¥{{ yuan(estimate.ceiling_fen) }}
              </span>
              <StatusBadge
                v-if="currentPrice"
                :text="currentPrice.billing_verified ? 'verified' : 'unverified'"
                style="margin-left: 8px"
              />
            </div>
            <div class="topbar-spacer"></div>
            <div class="btn-row">
              <button class="primary" :disabled="store.busy !== '' || promptOver" @click="store.confirmTalkingHeadCost(currentRoute)">
                确认调用清单与金额
              </button>
            </div>
          </div>
          <div class="faint" style="font-size: 12.5px; margin-top: 8px">{{ estimate.price_basis }}</div>
          <div class="faint" style="font-size: 12.5px; margin-top: 4px">{{ estimate.note }}</div>
          <div v-if="currentPrice" class="faint" style="font-size: 12.5px; margin-top: 4px">
            {{ currentPrice.rounding_note }}；{{ currentPrice.minimum_note }}；{{ currentPrice.failure_billing_note }}
          </div>
        </template>

        <div v-if="confirmedCost" class="divider" style="margin: 18px 0"></div>
        <template v-if="confirmedCost">
          <div class="sub">已确认的调用清单</div>
          <div class="faint" style="font-size: 12.5px; line-height: 1.8">
            段数 {{ confirmedCost.segment_count }} · 分辨率 {{ confirmedCost.resolution }} ·
            估价 ¥{{ yuan(confirmedCost.estimated_fen) }} / 上限 ¥{{ yuan(confirmedCost.ceiling_fen) }}<br />
            摘要 <span class="mono">{{ confirmedCost.request_digest }}</span><br />
            {{ confirmedCost.expiry_note ?? '清单变化即失效' }}<br />
            付费授权：<b>{{ confirmedCost.authorizes_payment ? '已授权' : '未授权' }}</b>
            —— 清单确认不等于付费授权。
          </div>
          <Note v-if="store.thCost && !store.thCost.billable_allowed" kind="warn" label="预算未授权">
            当前预算（单任务 {{ yuan(store.thCost.budget.per_task_limit_fen) }} 元、
            可计费提交 {{ store.thCost.budget.max_billable_submissions }} 次）不允许新增计费任务。
            报价确认不会放宽预算；超额须显式调整预算，而不是重复确认。
          </Note>
        </template>
      </div>
    </div>

    <!-- 4) 提交与运行记录 -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">提交与运行记录</span>
        <span class="section-note">失败与原片保留，不自动回退到其它路线</span>
      </div>
      <div class="panel">
        <div class="panel-pad">
          <div class="btn-row">
            <button :disabled="!store.thReady || !!store.busy" @click="store.submitTalkingHead(true)">检查生成条件（不生成视频）</button>
            <button class="primary" :disabled="!store.thReady || !confirmedCost || promptOver || !!store.busy || (wantsBodyMotion && !store.thCost?.billable_allowed)" @click="store.submitTalkingHead(false)">
              生成口播（真实调用{{ estimate ? ` · 估价 ¥${yuan(estimate.estimated_fen)}` : '' }}）
            </button>
          </div>
          <div v-if="!store.thReady" class="faint" style="font-size: 12.5px; margin-top: 10px">
            前置未满足，提交会被阻断。
          </div>
          <p v-if="!confirmedCost" class="faint" style="margin-top: 10px">先在上方确认本次调用清单与金额，再生成真实视频。</p>
          <Note kind="warn" label="真实生成与检查的区别">
            「检查生成条件」只校验，不会生成视频。「生成口播」才会向当前服务提交真实任务。
            重生成可能再次收费；取整/最低消费/失败扣费尚未核验，实际费用可能高于估价。
            外部作业受理后需按原任务号查询；结果未知时先核对，不盲目重提。
          </Note>
        </div>

        <template v-if="store.thSubmissions?.runs.length">
          <div class="divider"></div>
          <div class="stage-list">
            <div v-for="r in store.thSubmissions.runs" :key="r.id" class="stage-row">
              <StatusBadge :text="r.state" />
              <span class="mono faint">{{ r.id.slice(-8) }}</span>
              <span style="flex: 1">{{ r.model }}</span>
              <StatusBadge v-if="r.is_mock" text="mock" />
              <button
                v-if="r.state === 'unknown'"
                class="ghost sm"
                :disabled="store.busy !== ''"
                @click="store.settleRun(r.id, '用户核对后登记：以远端任务号查询结果为准')"
              >
                核对结果
              </button>
            </div>
          </div>
        </template>
        <div v-else class="empty">尚无提交记录。</div>

        <div v-if="store.thSubmissions" class="panel-pad faint" style="font-size: 12.5px">
          {{ store.thSubmissions.note }}
        </div>
      </div>
    </div>

    <!-- 5) 分段计划 -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">分段计划</span>
        <span class="section-note">分段只能来自同一音轨的句边界时间戳</span>
      </div>
      <div class="panel">
        <div class="panel-pad">
          <div class="btn-row">
            <button class="sm" :disabled="store.busy !== '' || !store.thReady" @click="store.createSegmentPlan()">
              建立/刷新分段计划
            </button>
            <span class="faint" style="font-size: 12.5px">
              禁止加速、截字或用字符平均切分
            </span>
          </div>
        </div>
        <template v-if="store.thSegments?.planned && store.thSegments.segments?.length">
          <div class="divider"></div>
          <table>
            <thead>
              <tr><th class="tight">#</th><th>起止</th><th>时长</th><th>全局偏移</th><th>单次调用</th></tr>
            </thead>
            <tbody>
              <tr v-for="s in store.thSegments.segments" :key="s.segment_id">
                <td class="tight num">{{ s.index + 1 }}</td>
                <td class="num">{{ (s.start_ms / 1000).toFixed(2) }}s – {{ (s.end_ms / 1000).toFixed(2) }}s</td>
                <td class="num">{{ (s.duration_ms / 1000).toFixed(2) }}s</td>
                <td class="num faint">{{ s.global_offset_ms }} ms</td>
                <td>
                  <StatusBadge :text="s.over_limit ? 'fail' : 'pass'" />
                </td>
              </tr>
            </tbody>
          </table>
        </template>
        <div v-else class="empty">
          {{ store.thSegments?.reason ?? '尚未建立分段计划。' }}
        </div>
      </div>
    </div>

    <!-- 6) 动态底片（M2 第一阶段） -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">动态底片</span>
        <span class="section-note">M2 专用：底片不是交付原片</span>
      </div>
      <div class="panel">
        <div class="panel-pad">
          <div class="grid-2" style="gap: 10px">
            <label class="field">
              <span>底片源图（已审变体）</span>
              <select v-model="plateVariantId">
                <option value="">沿用作品当前绑定（{{ work?.variant_id || '未绑定' }}）</option>
                <option v-for="v in approvedVariants" :key="v.id" :value="v.id">
                  {{ v.preview_label || v.id }} · {{ v.approval_state }}
                </option>
              </select>
            </label>
            <div class="field">
              <span>准入判定</span>
              <div class="muted" style="font-size: 12.5px; padding-top: 6px">
                <template v-if="store.variantGate">
                  <StatusBadge :text="store.variantGate.ok ? 'pass' : 'fail'" />
                  <span style="margin-left: 6px">{{ store.variantGate.reasons.join('；') || '无阻断项' }}</span>
                </template>
                <template v-else>未判定——点右侧按钮按服务端口径逐条核对</template>
              </div>
            </div>
          </div>
          <div class="btn-row" style="margin-top: 10px">
            <button class="sm" :disabled="store.busy !== ''" @click="store.createPlate(audioSeconds || 9, plateVariantId || undefined)">
              生成底片（{{ (audioSeconds || 9).toFixed(1) }}s）
            </button>
            <button
              class="sm"
              :disabled="store.busy !== '' || !(plateVariantId || work?.variant_id)"
              @click="store.admitVariant(plateVariantId || work?.variant_id || '')"
            >
              核对变体准入
            </button>
          </div>
          <Note label="源图不是随便挑的">
            M2 底片必须以**本作品选定人物的已审变体**为源图：种类不符（例如指向一张 hero）、
            资产未定版、画风未声明、Mock 后代，任一命中都会被拒。上面那个「核对变体准入」
            就是把服务端的逐条原因取回来，界面不自己另编一套说法。
          </Note>
          <div class="faint" style="font-size: 12.5px; margin-top: 6px">
            底片必须与最终音频核对时长；短了不得加速补齐，长了记作编辑决定
          </div>
        </div>
        <template v-if="plates.length">
          <div class="divider"></div>
          <div class="stage-list">
            <div v-for="p in plates" :key="p.id" class="stage-row">
              <video v-if="p.url && !p.is_mock" :src="p.url" controls preload="metadata" style="width: 180px; max-height: 220px" aria-label="动作底片预览"></video>
              <StatusBadge :text="p.approval_state" />
              <StatusBadge v-if="p.is_mock" text="mock" />
              <span class="mono faint">{{ p.id.slice(-8) }}</span>
              <span style="flex: 1">{{ (p.duration_ms / 1000).toFixed(2) }}s</span>
              <button class="ghost sm" :disabled="store.busy !== ''" @click="store.reviewPlate(p.id, 'pass', '界面人工确认：身份未漂移')">
                身份未漂移
              </button>
              <button class="danger sm" :disabled="store.busy !== ''" @click="store.reviewPlate(p.id, 'fail', '界面人工判定：身份漂移')">
                身份漂移
              </button>
            </div>
          </div>
        </template>
        <div v-else class="empty">尚无底片。</div>
      </div>
    </div>

    <!-- 7) 原片门禁：画面与音轨分别记录 -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">2. 观看口播原片，逐项审核并确认</span>
        <div class="topbar-spacer"></div>
        <StatusBadge :text="store.thGate?.original_confirmed ? 'pass' : 'not_run'" />
      </div>
      <div class="panel">
        <div v-if="store.thGate" class="panel-pad faint" style="font-size: 12.5px">
          {{ store.thGate.note }}（候选原片 {{ store.thGate.original_count }} 条）
        </div>

        <template v-for="v in originals" :key="v.id">
          <div class="divider"></div>
          <div class="panel-pad">
            <video v-if="v.url && !v.is_mock" :src="v.url" controls preload="metadata" class="media-preview" :aria-label="`口播原片 ${v.id}`"></video>
            <p v-else class="faint">当前原片没有可播放地址，请先检查文件是否可用，不能据此完成观看确认。</p>
            <div class="row">
              <span class="mono">{{ v.id.slice(-8) }}</span>
              <StatusBadge :text="v.approval_state" />
              <StatusBadge v-if="v.is_mock" text="mock" />
              <StatusBadge v-if="v.confirmed" text="approved" />
              <div class="topbar-spacer"></div>
              <span class="faint num" style="font-size: 12.5px">
                {{ (v.duration_ms / 1000).toFixed(2) }}s · {{ v.width }}×{{ v.height }} · {{ v.fps }}fps
              </span>
            </div>

            <div v-if="v.hard_failures.length" style="margin-top: 10px">
              <Note v-for="f in v.hard_failures" :key="f.code" kind="danger" :label="f.code">
                {{ f.message }}
              </Note>
            </div>

            <template v-if="gateOf(v.id)">
              <div class="row" style="margin-top: 12px">
                <span class="sub" style="margin: 0">门禁</span>
                <StatusBadge :text="gateOf(v.id)?.outcome ?? 'not_run'" />
                <span class="faint" style="font-size: 12.5px">
                  画面审核 {{ gateOf(v.id)?.review_state }} · 音轨保持 {{ gateOf(v.id)?.audio_track_state }}
                </span>
              </div>
              <div
                v-if="(gateOf(v.id)?.reasons ?? []).length"
                class="faint"
                style="font-size: 12.5px; margin-top: 6px; line-height: 1.7"
              >
                未通过原因：{{ (gateOf(v.id)?.reasons ?? []).join('；') }}
              </div>
            </template>

            <template v-if="review.videoId !== v.id">
              <div class="btn-row" style="margin-top: 12px">
                <button class="primary sm" :disabled="store.busy !== '' || !v.url || v.is_mock" @click="openReview(v)">观看后审核这条原片</button>
                <button class="sm" :disabled="store.busy !== ''" @click="submitTrackCheck(v)">
                  核对音轨保持（偏移 {{ review.trackOffset }}ms）
                </button>
              </div>
            </template>

            <div v-else class="review-box">
              <div class="sub">人工审核：口型 / 身份 / 身体 / 表情（本项目没有视频理解能力，结论只能由人给出）</div>
              <div v-for="d in DIMENSIONS" :key="d.key" class="check-row">
                <span class="check-label">{{ d.label }}</span>
                <select v-model="review.dimensions[d.key]" style="width: 130px">
                  <option value="not_run">未执行</option>
                  <option value="pass">通过</option>
                  <option value="fail">未通过</option>
                </select>
              </div>
              <div class="grid-2" style="margin-top: 12px">
                <label>
                  <div class="sub">引用对象</div>
                  <input v-model="review.refAsset" style="width: 100%" />
                </label>
                <label>
                  <div class="sub">引用区间（毫秒）</div>
                  <div class="row">
                    <input v-model.number="review.refStart" type="number" style="width: 48%" />
                    <input v-model.number="review.refEnd" type="number" style="width: 48%" />
                  </div>
                </label>
              </div>
              <div class="faint" style="font-size: 12.5px; margin-top: 8px">
                每条结论都要绑定对象与毫秒区间：没有引用的通过等于没有通过。
                口型不能用波形相关或 RMS 代替。
              </div>
              <div class="btn-row" style="margin-top: 12px">
                <button
                  class="primary"
                  :disabled="store.busy !== '' || !allDimensionsDecided"
                  @click="submitReview(allDimensionsPass ? 'pass' : 'fail')"
                >
                  登记审核结论
                </button>
                <button class="ghost sm" @click="review.videoId = ''">收起</button>
              </div>
              <div class="divider" style="margin: 16px 0"></div>
              <div class="sub">确认最终原片</div>
              <label class="faint" style="font-size: 13px; display: flex; align-items: center; gap: 8px">
                <input v-model="review.reviewAck" type="checkbox" />
                我已逐帧/慢放观看这条原片，确认口型、身份、表情与穿帮情况
              </label>
              <div class="btn-row" style="margin-top: 10px">
                <button
                  class="primary"
                  :disabled="store.busy !== '' || !review.reviewAck || !v.url || v.is_mock || gateOf(v.id)?.outcome !== 'pass'"
                  @click="store.confirmFinalVideo(v.id, review.reviewAck, '界面确认')"
                >
                  确认这条为最终原片
                </button>
                <span class="faint" style="font-size: 12.5px">
                  底片与占位产物不可确认；确认会替换此前已确认的原片
                </span>
              </div>
            </div>
          </div>
        </template>

        <div v-if="!originals.length" class="empty">
          尚无口播原片。占位产物不会出现在这里——它不进入审核与后期。
        </div>
      </div>
    </div>

    <VideoDelivery />

    <!-- 8) 队列 -->
    <details class="advanced">
      <summary>运行队列与诊断信息</summary>
      <div class="section-head">
        <span class="section-title">重型作业队列</span>
        <div class="topbar-spacer"></div>
        <StatusBadge :text="store.thQueue?.serialized ? 'pass' : 'fail'" />
      </div>
      <div class="panel">
        <div v-if="store.thQueue" class="panel-pad">
          <div class="row">
            <span v-for="(n, k) in store.thQueue.counts" :key="k" class="faint num" style="font-size: 12.5px">
              {{ k }}: <b>{{ n }}</b>
            </span>
          </div>
          <div class="faint" style="font-size: 12.5px; margin-top: 8px">{{ store.thQueue.note }}</div>
          <div class="faint" style="font-size: 12.5px; margin-top: 4px">
            GPU 忙只是排队，不判失败；排队期不占用租约。
          </div>
        </div>
        <div v-else class="empty">尚未取得队列状态。</div>
      </div>
    </details>

    <!-- 原始响应：排查用，默认收起 -->
    <div class="section">
      <div class="section-head">
        <span class="section-title">原始视图</span>
        <span class="section-note">排查字段口径用</span>
        <div class="topbar-spacer"></div>
        <button class="ghost sm" @click="showRaw = !showRaw">{{ showRaw ? '收起' : '展开' }}</button>
      </div>
      <div v-if="showRaw" class="panel">
        <pre class="mono" style="padding: 16px 20px; overflow: auto; max-height: 420px; margin: 0">{{ JSON.stringify({
          preflight: store.thPreflight,
          routes: store.thRoutes,
          cost: store.thCost,
          segments: store.thSegments,
          plate: store.thPlate,
          submissions: store.thSubmissions,
          gate: store.thGate,
          videos: store.videos,
        }, null, 2) }}</pre>
      </div>
    </div>
<!-- 高成本路线的费用提示：确认前不写入路线选择 -->
    <div v-if="noticeFor && notice" class="modal-mask" @click.self="noticeFor = null">
    <div class="modal">
      <div class="modal-head">
        <span class="sub" style="margin: 0">加入肢体动作 · {{ notice.cost_tier_label }}</span>
        <div class="topbar-spacer"></div>
        <span class="tier tier-high">{{ noticeFor.label }}</span>
      </div>

      <div class="faint" style="font-size: 13px; line-height: 1.7; margin-top: 10px">
        加入肢体动作将改为调用云端 API（OmniHuman），<strong>成本会大幅高于默认路线</strong>：
        默认路线只占本机 GPU 卡时、没有云单价，而这条按生成秒计费。
        确认后你才能填写身体动作提示词。
      </div>

      <div class="modal-amount">
        <template v-if="noticeAmountKnown">
          <span class="num" style="font-size: 24px; font-weight: 600">
            ¥{{ yuan(notice.estimated_fen ?? 0) }}
          </span>
          <span class="faint num" style="margin-left: 8px; font-size: 13px">
            上限 ¥{{ yuan(notice.ceiling_fen ?? 0) }}（{{ notice.audio_seconds }}s，向上取整为
            {{ notice.billing_seconds }} 计费秒）
          </span>
        </template>
        <template v-else>
          <span class="faint" style="font-size: 13.5px">{{ notice.amount_pending_reason }}</span>
        </template>
      </div>

      <div class="faint" style="font-size: 12.5px; margin-top: 8px">
        计费口径：{{ notice.unit_text }}
      </div>
      <div v-if="notice.price_basis" class="faint" style="font-size: 12.5px; margin-top: 4px">
        {{ notice.price_basis }}
      </div>

      <div class="sub" style="margin-top: 14px">你需要知道的风险</div>
      <ul class="risk-list">
        <li v-for="risk in notice.risks" :key="risk">{{ risk }}</li>
      </ul>
      <div class="faint" style="font-size: 12.5px">
        不含：{{ notice.excluded.join('、') }}
      </div>

      <div class="divider" style="margin: 14px 0"></div>
      <label class="faint" style="font-size: 13px; display: flex; align-items: flex-start; gap: 8px">
        <input v-model="noticeAck" type="checkbox" style="margin-top: 3px" />
        我已阅读并确认上述费用提示：这条路线按生成秒计费，金额可能高于估价，
        效果不满意或重做仍会收费。
      </label>

      <div class="btn-row" style="margin-top: 14px">
        <button class="primary" :disabled="!noticeAck || store.busy !== ''" @click="acceptNotice()">
          确认费用并加入肢体动作
        </button>
        <button class="ghost sm" @click="noticeFor = null">取消</button>
        <div class="topbar-spacer"></div>
        <span class="faint" style="font-size: 12.5px">
          提示版本 {{ notice.notice_version }}
        </span>
      </div>
      <div class="faint" style="font-size: 12.5px; margin-top: 8px">
        这里确认的是"要不要走这条付费路线"；提交前还要再确认一次本次的调用清单与金额。
      </div>
    </div>
    </div>
  </div>
</template>

<style scoped>
.tier {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
}
.tier-low {
  background: #e8f3ec;
  color: #1f7a4d;
  border: 1px solid #bfe0cd;
}
.tier-high {
  background: #fdeee9;
  color: #b4462a;
  border: 1px solid #f3cfc3;
}
.modal-mask {
  position: fixed;
  inset: 0;
  background: rgba(20, 28, 45, 0.32);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 60;
}
.modal {
  width: min(560px, calc(100vw - 48px));
  max-height: calc(100vh - 80px);
  overflow: auto;
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: var(--r-sm);
  box-shadow: var(--shadow-3);
  padding: 20px 22px;
}
.modal-head {
  display: flex;
  align-items: center;
  gap: 10px;
}
.modal-amount {
  margin-top: 12px;
  padding: 14px 16px;
  border-radius: var(--r-xs);
  background: var(--panel-2);
}
.risk-list {
  margin: 8px 0 0;
  padding-left: 20px;
  font-size: 13px;
  line-height: 1.8;
  color: var(--fg-2);
}
.review-box {
  margin-top: 14px;
  padding: 16px 18px;
  border: 1px solid var(--line);
  border-radius: var(--r-sm);
  background: var(--bg-2);
}

/* ---------- 是否加入肢体动作：分段选项卡 ---------- */
.seg {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}
.seg-item {
  display: block;
  width: 100%;
  text-align: left;
  padding: 14px 16px;
  border: 1px solid var(--line);
  border-radius: var(--r-sm);
  background: var(--panel);
  cursor: pointer;
  transition: border-color 0.15s, background 0.15s;
}
.seg-item:hover:not(:disabled) { border-color: var(--line-2); }
.seg-item.on { border-color: var(--blue); background: var(--blue-wash); }
.seg-item:disabled { cursor: not-allowed; opacity: 0.6; }
.seg-head { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; }
.seg-name { font-size: 14.5px; font-weight: 600; }
.seg-desc { font-size: 13px; color: var(--fg-2); line-height: 1.6; }

/* 选中路线的能力披露：声明/实测/未决问题照实列出，不藏 */
.route-detail {
  margin-top: 14px;
  padding: 14px 16px;
  border: 1px dashed var(--line);
  border-radius: var(--r-sm);
  background: var(--bg-2);
}
@media (max-width: 720px) {
  .seg { grid-template-columns: 1fr; }
}
</style>
