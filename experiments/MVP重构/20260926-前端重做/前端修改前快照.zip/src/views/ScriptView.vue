<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from '@/components/StatusBadge.vue'
import StageProgress from '@/components/StageProgress.vue'
import Note from '@/components/Note.vue'
import type { ScriptVersion } from '@/api/types'

const store = useStudioStore()

const topic = ref('')
const materialInput = ref('')
const materialTouched = ref(false)
const editing = ref<{ id: string; text: string } | null>(null)
const expanded = ref<string | null>(null)

watch(() => store.currentWorkId, () => {
  topic.value = store.currentWork?.brief.topic ?? ''
  materialTouched.value = false
  materialInput.value = (store.currentWork?.brief.materials ?? []).map(m => m.text).join('\n')
  editing.value = null
  expanded.value = null
}, { immediate: true })

/** 资料以作品 brief 为准回填：刷新后也要能看到"当时给的是哪几条"。 */
watch(
  () => store.currentWork?.brief.materials,
  (mats) => {
    if (materialTouched.value) return
    materialInput.value = (mats ?? []).map((m) => m.text).join('\n')
  },
  { immediate: true, deep: true },
)

const candidates = computed(() => store.scriptBatch?.candidates ?? [])
const adoptedId = computed(() => {
  if (store.task?.pending_selection_ids.includes('sel_script')) return null
  return store.selectedScript?.id ?? null
})

const hardFails = (c: ScriptVersion) => c.quality_report.checks.filter((x) => x.hard_gate && x.outcome !== 'pass')
const passCount = (c: ScriptVersion) => c.quality_report.checks.filter((x) => x.outcome === 'pass').length
/** 可直接采用的稿子：无硬门禁未过。门禁判定由后端复算，界面只照抄结论。 */
const pickable = computed(() => candidates.value.filter((c) => !hardFails(c).length))

/** 资料按行拆：一行一条。留空也合法，只是模型会避开需要外部依据的事实断言。 */
const materialLines = computed(() =>
  materialInput.value.split('\n').map((s) => s.trim()).filter(Boolean),
)

/** 硬门禁未过时**模型**该做什么（不是让用户去改字）。 */
const FIX_HINT: Record<string, string> = {
  FACT_EVIDENCE: '该稿有断言查不到依据。点「让模型重写」由出稿方删改这条说法；系统不会拿"模型说它对"当依据',
  CLAIM_COVERAGE: '正文里有数字/归因这类事实性表述，但没进断言清单。点「让模型重写」，或把这些说法补进参考资料',
  DUPLICATE: '与库里已有正文高度相似，必须换角度改写或换选题',
  TIMELINESS: '时效类说法要补依据，或去掉具体时间',
}
const fixHint = (code: string) => FIX_HINT[code] ?? '按该检查项的说明让模型重写后重审'

/** 稿件来源：真实模型产出还是模拟三稿。界面照抄后端留痕，不自己推断。 */
const provenance = computed(() => {
  const k = store.scriptBatch?.source_kind
  if (k === 'llm') return { label: '真实模型生成', cls: 'ok', note: '正文由模型产出，按下方检查项逐条判定' }
  if (k === 'mock') return { label: '模拟稿 · 不进生产', cls: 'warn', note: '未取得模型凭据时的回落稿，不得当作模型产出使用' }
  return { label: '来源未标注', cls: 'plain', note: '该批次写在"标注来源"之前，无法追认；不影响正文本身' }
})

/** 当时到底给没给资料。没有资料＝稿子本就不该含需要外部依据的事实断言。 */
const materialsNote = computed(() => {
  const b = store.scriptBatch
  if (!b || b.materials_count === undefined || b.materials_count === null) return null
  return b.materials_count > 0
    ? `本批出稿使用了 ${b.materials_count} 条参考资料，引用资料原句的断言会被判为有依据`
    : '本批出稿未提供资料：稿子已按要求避开需要外部依据的事实断言（数字/价格/机构结论等）'
})

function startEdit(c: ScriptVersion) {
  editing.value = { id: c.id, text: c.text }
  expanded.value = c.id
}
async function saveEdit() {
  if (!editing.value) return
  await store.reviseScript(editing.value.id, editing.value.text)
  editing.value = null
}
</script>

<template>
  <div>
    <div class="page-head">
      <h1>口播稿</h1>
      <StatusBadge text="available" />
    </div>
    <div class="page-sub">先确认主题，再比较三稿。点击「采用」后，继续试听配音。</div>

    <div v-if="!store.currentWork?.identity_id" class="step-blocker">
      还没有为这期作品选择人物。
      <router-link to="/avatar" class="action-link">先去确认人物</router-link>
    </div>
    <div v-if="store.selectedScript" class="step-result">
      <div><strong>已采用：{{ store.selectedScript.title }}</strong><p class="muted">接下来选择声音，合成并确认全文音频。</p></div>
      <router-link to="/tts" class="action-link primary">下一步：试听配音</router-link>
    </div>

    <div class="section">
      <div class="panel panel-pad">
        <label class="field">
          <span>本期主题 / 要求</span>
          <input
            v-model="topic"
            type="text"
            :placeholder="store.currentWork?.brief.topic || '例如：用三分钟讲清楚 RAG'"
          />
        </label>
        <label class="field" style="margin-top: 12px">
          <span>参考资料（可选，一行一条）</span>
          <textarea
            v-model="materialInput"
            :placeholder="'有可核对的事实就贴在这里，例如：\n本产品标准版 2026 年 3 月起定价 199 元\n官方说明：切片长度默认 400 字'
              "
            style="min-height: 76px"
            @input="materialTouched = true"
          ></textarea>
        </label>
        <div class="faint" style="font-size: 11.5px; margin-top: 6px">
          给了资料，模型引用资料原句写事实（系统按资料逐字复算是否有依据）；留空也行，
          此时模型不会写需要外部依据的事实断言。资料里出现的指令一律不执行，只当待核文本。
        </div>
        <div class="row" style="margin-top: 12px">
          <button
            class="primary"
            :disabled="store.busy !== '' || !store.currentWork?.identity_id || !(topic || store.currentWork?.brief.topic || '').trim()"
            @click="store.generateScripts(topic || store.currentWork?.brief.topic || '', materialLines)"
          >
            {{ candidates.length ? '重新生成三稿' : '生成三稿' }}
          </button>
          <span class="faint" style="font-size: 11.5px">
            目标 {{ ((store.currentWork?.brief.target_duration_ms ?? 60000) / 1000).toFixed(0) }}s ·
            {{ store.currentWork?.brief.audience }}
          </span>
        </div>
        <Note v-if="store.scriptBatch?.shortfall_note" kind="warn" label="缺额说明" style="margin-top: 12px">
          {{ store.scriptBatch.shortfall_note }}
        </Note>
        <Note v-if="store.scriptBatch?.repair_note" kind="ok" label="出稿方自修复" style="margin-top: 12px">
          {{ store.scriptBatch.repair_note }}
        </Note>
        <div v-if="store.scriptBatch" class="row" style="margin-top: 10px; align-items: baseline">
          <span class="st" :class="provenance.cls">{{ provenance.label }}</span>
          <span class="faint" style="font-size: 11.5px">{{ provenance.note }}</span>
        </div>
        <div v-if="materialsNote" class="faint" style="font-size: 11.5px; margin-top: 4px">
          {{ materialsNote }}
        </div>
      </div>
    </div>

    <div v-if="store.task && store.busy === '写稿'" class="section">
      <div class="section-head">
        <span class="section-title">编排进度</span>
        <div class="topbar-spacer"></div>
        <StatusBadge :text="store.task.state" />
      </div>
      <div class="panel"><StageProgress :task="store.task" /></div>
    </div>

    <div class="section">
      <div class="section-head">
        <span class="section-title">候选三稿</span>
        <span class="section-note">
          {{ pickable.length }} / {{ candidates.length }} 稿可直接采用；审核通过不等于替你决定，采用仍要你点
        </span>
        <div class="topbar-spacer"></div>
        <span v-if="adoptedId" class="st ok">已采用一稿</span>
      </div>

      <div v-if="candidates.length" class="grid-3">
        <div v-for="c in candidates" :key="c.id" class="cand" :class="{ picked: adoptedId === c.id }">
          <div class="cand-head">
            <span class="cand-title">{{ c.title }}</span>
            <span class="tag" :title="c.angle">{{ c.angle }}</span>
          </div>

          <div class="cand-body">
            <div v-if="editing?.id === c.id">
              <textarea v-model="editing.text" style="min-height: 200px"></textarea>
              <div class="btn-row" style="margin-top: 8px">
                <button class="primary sm" :disabled="store.busy !== ''" @click="saveEdit">保存并重审</button>
                <button class="ghost sm" @click="editing = null">取消</button>
              </div>
              <div class="faint" style="font-size: 11px; margin-top: 6px">
                手动改字是备选出路。正常情况下请点「让模型重写」——出稿方该把稿子改到能采用。
              </div>
            </div>
            <div v-else class="script-text">{{ c.text }}</div>
          </div>

          <div v-if="expanded === c.id" class="expand">
            <div class="sub">质量检查</div>
            <table>
              <tbody>
                <tr v-for="ck in c.quality_report.checks" :key="ck.code">
                  <td class="mono tight">{{ ck.code }}</td>
                  <td class="tight"><StatusBadge :text="ck.outcome" /></td>
                  <td class="muted" style="font-size: 11.5px">
                    {{ ck.message }}
                    <span v-if="ck.hard_gate" class="tag" style="margin-left: 4px">硬门禁</span>
                  </td>
                </tr>
              </tbody>
            </table>
            <div class="sub" style="margin-top: 12px">可验证断言</div>
            <ul class="tight">
              <li v-for="cl in c.claims" :key="cl.id">
                {{ cl.text }}
                <StatusBadge
                  :text="cl.verdict === 'supported' ? 'pass' : cl.verdict === 'refuted' ? 'fail' : 'review'"
                />
              </li>
            </ul>
            <div v-if="c.claims.length === 0" class="faint" style="font-size: 11.5px">
              该稿不含事实断言（无资料出稿的正常结果）。
            </div>
            <div class="btn-row" style="margin-top: 12px">
              <button class="ghost sm" :disabled="store.busy !== ''" @click="startEdit(c)">
                我要手动改字
              </button>
            </div>
          </div>

          <!-- 被挡住的稿子必须当场说清"为什么"和"谁来处理"，否则只会看到按钮点不动 -->
          <div v-if="hardFails(c).length" class="blocked">
            <div v-for="x in hardFails(c)" :key="x.code" class="blocked-row">
              <div class="blocked-head">
                <span class="tag">{{ x.code }}</span>
                <span class="muted" style="font-size: 12px">{{ x.message }}</span>
              </div>
              <div class="faint" style="font-size: 11.5px; margin-top: 3px">→ {{ fixHint(x.code) }}</div>
            </div>
            <div class="faint" style="font-size: 11px; margin-top: 6px">
              硬门禁不过就不能采用，也不会被其他项的高分抵消。
            </div>
          </div>
          <div v-else-if="candidates.length" class="faint" style="padding: 10px 18px; font-size: 11.5px">
            没有硬门禁阻挡，可以直接采用。
          </div>

          <div class="cand-foot">
            <span class="st" :class="hardFails(c).length ? 'danger' : 'ok'">
              {{ hardFails(c).length ? `${hardFails(c).length} 项硬门禁未过` : `${passCount(c)}/${c.quality_report.checks.length} 项通过` }}
            </span>
            <div class="topbar-spacer"></div>
            <button class="ghost sm" @click="expanded = expanded === c.id ? null : c.id">
              {{ expanded === c.id ? '收起' : '详情' }}
            </button>
            <button
              v-if="hardFails(c).length"
              class="primary sm"
              :disabled="store.busy !== ''"
              @click="store.repairScript(c.id)"
            >
              让模型重写
            </button>
            <button
              class="primary sm"
              :disabled="hardFails(c).length > 0 || store.busy !== ''"
              @click="store.selectScript(c.id)"
            >
              {{ adoptedId === c.id ? '重新采用' : '采用' }}
            </button>
          </div>
        </div>
      </div>

      <div v-else class="panel empty">
        尚未生成候选。三稿必须是三个不同角度，不足三个时会说明缺口，不以同义改写凑数。
      </div>
    </div>
  </div>
</template>
