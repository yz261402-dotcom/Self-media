<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useStudioStore } from '@/stores/studio'
import StatusBadge from '@/components/StatusBadge.vue'
import Note from '@/components/Note.vue'

const store = useStudioStore()
const sampleText = ref('大家好，今天我们用三分钟讲清楚一个容易被忽略的细节。')
const listened = ref<Record<string, boolean>>({})
watch(() => store.currentWorkId, () => { listened.value = {} })

const scriptReady = computed(() => store.scriptReady)
const previews = computed(() => store.audios.filter((a) => a.kind === 'preview'))
const fulls = computed(() => store.audios.filter((a) => a.kind === 'full'
  && (!a.script_version_id || a.script_version_id === store.currentWork?.script_version_id)
  && (!a.voice_asset_id || a.voice_asset_id === store.currentWork?.voice_asset_id)))
const dur = (ms: number) => (Math.round(ms / 100) / 10).toFixed(1)

// 可确认性来自后端门禁，不在前端自己放宽：
// 占位产物（is_mock）与硬门禁失败项都不允许被确认为最终音频。
const confirmBlock = (a: { is_mock?: boolean; confirmed?: boolean; checks: { code: string; outcome: string; hard_gate: boolean; message: string }[] }) => {
  if (a.confirmed) return '已确认为最终音频'
  if (a.is_mock) return '占位音频不可确认：需接入真实 Provider 后重新合成'
  const hard = a.checks.filter((c) => c.hard_gate && c.outcome !== 'pass')
  if (hard.length) return `硬门禁未通过（${hard.map((c) => c.code).join('、')}）`
  return ''
}
</script>

<template>
  <div>
    <div class="page-head">
      <h1>语音配音</h1>
      <StatusBadge text="available" />
    </div>
    <div class="page-sub">1. 试听并选用音色　2. 合成全文　3. 听完并确认，进入视频合成</div>

    <div v-if="store.confirmedAudio" class="step-result">
      <div><strong>全文音频已确认 · {{ dur(store.confirmedAudio.duration_ms) }} 秒</strong><p class="muted">当前音色：{{ store.currentVoice?.name ?? '已选音色' }}。视频将沿用这条音轨。</p></div>
      <router-link to="/video" class="action-link primary">下一步：合成视频</router-link>
    </div>

    <div v-if="!scriptReady" class="section">
      <Note kind="warn" label="前置未满足">
        还没有已采用且通过审核的稿件。请先到「口播稿」选定一稿，全文配音以它为唯一正文来源。
        <router-link to="/script" class="action-link">去选定稿件</router-link>
      </Note>
    </div>

    <div class="grid-2 section">
      <div>
        <div class="section-head">
          <span class="section-title">音色与试听</span>
          <span class="section-note">用同一短句比较不同声音</span>
        </div>
        <div class="panel">
          <div class="panel-pad" style="border-bottom: 1px solid var(--line)">
            <label class="field" style="margin-bottom: 0">
              <span>基准短句</span>
              <textarea v-model="sampleText" style="min-height: 56px"></textarea>
            </label>
          </div>
          <table>
            <thead>
              <tr><th>音色</th><th class="tight">定版</th><th class="tight">操作</th></tr>
            </thead>
            <tbody>
              <tr v-for="v in store.voices" :key="v.id" :class="{ hl: store.currentWork?.voice_asset_id === v.id }">
                <td>
                  <div style="font-weight: 600">{{ v.name }}</div>
                  <div class="faint mono">{{ v.provider }} / {{ v.model }}</div>
                </td>
                <td class="tight"><StatusBadge :text="v.approval_state" /></td>
                <td class="tight">
                  <div class="btn-row">
                    <button class="sm" :disabled="store.busy !== '' || !store.currentWork || !sampleText.trim()" @click="store.voicePreview(v.id, sampleText)">
                      生成试听
                    </button>
                    <button
                      class="sm"
                      :disabled="store.busy !== '' || !store.currentWork || store.currentWork?.voice_asset_id === v.id || v.approval_state !== 'approved'"
                      @click="store.selectVoice(v.id)"
                    >
                      {{ store.currentWork?.voice_asset_id === v.id ? '已绑定' : '选用' }}
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <div v-if="previews.length" style="border-top: 1px solid var(--line); padding: 8px 14px">
            <div v-for="a in previews" :key="a.id" style="padding: 8px 0">
              <div class="row"><span class="st ok">试听 {{ dur(a.duration_ms) }}s</span>
              <span class="faint">{{ store.voices.find(v => v.id === a.voice_asset_id)?.name ?? a.voice_asset_id }}</span></div>
              <audio v-if="a.url && !a.is_mock" :src="a.url" controls preload="none" style="width: 100%; margin-top: 8px"></audio>
              <p v-else class="faint">暂无可播放的真实试听音频。</p>
            </div>
            <div class="faint" style="font-size: 10.5px">试听片不能当作最终音频</div>
          </div>
        </div>
      </div>

      <div>
        <div class="section-head">
          <span class="section-title">全文合成</span>
          <span class="section-note">音色：{{ store.currentVoice?.name ?? '未选择' }}</span>
        </div>
        <div class="panel">
          <div class="panel-pad">
            <p class="muted">采用稿件：{{ store.selectedScript?.title ?? '未选择' }}</p>
            <button class="primary" :disabled="!scriptReady || !store.currentVoice || store.busy !== ''" @click="store.synthesizeFull()">
              {{ fulls.length ? '读取或复用全文音频' : '合成全文音频' }}
            </button>
            <button v-if="fulls.length" style="margin-left: 8px" :disabled="!scriptReady || !store.currentVoice || !!store.busy" @click="store.synthesizeFull(true)">重新合成（可能再次收费）</button>
            <p v-if="!store.currentVoice" class="faint" style="margin-top: 10px">先在左侧选择一种已定版音色。</p>
          </div>

          <template v-if="fulls.length">
            <div class="divider"></div>
            <div v-for="a in fulls" :key="a.id" style="padding: 14px 16px">
              <div class="row" style="margin-bottom: 8px">
                <span style="font-weight: 600">全文音频 {{ dur(a.duration_ms) }}s</span>
                <StatusBadge v-if="a.is_mock" text="mock" />
                <div class="topbar-spacer"></div>
                <StatusBadge :text="a.confirmed ? 'approved' : 'pending'" />
              </div>

              <audio v-if="a.url" :src="a.url" controls style="width: 100%; margin-bottom: 10px"></audio>
              <div v-else class="faint" style="font-size: 11.5px; margin-bottom: 10px">
                当前模式未返回可播放音频字节（不伪造音频；真实 Provider 接入后此处播放最终 WAV）
              </div>

              <table>
                <tbody>
                  <tr v-for="ck in a.checks" :key="ck.code">
                    <td class="mono tight">{{ ck.code }}</td>
                    <td class="tight"><StatusBadge :text="ck.outcome" /></td>
                    <td class="muted" style="font-size: 11.5px">{{ ck.message }}</td>
                  </tr>
                </tbody>
              </table>

              <div style="margin-top: 10px">
                <label v-if="!a.confirmed && !confirmBlock(a)" class="ack-label">
                  <input v-model="listened[a.id]" type="checkbox" />
                  我已试听全文，确认内容、发音和音色符合这一期要求
                </label>
                <button
                  class="primary sm"
                  :disabled="!!confirmBlock(a) || !listened[a.id] || store.busy !== ''"
                  @click="store.confirmAudio(a.id)"
                >
                  {{ a.confirmed ? '已确认为最终音频' : '确认这条全文音频' }}
                </button>
                <span v-if="confirmBlock(a)" class="faint" style="margin-left: 10px; font-size: 11.5px">
                  {{ confirmBlock(a) }}
                </span>
              </div>
            </div>
          </template>
          <div v-else class="empty">尚未合成全文音频。</div>
        </div>
      </div>
    </div>

    <div class="section">
      <Note label="约束">
        术语（RAG / API / LLM）读法需一致，表达标记不能被朗读出来；不支持的情绪要明确提示，不允许静默忽略。
        换声或改正文都会使下游口型与字幕失效并重做。
      </Note>
    </div>
  </div>
</template>
