import { defineStore } from 'pinia'
import { api } from '@/api'
import type {
  AdapterStatusView,
  AudioAssetInfo,
  AvatarAssetView,
  AvatarIdentity,
  AvatarVariant,
  Capabilities,
  CostEstimate,
  FeatureEntry,
  GenerationRoute,
  IdentityReadinessBrief,
  MaskEstimateResult,
  MaskSpec,
  MotionCatalogView,
  PlateStatusView,
  PublishPackage,
  PostprocessView,
  QueueView,
  RoutePriceView,
  ScriptBatch,
  ScriptVersion,
  SegmentPlanView,
  SubmissionListView,
  TalkingHeadCostView,
  TalkingHeadGateSummary,
  TalkingHeadPreflight,
  Task,
  TaskEvent,
  VariantAdmitResult,
  VariantComposeResult,
  VideoAsset,
  VideoGateView,
  VoiceAsset,
  Work,
} from '@/api/types'

export type Resolution = '720p' | '1080p'

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))

export const useStudioStore = defineStore('studio', {
  state: () => ({
    apiReady: false as boolean,
    workLoadVersion: 0,
    capabilities: null as Capabilities | null,
    features: [] as FeatureEntry[],
    works: [] as Work[],
    currentWorkId: null as string | null,
    identities: [] as AvatarIdentity[],
    // 已丢弃的草稿候选：记录仍在后端，只是被移出工作列表。界面单独成组并给"恢复"。
    discardedIdentities: [] as AvatarIdentity[],
    // 每条人物"还缺什么"（来自后端 readiness 的 reasons，界面不自己另编一套说法）
    readinessMap: {} as Record<string, IdentityReadinessBrief>,
    voices: [] as VoiceAsset[],
    variants: [] as AvatarVariant[],
    scriptBatch: null as ScriptBatch | null,
    audios: [] as AudioAssetInfo[],
    task: null as Task | null,
    events: [] as TaskEvent[],
    pkg: null as PublishPackage | null,
    postprocess: null as PostprocessView | null,
    busy: '' as string,
    error: null as string | null,
    notice: null as { kind: 'ok' | 'warn' | 'danger'; text: string } | null,

    // ---------- T05 数字人口播 ----------
    thRoutes: null as RoutePriceView | null,
    thPreflight: null as TalkingHeadPreflight | null,
    thCost: null as TalkingHeadCostView | null,
    thSegments: null as SegmentPlanView | null,
    thPlate: null as PlateStatusView | null,
    thSubmissions: null as SubmissionListView | null,
    thGate: null as TalkingHeadGateSummary | null,
    thQueue: null as QueueView | null,
    thAdapters: null as AdapterStatusView | null,
    /** 该人物已获准的动作参考 + 受支持动作目录（目录≠可用：只有 approved 能解析通过） */
    motionCatalog: null as MotionCatalogView | null,
    /** 变体准入判定的原始结论：不合格时逐条原因，界面照抄 */
    variantGate: null as VariantAdmitResult | null,
    /** 该人物已登记的 mask（含未确认的草稿）：换景合成的前置 */
    masks: [] as MaskSpec[],
    /** 最近一次自动分割的草稿（含预览图与风险提示） */
    maskDraft: null as MaskEstimateResult | null,
    /** 最近一次确定性合成的结果：pixel_identical / max_channel_diff 直接照抄展示 */
    composeResult: null as VariantComposeResult | null,
    /** 该人物可用的背景底片资产。合成要的是 background_asset_id，不是界面自造的场景名 */
    backgroundAssets: [] as AvatarAssetView[],
    /** 准入时声明的画风。留空 = "无法判断"，门禁不会放过，因此必须显式填 */
    variantStyle: 'realistic' as string,
    videos: [] as VideoAsset[],
    videoGates: {} as Record<string, VideoGateView>,
    /** 提交参数：清单摘要由这些值推导，因此它们必须显式可见、可回溯 */
    thPrompt: '' as string,
    thResolution: '1080p' as Resolution,
  }),
  getters: {
    currentWork(state): Work | null {
      return state.works.find((w) => w.id === state.currentWorkId) ?? null
    },
    currentIdentity(state): AvatarIdentity | null {
      const id = this.currentWork?.identity_id
      return state.identities.find((i) => i.id === id) ?? null
    },
    identityReady(state): boolean {
      const id = this.currentWork?.identity_id
      return !!id && state.readinessMap[id]?.ready === true
    },
    /** 已定版、可以选用的身份。 */
    usableIdentities(state): AvatarIdentity[] {
      return state.identities.filter((i) => i.approval_state === 'approved')
    },
    /** 草稿候选：还没定版，不能进生产，只能继续走定版或被丢弃。 */
    draftIdentities(state): AvatarIdentity[] {
      return state.identities.filter((i) => i.approval_state !== 'approved')
    },
    /**
     * 当前作品"下一步该做什么"——**全应用唯一的定义**（侧栏与各页都用它）。
     *
     * 存在的理由：界面此前选完人物就没了下文，用户点完「选用」不知道往哪走；
     * 侧栏底部虽然有一行"下一步"，但它是浅灰小字、贴在页面最底部，等于藏起来了。
     *
     * 判定沿用侧栏既有的派生量（scriptReady / confirmedAudio / pkg），
     * 不另起一套原始字段判断——两套判断会给出两个"下一步"，比没有指引更糟。
     * `to` 为空表示"还没有作品"，此时不指向任何页面。
     */
    nextStep(state): { key: string; title: string; detail: string; to: string; label: string } {
      const w = state.works.find((x) => x.id === state.currentWorkId)
      if (!w) {
        return { key: 'work', title: '先创建一个作品',
                 detail: '填写这一期的主题和目标时长，之后按顺序确认人物、稿件、声音与视频。', to: '', label: '创建第一个作品' }
      }
      if (!this.identityReady) {
        return { key: 'identity', title: '第 1 步：选定人物',
                 detail: w.identity_id
                   ? `当前人物还需完善：${state.readinessMap[w.identity_id]?.reasons.join('；') || '尚未取得人物就绪结果'}。到人物页查看并处理。`
                   : '选择已有主播，或新建一个主播并完成图片与使用权确认。',
                 to: '/avatar', label: '回到人物库' }
      }
      if (!this.scriptReady) {
        return { key: 'script', title: '第 2 步：写口播稿并定稿',
                 detail: '人物已选定，接下来要有可朗读、已采用的一稿',
                 to: '/script', label: '去写口播稿' }
      }
      if (!this.confirmedAudio) {
        return { key: 'tts', title: '第 3 步：合成并确认音轨',
                 detail: '稿件已定稿，需要一条经人工确认的最终音轨',
                 to: '/tts', label: '去合成音轨' }
      }
      if (!this.deliveryReady) {
        return { key: 'video', title: '第 4 步：生成并打包口播视频',
                 detail: '基础输入已齐。到视频页检查生成条件、选择方式，确认费用后提交；原片和成片都要由你观看确认。',
                 to: '/video', label: '去生成视频' }
      }
      return { key: 'download', title: '制作完成：预览并下载成片',
               detail: '下载视频、字幕、封面与投稿文案后自行投稿。自动发布仍在开发中。', to: '/video', label: '查看与下载成片' }
    },
    currentVoice(state): VoiceAsset | null {
      const id = this.currentWork?.voice_asset_id
      return state.voices.find((v) => v.id === id) ?? null
    },
    /** 用户显式采用的稿件；以 Work.script_version_id 为准，重新出稿后会被后端清空 */
    selectedScript(state): ScriptVersion | null {
      const id = this.currentWork?.script_version_id
      if (!id) return null
      return state.scriptBatch?.candidates.find((c) => c.id === id) ?? null
    },
    /** 稿件是否已采用：以服务端持久化字段为准，避免刷新后状态丢失 */
    scriptReady(): boolean {
      return !!this.selectedScript
    },
    confirmedAudio(state): AudioAssetInfo | null {
      const w = this.currentWork
      if (!w) return null
      return state.audios.find((a) => a.kind === 'full' && a.confirmed && !a.is_mock
        && (!a.work_id || a.work_id === w.id)
        && (!a.script_version_id || a.script_version_id === w.script_version_id)
        && (!w.final_audio_id || a.id === w.final_audio_id)) ?? null
    },
    deliveryReady(state): boolean {
      return !!state.currentWorkId && state.pkg?.work_id === state.currentWorkId
        && state.pkg.state === 'ready' && state.pkg.mode !== 'mock' && !!state.pkg.download_url
    },

    /** 当前作品选定的口播路线：以作品字段为准，与服务端前置判定同源。
     *
     * 作品还没有路线时回退为 **M2**：那是界面默认指向的低成本路线，
     * 不能回退成 OmniHuman——否则界面会把"没选"显示成"已选高成本路线"，
     * 既误导用户，也会让费用提示看起来已经被跨过。
     */
    currentRoute(state): GenerationRoute {
      return this.currentWork?.route || 'M2'
    },
    /** 是否已经有过一次可追溯的人工路线确认。
     *
     * 与 `currentRoute` 分开：后者带默认值 `M2`，前者才回答"选了没有"。
     * 界面据此区分"已选 M2"和"还没选、只是默认指向 M2"——
     * 后端明确不接受把默认值当授权（`assert_route_selected` 要求
     * `route_confirmed` 与 `route_selection_id` 同时存在）。
     * 判据来自服务端（`/talking-head/routes?work_id=`），不靠作品字段：
     * 作品 `route` 永远非空，拿它判断会永远显示成"已选"。
     */
    routeSelected(state): boolean {
      return state.thRoutes?.route_confirmed === true
    },
    /** 路线能力条目（declared / verified 分列的那一份） */
    currentRouteSpec(state) {
      const r = this.currentRoute
      return state.thRoutes?.routes.find((x) => x.route === r) ?? null
    },
    thBlockers(state) {
      return state.thPreflight?.blockers ?? []
    },
    /** 前置未通过就不得提交——界面据此禁用按钮，而不是靠提示语 */
    thReady(): boolean {
      return !!this.thPreflight?.ok
    },
    /** 已确认的费用记录：确认过清单与金额，但这不等于付费授权 */
    thConfirmedCost(state) {
      return state.thCost?.confirmation ?? null
    },
    /** 已确认的最终原片（本作品唯一一条） */
    finalVideo(state): VideoAsset | null {
      return state.videos.find((v) => v.kind === 'original' && v.confirmed) ?? null
    },
    pendingPlates(state): VideoAsset[] {
      return state.videos.filter((v) => v.kind === 'plate' && !v.confirmed)
    },
  },
  actions: {
    workContextMatches(id: string | null, version: number, taskId?: string | null): boolean {
      return this.currentWorkId === id && this.workLoadVersion === version
        && (taskId === undefined || this.currentWork?.current_task_id === taskId)
    },
    setNotice(kind: 'ok' | 'warn' | 'danger', text: string) {
      this.notice = { kind, text }
    },
    clearNotice() {
      this.notice = null
    },
    async guard<T>(label: string, fn: () => Promise<T>): Promise<T | null> {
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      this.busy = label
      this.error = null
      try {
        const r = await fn()
        return this.workContextMatches(workId, version) ? r : null
      } catch (e: any) {
        if (this.workContextMatches(workId, version)) this.error = e?.message ?? String(e)
        return null
      } finally {
        if (this.workContextMatches(workId, version) && this.busy === label) this.busy = ''
      }
    },

    async bootstrap() {
      await this.guard('加载', async () => {
        this.capabilities = await api.getCapabilities()
        this.features = await api.getFeatures()
        this.identities = await api.listIdentities()
        this.discardedIdentities = (await api.listIdentities(true)).filter((i) => !!i.discarded_at)
        this.readinessMap = await api.identitiesReadiness()
        this.voices = await api.listVoices()
        this.works = (await api.listWorks()).sort((a, b) => (b.created_at ?? '').localeCompare(a.created_at ?? ''))
        let remembered = ''
        try { remembered = localStorage.getItem('avatar-studio:last-work') ?? '' } catch { /* storage may be unavailable */ }
        if (!this.currentWorkId && this.works.length) {
          this.currentWorkId = this.works.find(w => w.id === remembered)?.id ?? this.works[0].id
        }
        this.apiReady = true
      })
      if (this.currentWorkId) await this.loadWork(this.currentWorkId)
    },

    async createWork(input: {
      name: string
      topic: string
      content_type: string
      audience: string
      keywords: string[]
      target_duration_ms: number
    }) {
      const w = await this.guard('创建作品', () => api.createWork(input))
      if (w) {
        this.works.push(w)
        this.currentWorkId = w.id
        this.rememberWork(w.id)
        await this.loadWork(w.id)
      }
      return w
    },

    async selectWork(id: string) {
      this.currentWorkId = id
      this.rememberWork(id)
      await this.loadWork(id)
    },

    rememberWork(id: string) {
      try { localStorage.setItem('avatar-studio:last-work', id) } catch { /* selection still works without storage */ }
    },

    async loadWork(id: string) {
      const version = ++this.workLoadVersion
      this.clearWorkState()
      await this.guard('读取作品', async () => {
        const [works, scriptBatch, variants, pkg, audios] = await Promise.all([
          api.listWorks(), api.getScriptBatch(id), api.listVariants(id),
          api.getPackage(id), api.listAudios(id),
        ])
        if (version !== this.workLoadVersion || id !== this.currentWorkId) return
        this.works = works.sort((a, b) => (b.created_at ?? '').localeCompare(a.created_at ?? ''))
        this.scriptBatch = scriptBatch
        this.variants = variants
        this.pkg = pkg?.work_id === id ? pkg : null
        this.audios = audios
        const w = works.find((x) => x.id === id)
        if (w?.current_task_id) {
          const taskId = w.current_task_id
          const [task, events] = await Promise.all([
            api.getTask(taskId), api.getTaskEvents(taskId),
          ])
          if (!this.workContextMatches(id, version, taskId) || task.work_id !== id || task.id !== taskId) return
          this.task = task
          this.events = events
        }
      })
      if (version !== this.workLoadVersion || id !== this.currentWorkId) return
      await this.loadMotions()
      if (!this.workContextMatches(id, version)) return
      await this.loadVariantInputs()
    },

    /** Keep derived data scoped to one work, including while the next request is pending. */
    clearWorkState() {
      this.busy = ''
      this.error = null
      this.notice = null
      this.scriptBatch = null
      this.variants = []
      this.audios = []
      this.task = null
      this.events = []
      this.pkg = null
      this.postprocess = null
      this.videos = []
      this.videoGates = {}
      this.thRoutes = null
      this.thPreflight = null
      this.thCost = null
      this.thSegments = null
      this.thPlate = null
      this.thSubmissions = null
      this.thGate = null
      this.thQueue = null
      this.motionCatalog = null
      this.variantGate = null
      this.masks = []
      this.maskDraft = null
      this.composeResult = null
      this.backgroundAssets = []
      this.thPrompt = ''
      this.thResolution = '1080p'
    },

    /** Re-read authoritative invalidation after changing a dependency. */
    async syncWork(id: string) {
      if (this.currentWorkId !== id) return
      await this.loadWork(id)
    },

    async refreshPostprocess() {
      const id = this.currentWorkId
      if (!id) return
      const version = this.workLoadVersion
      const taskId = this.currentWork?.current_task_id
      const view = await api.getPostprocess(id)
      if (!this.workContextMatches(id, version, taskId)) return
      this.postprocess = view
      if (view?.task) {
        this.task = view.task
        const w = this.works.find((x) => x.id === id)
        if (w) w.current_task_id = view.task.id
      }
    },

    async startPostprocess() {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      const taskId = this.currentWork?.current_task_id
      if (!id) return
      const task = await this.guard('生成字幕与成片', () => api.startPostprocess(id))
      if (!task || !this.workContextMatches(id, version, taskId) || task.work_id !== id) return
      this.task = task
      const w = this.works.find((x) => x.id === id)
      if (w) w.current_task_id = task.id
      await this.guard('读取成片进度', () => this.refreshPostprocess())
    },

    async confirmPostprocess() {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      const taskId = this.currentWork?.current_task_id
      const executionId = this.postprocess?.execution?.id
      if (!id || !this.postprocess?.ready_for_review || !executionId) return
      const pkg = await this.guard('生成下载包', () => api.confirmPostprocess(id, executionId))
      if (!pkg || !this.workContextMatches(id, version, taskId) || pkg.work_id !== id
        || this.postprocess?.execution?.id !== executionId) return
      this.pkg = pkg
      this.setNotice('ok', '成片已确认，可以下载视频、字幕、封面与投稿文案')
      await this.guard('读取交付状态', () => this.refreshPostprocess())
    },

    /** 该人物**现在真能用**的动作 = 已获准参考，而不是整个目录。
     *  目录里没登记参考的动作键，解析阶段会被 MOTION_NOT_APPROVED 拒掉，
     *  界面上不该给一个选了必然失败的选项。 */
    async loadMotions() {
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      const id = this.currentWork?.identity_id
      if (!id) {
        this.motionCatalog = null
        return
      }
      const catalog = await api.listMotions(id).catch(() => null)
      if (this.workContextMatches(workId, version) && this.currentWork?.identity_id === id) this.motionCatalog = catalog
    },

    /** 登记动作意图（落库）。只在下拉框里选一下是不够的：
     *  底片是从作品上读 motion_intent 的，不落库就会在提交时才报 MOTION_REQUIRED。 */
    async adoptMotion(motionKey: string, motionRefId?: string) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id || !motionKey) return
      const r = await this.guard('登记动作意图', () =>
        api.setMotionIntent(id, {
          motion_key: motionKey,
          ...(motionRefId ? { motion_ref_id: motionRefId } : {}),
        }),
      )
      if (!r) return
      this.setNotice(
        'ok',
        `已登记动作「${r.motion_intent.motion_key}」并绑定参考 ${r.motion_intent.motion_ref_id}`
          + '（绑定后同一动作键下的其他参考不得顶替）',
      )
      const preflight = await api.getTalkingHeadPreflight(id).catch(() => null)
      if (this.workContextMatches(id, version)) this.thPreflight = preflight
    },

    /** 变体准入判定：拿服务端逐条原因，界面不自己另编一套说法 */
    async admitVariant(variantId: string) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      // 画风必须显式声明：门禁不接受"未声明画风"，空字符串会被判 review 而不是 pass。
      const r = await api.admitVariant(id, variantId, this.variantStyle).catch(() => null)
      if (!this.workContextMatches(id, version)) return
      this.variantGate = r
      if (r && !r.ok) {
        this.setNotice('danger', `变体不可用于生产：${r.reasons.join('；')}`)
      } else if (r) {
        this.setNotice('ok', '变体通过生产准入判定')
      }
    },

    /**
     * 换景合成的前置输入：已登记的 mask + 可用的背景底片。
     * 两者都从后端取——合成要的是真实资产 id，界面自己编一个场景名是合成不出来的。
     */
    async loadVariantInputs() {
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      const id = this.currentWork?.identity_id
      this.maskDraft = null
      this.composeResult = null
      if (!id) {
        this.masks = []
        this.backgroundAssets = []
        return
      }
      const [masks, backgrounds] = await Promise.all([
        api.listMasks(id).catch(() => null),
        api.listIdentityAssets(id, 'background').catch(() => [] as AvatarAssetView[]),
      ])
      if (!this.workContextMatches(workId, version) || this.currentWork?.identity_id !== id) return
      this.masks = masks?.masks ?? []
      this.backgroundAssets = backgrounds
    },

    /** 自动分割 mask **草稿**。界面上不提供"自动通过"：指标只能排除已知失效。 */
    async createMaskDraft() {
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      const id = this.currentWork?.identity_id
      if (!id) return
      const r = await this.guard('生成蒙版草稿', () => api.createMask(id))
      if (!r) return
      this.setNotice(
        'warn',
        '已生成蒙版草稿：它必须由人目视确认后才能用于产出变体。指标全绿只说明没触发已知失效条件，不等于蒙版正确',
      )
      await this.loadVariantInputs()
      if (!this.workContextMatches(workId, version)) return
      this.maskDraft = r
    },

    /** 人工目视确认 mask —— 权限来自"人"本身，系统不替人核发。 */
    async confirmMask(maskAssetId: string, outcome: 'pass' | 'fail' | 'review', note: string) {
      const r = await this.guard('确认蒙版', () => api.confirmMask(maskAssetId, outcome, note))
      if (!r) return
      if (r.state === 'confirmed') this.setNotice('ok', '蒙版已由人工确认通过，可用于产出变体')
      else if (r.state === 'rejected') this.setNotice('danger', '蒙版已标记为不通过，需重新生成')
      else this.setNotice('warn', '蒙版结论记为"待复核"：仍不能用于产出变体')
      await this.loadVariantInputs()
    },

    /**
     * 生成变体 = **确定性合成**，不是生成模型重绘。
     *
     * 顺序固定且不可跳：先要一条已人工确认的 mask，再选背景底片。
     * 之所以不给"直接出图"的捷径：gpt-image 系列中转会整图重绘，
     * 换景必然连着把脸一起重画（身份漂移），只有逐像素合成能守住身份。
     */
    async createVariant(outfit: string, backgroundAssetId: string, backgroundLabel = '') {
      const workId = this.currentWorkId
      const identityId = this.currentWork?.identity_id
      if (!workId || !identityId) return

      const confirmed = this.masks.find((m) => m.state === 'confirmed')
      if (!confirmed) {
        this.setNotice('danger', '还没有已确认的蒙版：先在下面生成蒙版草稿，并由人目视确认通过')
        return
      }
      if (!backgroundAssetId) {
        this.setNotice('danger', '该人物还没有可用的背景底片资产，无法合成')
        return
      }

      const composed = await this.guard('确定性合成变体', () =>
        api.composeVariant(identityId, {
          mask_asset_id: confirmed.mask_asset_id,
          background_asset_id: backgroundAssetId,
          edge_mode: 'unmix',
          outfit,
          background_label: backgroundLabel,
        }),
      )
      if (!composed) return
      this.composeResult = composed

      const v = await this.guard('登记变体', () =>
        api.createVariant(workId, {
          // 引用刚合成的那张资产，不再重复登记一份（同一张图两个 id 会让来源链断掉）
          asset_id: composed.asset?.id,
          outfit,
          background: backgroundLabel || backgroundAssetId,
          identity_digest: this.currentIdentity?.identity_digest || undefined,
        }),
      )
      if (!v) return
      this.variants.push(v)
      const mx = composed.max_channel_diff
      this.setNotice(
        'warn',
        `变体已登记为待审。硬保护区最大通道差 ${mx === null ? '无法判定' : mx}` +
          '（严格为 0 才是逐像素相同）；未通过身份审核前不得进入生产',
      )
    },

    /** 变体身份审核：走资产审核端点，审核摘要必须与冻结基准一致，否则按换脸拒收。 */
    async reviewVariantAsset(assetId: string, outcome: 'pass' | 'fail' | 'review') {
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      const identityId = this.currentWork?.identity_id
      if (!identityId || !assetId) return
      const digest = this.currentIdentity?.identity_digest || ''
      const r = await this.guard('变体身份审核', () =>
        api.reviewIdentityAsset(identityId, assetId, {
          // 资产审核的结论取值是 pass/reject/review；本方法的 fail 语义等同于 reject。
          outcome: outcome === 'fail' ? 'reject' : outcome,
          identity_digest: digest,
          method: '人工对照定妆原图',
          note: '变体身份审核：人工对照冻结基准',
        }),
      )
      if (!r) return
      this.setNotice(
        outcome === 'pass' ? 'ok' : 'warn',
        outcome === 'pass'
          ? '变体身份审核记为通过：它现在可以通过准入判定（仍需核对画风与种类）'
          : '变体审核未记为通过，不能用于生产',
      )
      if (workId) {
        const variants = await api.listVariants(workId)
        if (this.workContextMatches(workId, version)) this.variants = variants
      }
    },

    async refreshTask() {
      const id = this.currentWork?.current_task_id
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      if (!id || !workId) return
      const t = await api.getTask(id).catch(() => null)
      if (!t || t.work_id !== workId || t.id !== id || !this.workContextMatches(workId, version, id)) return
      this.task = t
      const w = this.works.find((x) => x.id === t.work_id)
      if (w) w.current_task_id = t.id
      const evs = await api.getTaskEvents(id, this.events.length).catch(() => [])
      if (!this.workContextMatches(workId, version, id)) return
      if (evs.length) this.events.push(...evs)
      if (t.state === 'succeeded' && !this.pkg) {
        const pkg = await api.getPackage(workId).catch(() => null)
        if (!this.workContextMatches(workId, version, id)) return
        if (pkg?.work_id === workId) this.pkg = pkg
      }
    },

    /** 轮询直到任务离开运行态；只展示真实阶段，不伪造百分比。 */
    async pollTask(times = 40) {
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      const taskId = this.currentWork?.current_task_id
      for (let i = 0; i < times; i++) {
        await wait(1200)
        if (!this.workContextMatches(workId, version, taskId)) return
        await this.refreshTask()
        if (!this.workContextMatches(workId, version, taskId)) return
        const s = this.task?.state
        if (!s) break
        if (['waiting_selection', 'succeeded', 'failed', 'cancelled', 'blocked'].includes(s)) break
      }
    },

    async generateScripts(topic: string, materials: string[] = []) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      const clean = materials.map((m) => m.trim()).filter(Boolean)
      this.setNotice(
        'ok',
        clean.length
          ? `已提交写稿任务：将按你给的 ${clean.length} 条资料生成三个不同角度，并要求模型交付可采用稿`
          : '已提交写稿任务：未提供资料，模型会避开需要外部依据的事实断言，交付三个可采用的角度',
      )
      const batch = await this.guard('写稿', async () => {
        const b = await api.generateScripts(id, topic, clean)
        if (!this.workContextMatches(id, version)) return null
        // 新一版候选意味着旧采用失效
        const w = this.works.find((x) => x.id === id)
        if (w) w.script_version_id = null
        // 资料落进作品 brief：重新生成时沿用，刷新后也能看到当时给了什么
        if (w) w.brief.materials = clean.map((text) => ({ text }))
        await this.pollTask(12)
        return b
      })
      if (batch && this.currentWorkId === id) await this.syncWork(id)
    },

    /** 让模型把这一稿重写到过硬门禁。这是出稿方返工，不是让用户去改字。 */
    async repairScript(scriptId: string) {
      const id = this.currentWorkId
      if (!id) return null
      const fixed = await this.guard('重写稿件', () => api.repairScript(id, scriptId))
      if (!fixed) return null
      if (this.scriptBatch) {
        this.scriptBatch = {
          ...this.scriptBatch,
          candidates: this.scriptBatch.candidates.map((c) => (c.id === scriptId ? fixed : c)),
        }
      }
      const hard = fixed.quality_report.checks.filter((c) => c.hard_gate && c.outcome !== 'pass')
      this.setNotice(
        hard.length ? 'danger' : 'ok',
        hard.length
          ? `模型重写后仍有 ${hard.length} 项硬门禁未过（${hard.map((c) => c.code).join('/')}），未伪报可用`
          : `模型已重写「${fixed.angle}」，硬门禁全部通过，可以采用了`,
      )
      return fixed
    },

    async selectScript(scriptId: string) {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('选稿', () => api.selectScript(id, scriptId))
      if (!r) return
      if (!r.ok) {
        this.setNotice('danger', r.message)
        return
      }
      const w = this.works.find((x) => x.id === id)
      if (w) w.script_version_id = scriptId
      this.setNotice('ok', r.message)
      await this.syncWork(id)
    },

    async reviseScript(scriptId: string, text: string) {
      const id = this.currentWorkId
      if (!id) return
      const v = await this.guard('重审', () => api.reviseScript(id, scriptId, text))
      if (v) {
        this.setNotice('ok', '已保存修订稿并重新审核；下游音频与口型依赖已失效')
        await this.syncWork(id)
      }
    },

    /** 重新拉人物列表与就绪度：丢弃 / 恢复之后必须重取，否则分组与"还缺什么"会不同步。 */
    async reloadIdentities() {
      this.identities = await api.listIdentities()
      this.discardedIdentities = (await api.listIdentities(true)).filter((i) => !!i.discarded_at)
      this.readinessMap = await api.identitiesReadiness()
    },

    /**
     * 丢弃草稿候选：移出工作列表。**不是删除**——记录与历史都保留，可随时恢复。
     * 拒绝的原因由后端给（已定版 / 被作品或变体引用），界面直接转述，不自己另编。
     */
    async discardCandidate(identityId: string, reason: string) {
      const r = await this.guard('丢弃候选', () => api.discardIdentity(identityId, reason))
      if (!r) return
      await this.reloadIdentities()
      this.setNotice('ok', '候选已移出工作列表（记录仍保留，可随时恢复）')
    },

    async restoreCandidate(identityId: string) {
      const r = await this.guard('恢复候选', () => api.restoreIdentity(identityId))
      if (!r) return
      await this.reloadIdentities()
      this.setNotice('ok', '候选已放回工作列表')
    },

    async selectIdentity(identityId: string) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      await this.guard('选择人物', async () => {
        const updated = await api.selectIdentity(id, identityId)
        if (!this.workContextMatches(id, version)) return
        const w = this.works.find((x) => x.id === id)
        if (w) Object.assign(w, updated)
      })
      if (!this.error && this.workContextMatches(id, version)) await this.syncWork(id)
    },

    async voicePreview(voiceId: string, sampleText: string) {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('试听', () => api.createVoicePreview(id, voiceId, sampleText))
      if (!r) return
      this.audios.push(r.audio)
      // 区分"已缓存"与"需要付费的新合成"：两者都不等于试听合格
      const head = r.cached ? '命中已缓存试听（未产生新费用）' : '已生成试听'
      const tail = r.audio.is_mock
        ? '（占位试听，未提交真实供应商）'
        : `（${Math.round(r.audio.duration_ms / 100) / 10}s）`
      this.setNotice('ok', `${head}${tail}：试听片不能当作正文音频`)
    },

    async selectVoice(voiceId: string) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      await this.guard('选声', async () => {
        const updated = await api.selectVoice(id, voiceId)
        if (!this.workContextMatches(id, version)) return
        const w = this.works.find((x) => x.id === id)
        if (w) Object.assign(w, updated)
      })
      if (!this.error && this.workContextMatches(id, version)) await this.syncWork(id)
    },

    async synthesizeFull(forceNew = false) {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('全文合成', () => api.synthesizeFullAudio(id, forceNew))
      if (!r) return
      this.audios = [...this.audios.filter(a => a.id !== r.audio.id), r.audio]
      if (r.is_mock) {
        // 占位产物不继承任何通过结论：必须说清楚它不能进入生产
        this.setNotice('warn', r.note)
        return
      }
      const unsupported = r.control_summary?.unsupported ?? 0
      const extra = unsupported ? `，${unsupported} 项表达控制未生效（已在调用前报告）` : ''
      this.setNotice('ok', `全文音频已合成，实际时长 ${Math.round(r.duration_ms / 100) / 10}s${extra}，请试听后确认`)
    },

    async confirmAudio(audioId: string) {
      const id = this.currentWorkId
      if (!id) return
      // 点击"确认"即用户的显式听检确认：本项目没有音频识别能力，
      // 术语读法正确与否只能由人听过之后承担，因此这里必须传 audition_ack=true。
      const r = await this.guard('确认音频', () => api.confirmAudio(id, audioId, true))
      if (!r) return
      if (!r.ok) return this.setNotice('danger', r.message)
      this.audios.forEach((a) => (a.confirmed = a.id === audioId))
      this.setNotice('ok', r.message)
      await this.syncWork(id)
    },

    async estimateCost(route: GenerationRoute) {
      const id = this.currentWorkId
      if (!id) return null
      return await this.guard('估价', () => api.estimateCost(id, route))
    },

    /**
     * 确认路线。高成本路线（OmniHuman）必须先确认费用提示：
     * 后端的门禁是硬性的，这里只是把用户那一次确认如实传上去。
     */
    async confirmRoute(route: GenerationRoute, costNoticeAck = false) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      const r = await this.guard('确认路线', () => api.confirmCost(id, route, costNoticeAck))
      if (!r) return
      const w = this.works.find((x) => x.id === id)
      if (w) w.route = route
      if (this.task) this.task.route_confirmed = true
      this.setNotice('ok', r.message)
      const [routes, preflight] = await Promise.all([
        api.getTalkingHeadRoutes(id).catch(() => null), api.getTalkingHeadPreflight(id).catch(() => null),
      ])
      if (!this.workContextMatches(id, version)) return
      this.thRoutes = routes
      this.thPreflight = preflight
    },

    async submitVideo() {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      const t = await this.guard('提交合成', async () => {
        const task = await api.submitTask(id)
        if (!this.workContextMatches(id, version)) return null
        this.task = task
        const w = this.works.find((x) => x.id === id)
        if (w) w.current_task_id = task.id
        return task
      })
      if (t) await this.pollTask(40)
    },

    async cancelTask() {
      const id = this.task?.id
      const workId = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      await this.guard('取消', async () => {
        const task = await api.cancelTask(id)
        if (this.workContextMatches(workId, version, id)) this.task = task
      })
    },

    // ---------- T05 数字人口播 ----------

    /**
     * 读取口播相关的全部只读视图。刻意分开取：某项不存在（例如还没分段计划）
     * 是正常状态，不应该让整页加载失败。
     */
    async loadTalkingHead(workId?: string) {
      const id = workId ?? this.currentWorkId
      if (!id) return
      const version = this.workLoadVersion
      await this.guard('读取口播状态', async () => {
        const [routes, preflight, cost, segments, plate, submissions, gate, queue, adapters, videos] = await Promise.all([
          api.getTalkingHeadRoutes(id), api.getTalkingHeadPreflight(id), api.getTalkingHeadCost(id),
          api.getSegmentPlan(id), api.getPlateStatus(id), api.getSubmissions(id),
          api.getTalkingHeadGate(id), api.getTalkingHeadQueue(id), api.getTalkingHeadAdapters(), api.getVideos(id),
        ])
        // 门禁逐条取：列表里可能有多条候选原片，各自结论不同。
        const gates: Record<string, VideoGateView> = {}
        for (const v of videos) {
          try {
            gates[v.id] = await api.getVideoGate(v.id)
          } catch {
            // 取不到就留空——界面显示"未取得结论"，绝不推断成通过。
          }
        }
        if (this.currentWorkId !== id || this.workLoadVersion !== version) return
        this.thRoutes = routes
        this.thPreflight = preflight
        this.thCost = cost
        this.thSegments = segments
        this.thPlate = plate
        this.thSubmissions = submissions
        this.thGate = gate
        this.thQueue = queue
        this.thAdapters = adapters
        this.videos = videos
        this.videoGates = gates
      })
    },

    /** 费用确认：摘要由服务端按当前绑定推导，前端只提交输入（描述、分辨率）。 */
    async confirmTalkingHeadCost(route: GenerationRoute) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      const rec = await this.guard('确认费用', () =>
        api.confirmTalkingHeadCost(id, {
          route,
          prompt: this.thPrompt,
          resolution: this.thResolution,
        }),
      )
      if (!rec) return
      this.setNotice(
        'warn',
        `已确认调用清单与金额（估价 ¥${(rec.estimated_fen / 100).toFixed(2)}，上限 ¥${(rec.ceiling_fen / 100).toFixed(2)}）：`
          + '这是清单确认，不是付费授权；实际扣费仍由预算策略与台账决定',
      )
      const cost = await api.getTalkingHeadCost(id, route).catch(() => null)
      if (this.workContextMatches(id, version)) this.thCost = cost
    },

    async createSegmentPlan() {
      const id = this.currentWorkId
      if (!id) return
      const p = await this.guard('建立分段计划', () => api.createSegmentPlan(id))
      if (p) this.thSegments = p
    },

    async createPlate(outputSeconds: number, variantId?: string) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      // 不带 variant_id 时后端回退到作品绑定的变体；这里显式传是为了让界面选的那条
      // 与实际用的那条一致——否则用户改了选择却仍用旧的，看不出来。
      const r = await this.guard('生成底片', () => api.createPlate(id, outputSeconds, variantId))
      if (!r) return
      // 占位产物不登记为资产：这里必须说清楚，否则用户会以为底片已经可用了。
      this.setNotice(r.registered ? 'ok' : 'warn', r.note)
      const [plate, videos] = await Promise.all([
        api.getPlateStatus(id).catch(() => null), api.getVideos(id).catch(() => []),
      ])
      if (!this.workContextMatches(id, version)) return
      this.thPlate = plate
      this.videos = videos
    },

    /** 底片审核：通过只能由用户给出——身份是否漂移只能由人目检。 */
    async reviewPlate(plateId: string, outcome: 'pass' | 'fail', note = '') {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('底片审核', () =>
        api.reviewPlate(plateId, { reviewer: 'user_local', outcome, note }),
      )
      if (!r) return
      this.setNotice('ok', `已登记底片审核结论：${outcome}`)
      await this.loadTalkingHead(id)
    },

    async submitTalkingHead(dryRun: boolean) {
      const id = this.currentWorkId
      const version = this.workLoadVersion
      if (!id) return
      const r = await this.guard('提交口播', () =>
        api.submitTalkingHead(id, {
          route: this.currentRoute,
          prompt: this.thPrompt,
          resolution: this.thResolution,
          dry_run: dryRun,
        }),
      )
      if (!r) return
      if (r.is_mock || !r.submitted) {
        // 占位提交不产生任何媒体：不得显示成"已生成"，也不得留下产物。
        this.setNotice('warn', r.note)
      } else {
        this.setNotice('ok', `已提交 ${r.runs.length} 个调用；外部作业需按原任务号查询，未知结果先核对`)
      }
      const [submissions, videos] = await Promise.all([
        api.getSubmissions(id).catch(() => null), api.getVideos(id).catch(() => []),
      ])
      if (!this.workContextMatches(id, version)) return
      this.thSubmissions = submissions
      this.videos = videos
    },

    /** 未知结果先对账：不盲目重提，也不把未知写成失败。 */
    async settleRun(runId: string, note: string) {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('对账', () => api.settleRun(runId, note))
      if (!r) return
      this.setNotice('ok', '已登记对账结论；重提需你重新授权，不会自动发生')
      await this.loadTalkingHead(id)
    },

    async reviewVideo(
      videoId: string,
      dimensions: Record<string, string>,
      references: Record<string, { asset_id: string; start_ms: number; end_ms: number }>,
      outcome: 'pass' | 'fail',
      note = '',
    ) {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('原片审核', () =>
        api.reviewVideo(videoId, { reviewer: 'user_local', outcome, dimensions, references, note }),
      )
      if (!r) return
      this.setNotice('ok', '已登记人工原片审核结论（口型/身份/身体/表情四项）')
      await this.loadTalkingHead(id)
    },

    async recordAudioTrackCheck(
      videoId: string,
      input: { audio_asset_id: string; measured_offset_ms: number; evidence: string },
    ) {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('核对音轨', () =>
        api.recordAudioTrackCheck(videoId, {
          audio_asset_id: input.audio_asset_id,
          method: 'decode_align',
          outcome: 'pass',
          measured_offset_ms: input.measured_offset_ms,
          evidence: input.evidence,
        }),
      )
      if (!r) return
      this.setNotice('ok', '已登记音轨保持核对记录（与画面审核分别记录）')
      await this.loadTalkingHead(id)
    },

    async confirmFinalVideo(videoId: string, reviewAck: boolean, note = '') {
      const id = this.currentWorkId
      if (!id) return
      const r = await this.guard('确认原片', () => api.confirmFinalVideo(id, videoId, reviewAck, note))
      if (!r) return
      this.setNotice('ok', r.note || '已确认最终原片')
      await this.loadTalkingHead(id)
    },
  },
})
