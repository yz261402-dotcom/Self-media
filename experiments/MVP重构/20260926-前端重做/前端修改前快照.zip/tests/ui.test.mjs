import assert from 'node:assert/strict'
import { after, test } from 'node:test'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { build } from 'esbuild'
import { parse, compileScript } from '@vue/compiler-sfc'
import { createSSRApp } from 'vue'
import { renderToString } from '@vue/server-renderer'
import { createPinia, setActivePinia } from 'pinia'
import { createRouter, createMemoryHistory } from 'vue-router'

const output = await mkdtemp(resolve('node_modules/.studio-ui-tests-'))
after(() => rm(output, { recursive: true, force: true }))
const views = {}
for (const name of ['App', 'views/AvatarView', 'views/TtsView', 'views/VideoView']) {
  const outfile = join(output, `${name.replaceAll('/', '-')}.mjs`)
  await build({
    stdin: { contents: `export { default } from './src/${name}.vue'; export { useStudioStore } from './src/stores/studio.ts'`, resolveDir: resolve('.') },
    outfile, bundle: true, format: 'esm', platform: 'node',
    external: ['vue', 'vue/server-renderer', 'pinia', 'vue-router'],
    plugins: [{ name: 'vue-test', setup(builder) {
      builder.onResolve({ filter: /^@\/api$/ }, () => ({ path: 'api', namespace: 'test' }))
      builder.onLoad({ filter: /.*/, namespace: 'test' }, () => ({ contents: 'export const api = {}; export const apiMode = "http";' }))
      builder.onLoad({ filter: /\.vue$/ }, async ({ path }) => {
        const { descriptor } = parse(await readFile(path, 'utf8'), { filename: path })
        const result = compileScript(descriptor, { id: path, inlineTemplate: true, templateOptions: { ssr: true } })
        return { contents: result.content, loader: 'ts', resolveDir: dirname(path) }
      })
    } }],
  })
  views[name] = await import(pathToFileURL(outfile).href)
}

async function render(name, setup) {
  const pinia = createPinia()
  setActivePinia(pinia)
  const view = views[name]
  const store = view.useStudioStore()
  store.apiReady = true
  setup(store)
  const router = createRouter({ history: createMemoryHistory(), routes: ['avatar', 'script', 'tts', 'video', 'publish', 'metrics', 'models'].map(name => ({ path: `/${name}`, component: { template: '<div />' } })) })
  await router.push('/avatar')
  return renderToString(createSSRApp(view.default).use(pinia).use(router))
}

test('empty workspace shows a five-step guide and a direct create-work action', async () => {
  const html = await render('App', () => {})
  assert.match(html, /aria-label="创作进度"/)
  assert.match(html, /创建第一个作品/)
  assert.match(html, /确认人物/)
  assert.match(html, /合成与下载/)
})

test('voice previews contain an actual audio player and require an explicit listening acknowledgement', async () => {
  const html = await render('views/TtsView', store => {
    store.works = [{ id: 'work', brief: {}, script_version_id: 'script' }]
    store.currentWorkId = 'work'
    store.scriptBatch = { candidates: [{ id: 'script' }] }
    store.audios = [
      { id: 'preview', kind: 'preview', duration_ms: 3000, url: '/preview.wav', checks: [] },
      { id: 'full', kind: 'full', duration_ms: 60000, url: '/full.wav', checks: [], confirmed: false },
    ]
  })
  assert.match(html, /<audio[^>]+src="\/preview.wav"/)
  assert.match(html, /我已试听/)
})

test('completed video page renders the real delivery preview and download', async () => {
  const html = await render('views/VideoView', store => {
    store.currentWorkId = 'work'
    store.pkg = { work_id: 'work', state: 'ready', mode: 'production', title: '交付作品', files: [], video_url: '/final.mp4', download_url: '/package.zip' }
  })
  assert.match(html, /<video[^>]+src="\/final.mp4"/)
  assert.match(html, /href="\/package.zip"/)
  assert.match(html, /下载完整作品包/)
  assert.match(html, /检查生成条件/)
  assert.match(html, /生成口播（真实调用/)
})

test('person selection starts with clear cards and variant options use real background assets', async () => {
  const html = await render('views/AvatarView', store => {
    store.identities = [{ id: 'person', name: '现有主播', approval_state: 'approved', persona: '自然讲述' }]
    store.backgroundAssets = [{ id: 'background-real', note: '已登记的演播室', kind: 'background', approval_state: 'approved' }]
  })
  assert.match(html, /class="avatar-cards"/)
  assert.match(html, /选择已有主播/)
  assert.match(html, /value="background-real"/)
  assert.doesNotMatch(html, /value="studio"/)
})

test('frozen incomplete person offers a new draft without claiming automatic approval', async () => {
  const html = await render('views/AvatarView', store => {
    store.identities = [{ id: 'legacy', name: '旧主播', approval_state: 'approved', frozen: true, persona: '自然讲述' }]
    store.readinessMap = { legacy: { ready: false, reasons: ['旧审核不完整'] } }
  })
  assert.match(html, /复制为新草稿/)
})

test('a running script or avatar task does not show video synthesis in progress', async () => {
  const html = await render('App', store => {
    store.task = { id: 'task', state: 'running', stage: 'avatar_variant' }
  })
  assert.doesNotMatch(html, /合成进行中/)
})
