import assert from 'node:assert/strict'
import { beforeEach, after, test } from 'node:test'
import { mkdtemp, rm } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { build } from 'esbuild'
import { createPinia, setActivePinia } from 'pinia'

// Only the HTTP boundary is replaced. Tests exercise the real Pinia actions/getters.
const output = await mkdtemp(resolve('node_modules/.studio-tests-'))
await build({
  entryPoints: ['src/stores/studio.ts'], outfile: join(output, 'studio.mjs'),
  bundle: true, platform: 'node', format: 'esm', external: ['vue', 'pinia'],
  plugins: [{ name: 'test-api', setup(builder) {
    builder.onResolve({ filter: /^@\/api$/ }, () => ({ path: 'api', namespace: 'test' }))
    builder.onLoad({ filter: /.*/, namespace: 'test' }, () => ({
      contents: 'export const api = new Proxy({}, { get: (_, key) => globalThis.studioTestApi[key] });',
    }))
  } }],
})
const { useStudioStore } = await import(pathToFileURL(join(output, 'studio.mjs')).href)
after(() => rm(output, { recursive: true, force: true }))

const work = (id, extra = {}) => ({
  id, name: id, brief: { topic: id, materials: [] }, identity_id: null,
  voice_asset_id: null, script_version_id: null, final_audio_id: null,
  current_task_id: null, ...extra,
})
const audio = (id, workId, extra = {}) => ({
  id, work_id: workId, kind: 'full', confirmed: true, is_mock: false,
  voice_asset_id: 'voice', duration_ms: 60000, checks: [], ...extra,
})
let serverWorks
let store
beforeEach(() => {
  setActivePinia(createPinia())
  serverWorks = [work('one'), work('two')]
  globalThis.studioTestApi = {
    listWorks: async () => structuredClone(serverWorks),
    getScriptBatch: async () => null, listVariants: async () => [],
    getPackage: async () => null, listAudios: async () => [],
    listMotions: async () => null, listMasks: async () => null,
    listIdentityAssets: async () => [],
  }
  store = useStudioStore()
  store.works = structuredClone(serverWorks)
})

test('opening a work restores its persisted final audio and current bindings', async () => {
  serverWorks[0].final_audio_id = 'saved'
  globalThis.studioTestApi.listAudios = async id => [audio('saved', id)]
  await store.selectWork('one')
  assert.equal(store.currentWork.final_audio_id, 'saved')
  assert.equal(store.confirmedAudio?.id, 'saved')
})

test('switching works removes the previous audio, video, price and package before loading', async () => {
  store.currentWorkId = 'one'
  store.audios = [audio('old', 'one')]
  store.videos = [{ id: 'video-old', work_id: 'one', kind: 'original', confirmed: true }]
  store.thCost = { confirmation: { id: 'old-price' } }
  store.pkg = { id: 'old-package' }
  let release
  globalThis.studioTestApi.getScriptBatch = () => new Promise(r => { release = r })
  const loading = store.selectWork('two')
  assert.equal(store.confirmedAudio, null)
  assert.equal(store.finalVideo, null)
  assert.equal(store.thConfirmedCost, null)
  assert.equal(store.pkg, null)
  release(null)
  await loading
})

test('a slower previous work request cannot overwrite the newly selected work', async () => {
  const pending = {}
  globalThis.studioTestApi.getScriptBatch = id => new Promise(r => { pending[id] = r })
  const first = store.selectWork('one')
  const second = store.selectWork('two')
  pending.two({ id: 'batch-two', candidates: [] })
  await second
  pending.one({ id: 'batch-one', candidates: [] })
  await first
  assert.equal(store.currentWorkId, 'two')
  assert.equal(store.scriptBatch.id, 'batch-two')
})

test('choosing a person uses all server bindings including its default voice', async () => {
  store.currentWorkId = 'one'
  globalThis.studioTestApi.selectIdentity = async () => {
    serverWorks[0] = work('one', { identity_id: 'person', voice_asset_id: 'default-voice' })
    return structuredClone(serverWorks[0])
  }
  await store.selectIdentity('person')
  assert.equal(store.currentWork.voice_asset_id, 'default-voice')
})

test('changing voice removes invalidated final audio and old delivery state', async () => {
  store.currentWorkId = 'one'
  store.audios = [audio('old', 'one')]
  store.pkg = { id: 'old-package' }
  globalThis.studioTestApi.selectVoice = async () => {
    serverWorks[0].voice_asset_id = 'new-voice'
    return structuredClone(serverWorks[0])
  }
  await store.selectVoice('new-voice')
  assert.equal(store.confirmedAudio, null)
  assert.equal(store.pkg, null)
  assert.equal(store.currentWork.voice_asset_id, 'new-voice')
})

test('a confirmed audio from another work or an obsolete script cannot advance the guide', () => {
  store.currentWorkId = 'one'
  store.works[0].script_version_id = 'script-new'
  store.audios = [audio('other', 'two'), audio('old', 'one', { script_version_id: 'script-old' })]
  assert.equal(store.confirmedAudio, null)
})

test('completed MVP directs the user to download instead of the unavailable publish page', () => {
  store.currentWorkId = 'one'
  Object.assign(store.works[0], { identity_id: 'person', script_version_id: 'script' })
  store.readinessMap = { person: { ready: true, reasons: [] } }
  store.scriptBatch = { candidates: [{ id: 'script' }] }
  store.audios = [audio('final', 'one', { script_version_id: 'script' })]
  store.pkg = { id: 'package', work_id: 'one', state: 'ready', mode: 'production', download_url: '/download' }
  assert.equal(store.nextStep.to, '/video')
  assert.equal(store.nextStep.key, 'download')
})

test('an already selected person with incomplete readiness keeps the guide on the person step', () => {
  store.currentWorkId = 'one'
  store.works[0].identity_id = 'person'
  store.readinessMap = { person: { ready: false, reasons: ['缺少参考图审核'] } }
  assert.equal(store.nextStep.to, '/avatar')
  assert.match(store.nextStep.detail, /缺少参考图审核/)
})

test('late video status from a previous work cannot overwrite current video state', async () => {
  store.currentWorkId = 'one'
  let release
  globalThis.studioTestApi.getTalkingHeadRoutes = () => new Promise(r => { release = r })
  for (const name of ['getTalkingHeadPreflight', 'getTalkingHeadCost', 'getSegmentPlan', 'getPlateStatus', 'getSubmissions', 'getTalkingHeadGate', 'getTalkingHeadQueue', 'getTalkingHeadAdapters']) {
    globalThis.studioTestApi[name] = async () => ({ work_id: 'one' })
  }
  globalThis.studioTestApi.getVideos = async () => []
  const pending = store.loadTalkingHead()
  store.currentWorkId = 'two'
  release({ work_id: 'one' })
  await pending
  assert.equal(store.thRoutes, null)
  assert.equal(store.thPreflight, null)
})

test('failed work creation returns null without selecting a different work', async () => {
  globalThis.studioTestApi.createWork = async () => { throw new Error('temporarily unavailable') }
  const created = await store.createWork({ name: 'new', topic: 'new' })
  assert.equal(created, null)
  assert.equal(store.currentWorkId, null)
  assert.equal(store.error, 'temporarily unavailable')
})

test('starting postprocess binds the returned task to the selected work', async () => {
  store.currentWorkId = 'one'
  globalThis.studioTestApi.startPostprocess = async () => ({ id: 'post-task', work_id: 'one', state: 'queued' })
  globalThis.studioTestApi.getPostprocess = async () => ({ task: { id: 'post-task', work_id: 'one', state: 'queued' }, ready_for_review: false })
  await store.startPostprocess()
  assert.equal(store.task.id, 'post-task')
  assert.equal(store.currentWork.current_task_id, 'post-task')
})

test('a late postprocess response cannot attach a preview to another work', async () => {
  store.currentWorkId = 'one'
  let release
  globalThis.studioTestApi.getPostprocess = () => new Promise(r => { release = r })
  const pending = store.refreshPostprocess()
  store.currentWorkId = 'two'
  release({ preview_url: '/one.mp4', ready_for_review: true })
  await pending
  assert.equal(store.postprocess, null)
})

test('full audio defaults to reuse and only explicitly requests a new paid synthesis', async () => {
  store.currentWorkId = 'one'
  const requested = []
  globalThis.studioTestApi.synthesizeFullAudio = async (_id, forceNew) => {
    requested.push(forceNew)
    return { audio: audio('synthesized', 'one', { confirmed: false }), is_mock: true, note: 'test' }
  }
  await store.synthesizeFull()
  await store.synthesizeFull(true)
  assert.deepEqual(requested, [false, true])
})

test('a package belonging to another work never completes the current guide', () => {
  store.currentWorkId = 'two'
  store.pkg = { work_id: 'one', state: 'ready', mode: 'production', download_url: '/one.zip' }
  assert.equal(store.deliveryReady, false)
})

test('late task polling cannot attach a previous work task or package', async () => {
  store.currentWorkId = 'one'
  store.works[0].current_task_id = 'task-one'
  let release
  globalThis.studioTestApi.getTask = () => new Promise(r => { release = r })
  globalThis.studioTestApi.getTaskEvents = async () => [{ id: 'old-event' }]
  globalThis.studioTestApi.getPackage = async id => id === 'one' ? { work_id: 'one', state: 'ready' } : null
  const pending = store.refreshTask()
  await store.selectWork('two')
  release({ id: 'task-one', work_id: 'one', state: 'succeeded' })
  await pending
  assert.equal(store.task, null)
  assert.deepEqual(store.events, [])
  assert.equal(store.pkg, null)
})

test('late task events cannot attach after the same work starts a replacement task', async () => {
  store.currentWorkId = 'one'
  store.works[0].current_task_id = 'task-one'
  globalThis.studioTestApi.getTask = async () => ({ id: 'task-one', work_id: 'one', state: 'running' })
  let release
  globalThis.studioTestApi.getTaskEvents = () => new Promise(r => { release = r })
  const pending = store.refreshTask()
  await new Promise(r => setImmediate(r))
  store.works[0].current_task_id = 'task-new'
  store.task = { id: 'task-new', work_id: 'one', state: 'running' }
  release([{ id: 'old-event' }])
  await pending
  assert.deepEqual(store.events, [])
  assert.equal(store.task.id, 'task-new')
})

test('postprocess response from a previous visit cannot overwrite a newer visit to the same work', async () => {
  store.currentWorkId = 'one'
  let release
  globalThis.studioTestApi.getPostprocess = () => new Promise(r => { release = r })
  const pending = store.refreshPostprocess()
  await store.selectWork('two')
  await store.selectWork('one')
  release({ preview_url: '/obsolete.mp4', ready_for_review: true })
  await pending
  assert.equal(store.postprocess, null)
})

test('late audio synthesis cannot populate the newly selected work', async () => {
  store.currentWorkId = 'one'
  let release
  globalThis.studioTestApi.synthesizeFullAudio = () => new Promise(r => { release = r })
  const pending = store.synthesizeFull()
  await store.selectWork('two')
  release({ audio: audio('old', 'one'), is_mock: true, note: 'old audio' })
  await pending
  assert.deepEqual(store.audios, [])
  assert.notEqual(store.notice?.text, 'old audio')
})
